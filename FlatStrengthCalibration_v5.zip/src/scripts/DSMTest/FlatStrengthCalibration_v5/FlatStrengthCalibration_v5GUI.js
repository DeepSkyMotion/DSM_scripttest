// FlatStrengthCalibration_v5GUI.js - dialogs only. They edit PSWParameters and call
// PSWEngine; they never process pixels themselves.
// V8 engine style: ES6 class extends Dialog, enums as Namespace.Value (FrameStyle.Box ...).
//
// PSWDialog         main dialog (sessions, output, advanced options, Calibrate)
// PSWPreviewDialog  "Flat Strength" preview. It is a MODAL child dialog launched from
//                   the main dialog: its Apply buttons write strengths straight into
//                   params, and the main dialog refreshes its lists when it closes.

// Branded header strip (reference/branding.md). Pure display, never throws:
// a missing asset is simply skipped. SVGs are rendered once at physical size;
// onPaint only blits. Keep it unless the user asks to remove branding.
var PSWHeader = class extends Control
{
   constructor( parent )
   {
      super( parent );
      let self = this;
      this.iconBitmap = null;
      this.logoBitmap = null;
      this.titleFont = null;
      this.subFont = null;
      let s = 1;
      try { s = this.logicalPixelsToPhysical( 1 ); } catch ( e ) {}
      this.s = s;
      this.setScaledFixedHeight( 64 );
      let dir = File.extractDrive( #__FILE__ ) + File.extractDirectory( #__FILE__ ) + "/";
      try
      {
         if ( File.exists( dir + PSW_ICON ) )
            this.iconBitmap = Bitmap.fromSVGFile( dir + PSW_ICON, Math.round( 44*s ), Math.round( 44*s ) );
      }
      catch ( e ) { this.iconBitmap = null; }
      try
      {
         // brand_logo.svg: white logotype on transparent background; keep its aspect ratio.
         let f = dir + "brand_logo.svg";
         if ( File.exists( f ) )
         {
            let h = Math.round( 22*s );
            let w = 4*h;
            let vb = /viewBox="\s*[-\d.]+[\s,]+[-\d.]+[\s,]+([\d.]+)[\s,]+([\d.]+)/.exec( File.readTextFile( f ) );
            if ( vb != null && parseFloat( vb[2] ) > 0 )
               w = Math.round( h*parseFloat( vb[1] )/parseFloat( vb[2] ) );
            this.logoBitmap = Bitmap.fromSVGFile( f, w, h );
         }
      }
      catch ( e ) { this.logoBitmap = null; }
      try
      {
         let base = this.font;
         this.subFont = new Font( base.family, base.pointSize );
         this.titleFont = new Font( base.family, base.pointSize*1.35 );
         this.titleFont.bold = true;
      }
      catch ( e ) { this.titleFont = this.subFont = null; }

      this.onPaint = function( x0, y0, x1, y1 )
      {
         let g = new Graphics( self );
         try { self.paintHeader( g, self.width, self.height ); }
         catch ( e ) {}
         finally { g.end(); }
      };
   }

   paintHeader( g, w, h )
   {
      let s = this.s;
      g.fillRect( 0, 0, w, h, new Brush( 0xff0B1121 ) );
      let textX = Math.round( 12*s );
      if ( this.iconBitmap != null && this.iconBitmap.width > 0 )
      {
         g.drawBitmap( Math.round( 12*s ), Math.round( (h - this.iconBitmap.height)/2 ), this.iconBitmap );
         textX += this.iconBitmap.width + Math.round( 12*s );
      }
      if ( this.titleFont != null && this.subFont != null )
      {
         g.antialiasing = true;
         g.textAntialiasing = true;
         let th = this.titleFont.height, sh = this.subFont.height;
         let top = Math.round( (h - th - sh)/2 );
         g.font = this.titleFont;
         g.pen = new Pen( 0xffF8F9F9 );
         g.drawText( textX, top + this.titleFont.ascent, PSW_TITLE );
         g.font = this.subFont;
         g.pen = new Pen( 0xff9AA3B5 );
         g.drawText( textX, top + th + this.subFont.ascent, PSW_TAGLINE + "  ·  v" + PSW_VERSION );
      }
      if ( this.logoBitmap != null && this.logoBitmap.width > 0 )
      {
         g.smoothInterpolation = true;
         g.drawBitmap( w - Math.round( 14*s ) - this.logoBitmap.width, Math.round( (h - this.logoBitmap.height)/2 ), this.logoBitmap );
      }
   }
};

var PSW_FILE_FILTERS = [ [ "XISF and FITS files", "*.xisf", "*.fit", "*.fits", "*.fts" ], [ "All files", "*" ] ];

function pswFormatStrength( s )
{
   return ( s >= 0 ? "+" : "" ) + s.toFixed( 2 );
}

// v5: "R +0.10  G +0.00  B -0.20" (compact: "R+0.10 G+0.00 B-0.20").
function pswFormatTriple( t, compact )
{
   let sep = compact ? "" : " ";
   return [ "R", "G", "B" ].map( ( c, i ) => c + sep + pswFormatStrength( t[ i ] ) ).join( compact ? " " : "  " );
}

// v5: is the session CFA for the GUI? cfaMode CFA -> yes, Mono -> no, Auto -> the first
// light is a one-channel frame with a Bayer keyword (header only, cached per file stamp).
var pswCfaHeaderCache = {};
function pswSessionIsCFA( s )
{
   if ( !s )
      return false;
   let mode = String( s.cfaMode ).toLowerCase();
   if ( mode == "cfa" )
      return true;
   if ( mode == "mono" )
      return false;
   if ( !s.lights || s.lights.length == 0 || !File.exists( s.lights[ 0 ].path ) )
      return false;
   let key = JSON.stringify( PSWEngine.fileStamp( s.lights[ 0 ].path ) );
   if ( pswCfaHeaderCache[ key ] === undefined )
      try
      {
         let h = PSWEngine.readHeader( s.lights[ 0 ].path );
         pswCfaHeaderCache[ key ] = h.pattern != "" && h.channels == 1;
      }
      catch ( e )
      {
         return false;
      }
   return pswCfaHeaderCache[ key ];
}

// v5: channel-wise strengths are in effect for this session (flag set and CFA).
function pswChannelWiseActive( s )
{
   return !!( s && s.channelWise ) && pswSessionIsCFA( s );
}

// v5: switches channel-wise on/off. On: a missing session triple becomes [s, s, s] from the
// scalar session strength; every scalar frame override without a triple gets [s, s, s].
// Off: the triples stay stored, the run uses the scalar fields again.
function pswSetChannelWise( s, on )
{
   s.channelWise = !!on;
   if ( !on )
      return;
   if ( !PSWEngine.strengthTriple( s.strengthRGB ) )
   {
      let v = PSWEngine.normStrength( s.strength );
      s.strengthRGB = [ v, v, v ];
   }
   s.lights.forEach( l =>
   {
      if ( l.strength !== null && l.strength !== undefined && l.strength !== "" && !PSWEngine.strengthTriple( l.strengthRGB ) )
      {
         let v = PSWEngine.normStrength( l.strength );
         l.strengthRGB = [ v, v, v ];
      }
   } );
}

// v5: shifts all three strengths by the same delta, clamped so that none leaves [-1, +1]
// (the differences are kept). Returns the new triple.
function pswShiftTriple( t, delta )
{
   let lo = -1 - Math.min( t[ 0 ], t[ 1 ], t[ 2 ] ), hi = 1 - Math.max( t[ 0 ], t[ 1 ], t[ 2 ] );
   let d = Math.max( lo, Math.min( hi, delta ) );
   return t.map( v => PSWEngine.normStrength( v + d ) );
}

function pswMessage( text, icon )
{
   ( new MessageBox( text, PSW_TITLE, icon === undefined ? StdIcon.Information : icon, StdButton.Ok ) ).execute();
}

// ----------------------------------------------------------------------------
// Preview dialog
// ----------------------------------------------------------------------------

var PSWPreviewDialog = class extends Dialog
{
   // ctx: prepared preview context (PSWEngine.preparePreview), owned by this dialog from now on.
   constructor( params, sessionIndex, ctx, selectedIndices, parent )
   {
      super( parent );
      let self = this;
      this.params = params;
      this.si = sessionIndex;
      this.session = params.sessions[ sessionIndex ];
      this.ctx = ctx;
      this.selected = selectedIndices || [];
      this.bitmap = null;
      this.beforeCache = {};     // "deb|linked", "mos|unlinked", ... -> { bmp, st }
      this.frozen = null;        // Lock stretch: { key: "deb|unlinked" ..., st } from an After image
      this.busy = false;
      this.pending = false;
      this.lastRenderMs = 0;

      this.mainDialog = null;    // set by PSWDialog.openPreview: refreshed when Channel-wise changes
      let li = ctx.lightIndex || 0;
      this.s = PSWEngine.effectiveStrength( this.session.lights[ li ], this.session );
      // v5: channel-wise working triple [sR, sG, sB] (used when this.cw).
      this.cw = !!this.session.channelWise && ctx.isCFA;
      this.sRGB = this.loadTriple( li );

      // Header
      this.headerLabel = new Label( this );
      this.headerLabel.useRichText = true;
      this.headerLabel.wordWrapping = true;

      this.lightCombo = new ComboBox( this );
      this.session.lights.forEach( l => this.lightCombo.addItem( File.extractNameAndExtension( l.path ) ) );
      this.lightCombo.currentItem = li;
      this.lightCombo.toolTip = "<p>Light frame shown in the preview.</p>";
      this.lightCombo.onItemSelected = function( index ) { self.switchLight( index ); };

      this.lightSizer = new HorizontalSizer;
      this.lightSizer.spacing = 6;
      let ll = new Label( this );
      ll.text = "Light:";
      ll.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.lightSizer.add( ll );
      this.lightSizer.add( this.lightCombo, 100 );

      // Preview area
      this.previewControl = new Control( this );
      this.previewControl.setScaledMinSize( 820, 560 );
      this.previewControl.toolTip = "<p>Auto-stretched preview (display only).</p>";
      this.previewControl.onPaint = function( x0, y0, x1, y1 )
      {
         let g = new Graphics( this );
         try
         {
            g.fillRect( 0, 0, this.width, this.height, new Brush( 0xff181818 ) );
            let bmp = self.bitmap;
            if ( bmp )
            {
               let sc = Math.min( this.width/bmp.width, this.height/bmp.height );
               let w = Math.max( 1, Math.round( bmp.width*sc ) ), h = Math.max( 1, Math.round( bmp.height*sc ) );
               let ox = Math.round( ( this.width - w )/2 ), oy = Math.round( ( this.height - h )/2 );
               g.drawScaledBitmap( new Rect( ox, oy, ox + w, oy + h ), bmp );
            }
            else
            {
               g.pen = new Pen( 0xffc0c0c0 );
               g.drawTextRect( 0, 0, this.width, this.height, "Rendering...", TextAlignment.Center );
            }
         }
         finally
         {
            g.end();
         }
      };

      this.statusLabel = new Label( this );
      this.statusLabel.text = "";

      // Strength
      this.strengthControl = new NumericControl( this );
      this.strengthControl.label.text = "Flat strength:";
      this.strengthControl.setRange( -1, 1 );
      this.strengthControl.slider.setRange( -100, 100 );
      this.strengthControl.slider.scaledMinWidth = 300;
      this.strengthControl.setPrecision( 2 );
      this.strengthControl.setValue( this.s );
      this.strengthControl.toolTip = "<p>Flat correction strength. 0 = standard calibration, -1 = no flat, " +
                                     "+1 = flat applied twice (exponent k = 1 + s).</p>";
      this.strengthControl.onValueUpdated = function( value )
      {
         let v = PSWEngine.normStrength( value );
         if ( !self.cw )
            self.s = v;
         else
         {
            let ci = self.channelIndex();
            if ( ci >= 0 )
               self.sRGB[ ci ] = v;
            else
            {
               // All view: shift R, G, B together, keeping their differences.
               self.sRGB = pswShiftTriple( self.sRGB, v - self.sRGB[ 1 ] );
               if ( self.sRGB[ 1 ] != v )
                  self.strengthControl.setValue( self.sRGB[ 1 ] );   // clamped
            }
         }
         self.updateK();
         self.scheduleRender();
      };

      this.kLabel = new Label( this );
      this.kLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

      this.resetButton = new PushButton( this );
      this.resetButton.text = "Reset to 0";
      this.resetButton.toolTip = "<p>Back to the standard calibration (strength 0). Channel-wise: resets the " +
                                 "channel shown (R, G or B view) or all three (All view).</p>";
      this.resetButton.onClick = function()
      {
         self.strengthControl.setValue( 0 );
         if ( !self.cw )
            self.s = 0;
         else
         {
            let ci = self.channelIndex();
            if ( ci >= 0 )
               self.sRGB[ ci ] = 0;
            else
               self.sRGB = [ 0, 0, 0 ];
         }
         self.updateK();
         self.scheduleRender();
      };

      this.strengthSizer = new HorizontalSizer;
      this.strengthSizer.spacing = 8;
      this.strengthSizer.add( this.strengthControl, 100 );
      this.strengthSizer.add( this.kLabel );
      this.strengthSizer.add( this.resetButton );

      // v5: channel view and channel-wise strengths
      this.channelLabel = new Label( this );
      this.channelLabel.text = "Channel:";
      this.channelLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.channelCombo = new ComboBox( this );
      [ "All", "R", "G", "B" ].forEach( t => this.channelCombo.addItem( t ) );
      this.channelCombo.currentItem = 0;
      this.channelCombo.enabled = !!ctx.isCFA;
      this.channelLabel.enabled = !!ctx.isCFA;
      this.channelCombo.toolTip = "<p>R, G, B show a bin2 image built only from the pixels of that colour " +
                                  "(G = mean of the two green pixels).</p>" +
                                  "<p>Channel-wise: in R, G or B view the slider edits that colour only; in All view it " +
                                  "moves R, G and B together and keeps their differences.</p>";
      this.channelCombo.onItemSelected = function()
      {
         self.syncSlider();
         self.updateK();
         self.scheduleRender( true );
      };

      this.cwCheck = new CheckBox( this );
      this.cwCheck.text = "Channel-wise";
      this.cwCheck.checked = !!this.cw;
      this.cwCheck.enabled = !!ctx.isCFA;
      this.cwCheck.toolTip = "<p>Set the flat strength separately for red, green and blue pixels of the Bayer mosaic. " +
                             "No debayering: each colour is calibrated with its own flat strength. CFA frames only.</p>" +
                             "<p>Same setting as the session's 'Channel-wise (CFA)' checkbox.</p>";
      this.cwCheck.onCheck = function( checked )
      {
         pswSetChannelWise( self.session, checked );
         self.cw = !!( checked && self.ctx.isCFA );
         if ( self.cw )
         {
            // Stored triple of the frame or session; otherwise keep the unsaved slider value.
            let ses = self.session;
            if ( PSWEngine.strengthTriple( ses.lights[ self.ctx.lightIndex ].strengthRGB ) || PSWEngine.strengthTriple( ses.strengthRGB ) )
               self.sRGB = self.loadTriple( self.ctx.lightIndex );
            else
               self.sRGB = [ self.s, self.s, self.s ];
         }
         self.syncSlider();
         self.updateK();
         if ( self.mainDialog )
            self.mainDialog.updateSessionPanel();
         self.scheduleRender( true );
      };

      this.rgbLabel = new Label( this );
      this.rgbLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

      this.channelSizer = new HorizontalSizer;
      this.channelSizer.spacing = 8;
      this.channelSizer.add( this.channelLabel );
      this.channelSizer.add( this.channelCombo );
      this.channelSizer.addSpacing( 12 );
      this.channelSizer.add( this.cwCheck );
      this.channelSizer.addSpacing( 12 );
      this.channelSizer.add( this.rgbLabel, 100 );

      // View options
      this.beforeRadio = new RadioButton( this );
      this.beforeRadio.text = "Before";
      this.beforeRadio.toolTip = "<p>Raw light frame (no dark, no flat).</p>";
      this.beforeRadio.onCheck = function( checked ) { if ( checked ) self.scheduleRender( true ); };
      this.afterRadio = new RadioButton( this );
      this.afterRadio.text = "After";
      this.afterRadio.checked = true;
      this.afterRadio.toolTip = "<p>Calibrated light frame at the current strength.</p>";
      this.afterRadio.onCheck = function( checked ) { if ( checked ) self.scheduleRender( true ); };

      this.debayerCheck = new CheckBox( this );
      this.debayerCheck.text = "Debayer preview (CFA, preview only)";
      this.debayerCheck.checked = !!ctx.isCFA;
      this.debayerCheck.enabled = !!ctx.isCFA;
      this.debayerCheck.toolTip = "<p>Show a SuperPixel-debayered colour preview. Off: the calibrated mosaic " +
                                  "is shown in gray. The calibrated files always stay CFA.</p>";
      this.debayerCheck.onCheck = function() { self.bitmap = null; self.scheduleRender( true ); };

      this.lockCheck = new CheckBox( this );
      this.lockCheck.text = "Lock stretch";
      this.lockCheck.toolTip = "<p>Freeze the current After image's stretch (per colour in Unlinked mode). While " +
                               "locked, every strength is shown with the same stretch, so the real change in " +
                               "brightness and vignetting between strengths is visible. Changing Stretch or Debayer " +
                               "takes a new frozen stretch from the current After image; switching the light " +
                               "unlocks. Before always uses its own auto stretch.</p>";
      this.lockCheck.onCheck = function()
      {
         self.frozen = null;   // ticked: taken from the next (current) After render
         self.scheduleRender( true );
      };

      this.stretchLabel = new Label( this );
      this.stretchLabel.text = "Stretch:";
      this.stretchLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.stretchCombo = new ComboBox( this );
      this.stretchCombo.addItem( "Linked" );
      this.stretchCombo.addItem( "Unlinked" );
      let multi = !!ctx.isCFA || ( ctx.channels || 1 ) > 1;
      this.stretchCombo.currentItem = ( multi && params.previewStretchMode == "linked" ) ? 0 : 1;
      this.stretchCombo.enabled = multi;
      this.stretchLabel.enabled = multi;
      this.stretchCombo.toolTip = "<p>Display auto stretch (preview only).</p>" +
         "<p><b>Linked:</b> one stretch for all colours; the colour cast of the raw data stays visible.</p>" +
         "<p><b>Unlinked:</b> each colour gets its own stretch (R, G, B; in the gray mosaic per CFA colour, " +
         "G1 and G2 together), which neutralises the cast like PixInsight's unlinked STF.</p>" +
         "<p>Changing it only re-stretches the preview. Disabled for mono data.</p>";
      this.stretchCombo.onItemSelected = function( index )
      {
         self.params.previewStretchMode = index == 0 ? "linked" : "unlinked";
         self.scheduleRender( true );
      };

      this.viewSizer = new HorizontalSizer;
      this.viewSizer.spacing = 12;
      this.viewSizer.add( this.beforeRadio );
      this.viewSizer.add( this.afterRadio );
      this.viewSizer.addSpacing( 16 );
      this.viewSizer.add( this.debayerCheck );
      this.viewSizer.add( this.lockCheck );
      this.viewSizer.addSpacing( 16 );
      this.viewSizer.add( this.stretchLabel );
      this.viewSizer.add( this.stretchCombo );
      this.viewSizer.addSpacing( 16 );
      let msLabel = new Label( this );
      msLabel.text = "Preview size:";
      msLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.maxSizeSpin = new SpinBox( this );
      this.maxSizeSpin.minValue = 400;
      this.maxSizeSpin.maxValue = 4000;
      this.maxSizeSpin.stepSize = 100;
      this.maxSizeSpin.value = params.previewMaxSize;
      this.maxSizeSpin.toolTip = "<p>Longest side of the preview, in pixels.</p>";
      this.maxSizeSpin.onValueUpdated = function( v )
      {
         self.params.previewMaxSize = v;
         self.beforeCache = {};
         self.scheduleRender();
      };
      this.viewSizer.add( msLabel );
      this.viewSizer.add( this.maxSizeSpin );
      this.viewSizer.addStretch();

      // Apply
      this.applyFrameButton = new PushButton( this );
      this.applyFrameButton.text = "Apply to this frame";
      this.applyFrameButton.toolTip = "<p>Store the strength as an override for the frame shown.</p>";
      this.applyFrameButton.onClick = function()
      {
         let l = self.session.lights[ self.ctx.lightIndex ];
         if ( self.cw )
            l.strengthRGB = self.sRGB.slice();
         else
            l.strength = self.s;
         self.feedback( "Strength " + self.strengthText() + " set for " + self.lightCombo.itemText( self.ctx.lightIndex ) + "." );
      };

      this.applySelectedButton = new PushButton( this );
      this.applySelectedButton.text = "Apply to selected frames";
      this.applySelectedButton.enabled = this.selected.length > 0;
      this.applySelectedButton.toolTip = "<p>Store the strength as an override for all lights selected in the main " +
                                         "dialog (" + this.selected.length + ").</p>";
      this.applySelectedButton.onClick = function()
      {
         self.selected.forEach( i =>
         {
            if ( self.cw )
               self.session.lights[ i ].strengthRGB = self.sRGB.slice();
            else
               self.session.lights[ i ].strength = self.s;
         } );
         self.feedback( "Strength " + self.strengthText() + " set for " + self.selected.length + " selected frame(s)." );
      };

      this.applySessionButton = new PushButton( this );
      this.applySessionButton.text = "Apply to whole session";
      this.applySessionButton.toolTip = "<p>Set the session strength. Frame overrides stay unless " +
                                        "'Also clear frame overrides' is checked.</p>";
      this.applySessionButton.onClick = function()
      {
         if ( self.cw )
            self.session.strengthRGB = self.sRGB.slice();
         else
            self.session.strength = self.s;
         if ( self.clearOverridesCheck.checked )
            self.session.lights.forEach( l =>
            {
               if ( self.cw )
                  l.strengthRGB = null;
               else
                  l.strength = null;
            } );
         self.feedback( "Session strength set to " + self.strengthText() +
                        ( self.clearOverridesCheck.checked ? "; frame overrides cleared." : "." ) );
      };

      this.clearOverridesCheck = new CheckBox( this );
      this.clearOverridesCheck.text = "Also clear frame overrides";
      this.clearOverridesCheck.checked = false;

      this.clearFrameButton = new PushButton( this );
      this.clearFrameButton.text = "Clear frame override";
      this.clearFrameButton.toolTip = "<p>The frame shown goes back to the session strength (scalar and channel-wise " +
                                      "overrides are both cleared).</p>";
      this.clearFrameButton.onClick = function()
      {
         self.session.lights[ self.ctx.lightIndex ].strength = null;
         self.session.lights[ self.ctx.lightIndex ].strengthRGB = null;
         self.feedback( "Override cleared for " + self.lightCombo.itemText( self.ctx.lightIndex ) + "." );
      };

      this.closeButton = new PushButton( this );
      this.closeButton.text = "Close";
      this.closeButton.icon = this.scaledResource( ":/icons/close.png" );
      this.closeButton.onClick = function() { self.ok(); };

      this.applySizer = new HorizontalSizer;
      this.applySizer.spacing = 6;
      this.applySizer.add( this.applyFrameButton );
      this.applySizer.add( this.applySelectedButton );
      this.applySizer.add( this.applySessionButton );
      this.applySizer.add( this.clearOverridesCheck );
      this.applySizer.add( this.clearFrameButton );
      this.applySizer.addStretch();
      this.applySizer.add( this.closeButton );

      this.feedbackLabel = new Label( this );
      this.feedbackLabel.text = " ";

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 6;
      this.sizer.add( this.headerLabel );
      this.sizer.add( this.lightSizer );
      this.sizer.add( this.previewControl, 100 );
      this.sizer.add( this.statusLabel );
      this.sizer.add( this.strengthSizer );
      this.sizer.add( this.channelSizer );
      this.sizer.add( this.viewSizer );
      this.sizer.add( this.applySizer );
      this.sizer.add( this.feedbackLabel );

      this.windowTitle = "Flat Strength";
      this.updateHeader();
      this.syncSlider();
      this.updateK();
      this.adjustToContents();

      this.timer = new Timer;
      this.timer.interval = 0.15;
      this.timer.periodic = false;
      this.timer.onTimeout = function() { self.renderNow(); };

      this.onShow = function() { self.scheduleRender( true ); };
      this.onHide = function() { self.timer.stop(); };
   }

   updateHeader()
   {
      let name = File.extractNameAndExtension( this.ctx.lightPath );
      this.headerLabel.text = "<b>Session:</b> " + this.session.name + " &nbsp; <b>File:</b> " + name +
                              ( this.ctx.isCFA ? " &nbsp; (CFA " + this.ctx.pattern + ")" : " &nbsp; (mono)" ) +
                              ( this.ctx.flatPath ? "" : " &nbsp; <b>No master flat: only strength -1 is shown.</b>" );
   }

   updateK()
   {
      if ( this.cw )
      {
         this.kLabel.text = "k = " + this.sRGB.map( v => ( 1 + v ).toFixed( 2 ) ).join( "/" );
         this.rgbLabel.text = pswFormatTriple( this.sRGB );
      }
      else
      {
         this.kLabel.text = "k = " + ( 1 + this.s ).toFixed( 2 );
         this.rgbLabel.text = "";
      }
   }

   // v5: effective triple of a light for channel-wise editing (frame triple, session triple
   // or [s, s, s] from the scalar session strength).
   loadTriple( index )
   {
      let ses = this.session;
      return PSWEngine.effectiveStrengthRGB( ses.lights[ index ],
                                             { src: ses, channelWise: true, isCFA: true, strengthRGB: ses.strengthRGB } );
   }

   // v5: 0/1/2 for the R/G/B channel view, -1 for All.
   channelIndex()
   {
      return this.ctx.isCFA ? this.channelCombo.currentItem - 1 : -1;
   }

   // v5: "all", "R", "G" or "B" for the engine.
   viewChannel()
   {
      let ci = this.channelIndex();
      return ci < 0 ? "all" : "RGB".charAt( ci );
   }

   // v5: slider value for the current mode and channel view.
   syncSlider()
   {
      if ( !this.cw )
         this.strengthControl.setValue( this.s );
      else
      {
         let ci = this.channelIndex();
         this.strengthControl.setValue( this.sRGB[ ci >= 0 ? ci : 1 ] );
      }
   }

   // v5: strength passed to the engine: the triple in channel-wise mode, else the scalar.
   currentStrength()
   {
      return this.cw ? this.sRGB.slice() : this.s;
   }

   strengthText()
   {
      return this.cw ? pswFormatTriple( this.sRGB ) : pswFormatStrength( this.s );
   }

   feedback( text )
   {
      this.feedbackLabel.text = text;
   }

   scheduleRender( now )
   {
      this.timer.stop();
      if ( now )
         this.timer.interval = 0.01;
      else
         this.timer.interval = 0.15;
      this.timer.start();
   }

   switchLight( index )
   {
      if ( this.busy || index == this.ctx.lightIndex )
      {
         this.lightCombo.currentItem = this.ctx.lightIndex;
         return;
      }
      this.busy = true;
      this.cursor = new Cursor( StdCursor.Hourglass );
      try
      {
         // Same session: keep master flat, Fmax, reduced dark/flat and F_k means.
         PSWEngine.switchPreviewLight( this.ctx, this.session.lights[ index ].path, index );
         this.beforeCache = {};
         this.lockCheck.checked = false;
         this.frozen = null;
         this.bitmap = null;
         this.updateHeader();
      }
      catch ( e )
      {
         this.lightCombo.currentItem = this.ctx.lightIndex;
         pswMessage( "Cannot switch the preview:\n" + ( e.message || e ), StdIcon.Error );
      }
      finally
      {
         this.cursor = new Cursor( StdCursor.Arrow );
         this.busy = false;
      }
      this.scheduleRender( true );
   }

   // Stretch options for computeStretch: unlinked flag, and the CFA pattern for the gray mosaic.
   // v5 channel view (ch = "R"/"G"/"B"): a 1-channel image, so its own auto stretch
   // (Linked and Unlinked are the same for one channel).
   stretchOpts( debayer, ch )
   {
      let chView = ch && ch != "all";
      return { unlinked: this.stretchCombo.enabled && this.stretchCombo.currentItem == 1,
               pattern: ( this.ctx.isCFA && !debayer && !chView ) ? this.ctx.pattern : "" };
   }

   // v5: lock / Before cache key: (debayer | stretch mode | channel view).
   viewKey( debayer, so, ch )
   {
      return ( ch && ch != "all" ? "ch" + ch : ( debayer ? "deb" : "mos" ) ) + "|" + ( so.unlinked ? "unlinked" : "linked" );
   }

   // Before image (cached per debayer mode and stretch mode): { bmp, st }. The engine's
   // cached Before window is stretched directly (no copy) and is not closed here.
   getBefore( debayer, maxSize, ch )
   {
      let so = this.stretchOpts( debayer, ch );
      let key = this.viewKey( debayer, so, ch );
      if ( this.beforeCache[ key ] && this.beforeCache[ key ].maxSize == maxSize )
         return this.beforeCache[ key ];
      let w = PSWEngine.previewBeforeWindow( this.ctx, { debayer: debayer, maxSize: maxSize, channel: ch } );
      let st = PSWEngine.computeStretch( w, so );
      let bmp = PSWEngine.stretchedBitmap( this.ctx, w, st );
      this.beforeCache[ key ] = { bmp: bmp, st: st, w: w.mainView.image.width, h: w.mainView.image.height, maxSize: maxSize };
      return this.beforeCache[ key ];
   }

   renderNow()
   {
      if ( this.busy )
      {
         this.pending = true;
         return;
      }
      this.busy = true;
      this.pending = false;
      let t0 = Date.now();
      let debayer = this.debayerCheck.checked;
      let maxSize = this.params.previewMaxSize;
      let ch = this.viewChannel();
      let chView = ch != "all";
      try
      {
         let size = "";
         if ( this.beforeRadio.checked )
         {
            let b = this.getBefore( debayer, maxSize, ch );
            this.bitmap = b.bmp;
            size = b.w + "x" + b.h;
         }
         else
         {
            // Cached by the engine per (strength, debayer, size): a stretch-mode or lock
            // change only re-stretches. The window belongs to ctx: do not close it here.
            let w = PSWEngine.previewAfterWindow( this.ctx, this.currentStrength(), { debayer: debayer, maxSize: maxSize, channel: ch } );
            let so = this.stretchOpts( debayer, ch );
            let st;
            if ( this.lockCheck.checked )
            {
               // Frozen per (debayer, stretch mode, channel): a mode, debayer or channel change
               // while locked freezes a new set from the current After image.
               let key = this.viewKey( debayer, so, ch );
               if ( !this.frozen || this.frozen.key != key )
                  this.frozen = { key: key, st: PSWEngine.computeStretch( w, so ) };
               st = this.frozen.st;
            }
            else
               st = PSWEngine.computeStretch( w, so );
            this.bitmap = PSWEngine.stretchedBitmap( this.ctx, w, st );
            size = w.mainView.image.width + "x" + w.mainView.image.height;
         }
         this.lastRenderMs = Date.now() - t0;
         let afterText = "After, strength " + ( this.cw && chView ? ch + " " + pswFormatStrength( this.sRGB[ "RGB".indexOf( ch ) ] )
                                                                  : this.strengthText() );
         this.statusLabel.text = ( chView ? "Channel " + ch + " (bin2) " + size : "Preview " + size ) +
                                 ", reduction 1:" + PSWEngine.previewFactor( this.ctx, debayer, chView ) +
                                 ( this.ctx.isCFA && !chView ? ( debayer ? ", SuperPixel debayer" : ", gray mosaic" ) : "" ) +
                                 ", " + ( this.beforeRadio.checked ? "Before" : afterText ) +
                                 ( chView ? ", own channel stretch" :
                                   ( this.stretchCombo.enabled ? ", " + ( this.stretchOpts( debayer, ch ).unlinked ? "unlinked" : "linked" ) + " stretch" : "" ) ) +
                                 ( this.lockCheck.checked && !this.beforeRadio.checked ? ", stretch locked" : "" ) +
                                 ", " + this.lastRenderMs + " ms";
      }
      catch ( e )
      {
         this.statusLabel.text = "Preview error: " + ( e.message || e );
         console.criticalln( "*** Preview error: " + ( e.message || e ) );
      }
      finally
      {
         this.busy = false;
      }
      this.previewControl.update();
      if ( this.pending )
         this.scheduleRender();
   }
};

// ----------------------------------------------------------------------------
// Main dialog
// ----------------------------------------------------------------------------

var PSWDialog = class extends Dialog
{
   constructor( params, parent )
   {
      super( parent );
      PSWParameters.defaults( params );
      this.params = params;
      let self = this;
      this.updating = false;

      let labelWidth = this.font.width( "Master dark flat:" ) + this.font.width( 'M' );

      this.helpLabel = new Label( this );
      this.helpLabel.frameStyle = FrameStyle.Box;
      this.helpLabel.margin = 6;
      this.helpLabel.wordWrapping = true;
      this.helpLabel.useRichText = true;
      // The branded header already shows the title, so the help text does not repeat it.
      let help = "Calibrate lights with per-session master dark and flats. Flat strength 0 = standard calibration.";
      this.helpLabel.text = PSW_BRANDED ? "<p>" + help + "</p>" : "<p><b>" + PSW_TITLE + "</b> &mdash; " + help + "</p>";

      // ---------------------------------------------------------- sessions list
      this.sessionTree = new TreeBox( this );
      this.sessionTree.numberOfColumns = 1;
      this.sessionTree.headerVisible = false;
      this.sessionTree.rootDecoration = false;
      this.sessionTree.alternateRowColor = true;
      this.sessionTree.setScaledMinSize( 170, 200 );
      this.sessionTree.toolTip = "<p>Calibration sessions: each has lights, flats, master dark and master dark flat.</p>";
      this.sessionTree.onCurrentNodeUpdated = function() { if ( !self.updating ) self.updateSessionPanel(); };

      this.addSessionButton = new PushButton( this );
      this.addSessionButton.text = "Add session";
      this.addSessionButton.onClick = function()
      {
         let n = self.params.sessions.length;
         let s = PSWParameters.newSession( n );
         let names = self.params.sessions.map( x => PSWEngine.safeName( x.name ).toLowerCase() );
         let i = n + 1;
         while ( names.indexOf( PSWEngine.safeName( s.name ).toLowerCase() ) >= 0 )
            s.name = "Session " + ( ++i );
         self.params.sessions.push( s );
         self.refreshSessions( n );
      };

      this.removeSessionButton = new PushButton( this );
      this.removeSessionButton.text = "Remove session";
      this.removeSessionButton.onClick = function()
      {
         let i = self.currentSessionIndex();
         if ( i < 0 )
            return;
         self.params.sessions.splice( i, 1 );
         self.refreshSessions( Math.min( i, self.params.sessions.length - 1 ) );
      };

      this.renameButton = new PushButton( this );
      this.renameButton.text = "Rename";
      this.renameButton.toolTip = "<p>Rename the selected session using the Name field.</p>";
      this.renameButton.onClick = function() { self.applyName(); };

      this.sessionButtons = new VerticalSizer;
      this.sessionButtons.spacing = 4;
      this.sessionButtons.add( this.addSessionButton );
      this.sessionButtons.add( this.removeSessionButton );
      this.sessionButtons.add( this.renameButton );

      this.leftSizer = new VerticalSizer;
      this.leftSizer.spacing = 6;
      this.leftSizer.add( this.sessionTree, 100 );
      this.leftSizer.add( this.sessionButtons );

      // ---------------------------------------------------------- session panel
      this.panel = new Control( this );

      this.nameEdit = new Edit( this.panel );
      this.nameEdit.toolTip = "<p>Session name; used in output folder and master flat file names.</p>";
      this.nameEdit.onEditCompleted = function() { self.applyName(); };
      this.nameSizer = this.labeledRow( this.panel, "Name:", labelWidth, this.nameEdit );

      // Lights
      this.lightsTree = new TreeBox( this.panel );
      this.lightsTree.numberOfColumns = 2;
      this.lightsTree.headerVisible = true;
      this.lightsTree.setHeaderText( 0, "File" );
      this.lightsTree.setHeaderText( 1, "Strength" );
      this.lightsTree.setHeaderAlignment( 1, TextAlignment.Center );
      this.lightsTree.rootDecoration = false;
      this.lightsTree.alternateRowColor = true;
      this.lightsTree.multipleSelection = true;
      this.lightsTree.setScaledMinSize( 460, 170 );
      this.lightsTree.toolTip = "<p>Light frames. Strength '-' means the session value; other values are frame overrides.</p>";

      this.addLightsButton = this.button( this.panel, "Add lights...", "<p>Add light frames (XISF/FITS).</p>", function()
      {
         let files = self.pickFiles( "Select light frames", true );
         let s = self.currentSession();
         if ( !s || files.length == 0 )
            return;
         let have = {};
         s.lights.forEach( l => { have[ l.path ] = true; } );
         files.forEach( f => { if ( !have[ f ] ) s.lights.push( { path: f, strength: null } ); } );
         self.updateSessionPanel();
      } );
      this.removeLightsButton = this.button( this.panel, "Remove selected", "<p>Remove the selected light frames.</p>", function()
      {
         let s = self.currentSession();
         if ( !s )
            return;
         let sel = self.selectedLightIndices();
         s.lights = s.lights.filter( ( l, i ) => sel.indexOf( i ) < 0 );
         self.updateSessionPanel();
      } );
      this.clearLightsButton = this.button( this.panel, "Clear", "<p>Remove all light frames of this session.</p>", function()
      {
         let s = self.currentSession();
         if ( s )
         {
            s.lights = [];
            self.updateSessionPanel();
         }
      } );
      this.lightsSizer = this.listBlock( "Lights", this.lightsTree, [ this.addLightsButton, this.removeLightsButton, this.clearLightsButton ] );

      // Flats
      this.flatsTree = new TreeBox( this.panel );
      this.flatsTree.numberOfColumns = 1;
      this.flatsTree.headerVisible = false;
      this.flatsTree.rootDecoration = false;
      this.flatsTree.alternateRowColor = true;
      this.flatsTree.multipleSelection = true;
      this.flatsTree.setScaledMinSize( 460, 110 );
      this.flatsTree.toolTip = "<p>Flat frames of this session.</p>";

      this.addFlatsButton = this.button( this.panel, "Add flats...", "<p>Add flat frames (XISF/FITS).</p>", function()
      {
         let files = self.pickFiles( "Select flat frames", true );
         let s = self.currentSession();
         if ( !s || files.length == 0 )
            return;
         files.forEach( f => { if ( s.flats.indexOf( f ) < 0 ) s.flats.push( f ); } );
         self.updateSessionPanel();
      } );
      this.removeFlatsButton = this.button( this.panel, "Remove selected", "<p>Remove the selected flat frames.</p>", function()
      {
         let s = self.currentSession();
         if ( !s )
            return;
         let sel = [];
         for ( let i = 0; i < self.flatsTree.numberOfChildren; ++i )
            if ( self.flatsTree.child( i ).selected )
               sel.push( i );
         s.flats = s.flats.filter( ( f, i ) => sel.indexOf( i ) < 0 );
         self.updateSessionPanel();
      } );
      this.clearFlatsButton = this.button( this.panel, "Clear", "<p>Remove all flat frames of this session.</p>", function()
      {
         let s = self.currentSession();
         if ( s )
         {
            s.flats = [];
            self.updateSessionPanel();
         }
      } );
      this.flatsSizer = this.listBlock( "Flats", this.flatsTree, [ this.addFlatsButton, this.removeFlatsButton, this.clearFlatsButton ] );

      // Master files
      this.darkEdit = new Edit( this.panel );
      this.darkEdit.toolTip = "<p>Master dark for the lights (bias-calibrated). Empty = the shared master dark.</p>";
      this.darkEdit.onEditCompleted = function() { let s = self.currentSession(); if ( s ) { s.masterDark = this.text.trim(); self.updateState(); } };
      this.darkButton = new ToolButton( this.panel );
      this.darkButton.icon = this.scaledResource( ":/icons/select-file.png" );
      this.darkButton.setScaledFixedSize( 22, 22 );
      this.darkButton.toolTip = "<p>Select the master dark.</p>";
      this.darkButton.onClick = function()
      {
         let f = self.pickFiles( "Select master dark", false );
         let s = self.currentSession();
         if ( s && f.length > 0 )
         {
            s.masterDark = f[ 0 ];
            self.updateSessionPanel();
         }
      };
      this.darkSizer = this.labeledRow( this.panel, "Master dark:", labelWidth, this.darkEdit, this.darkButton );
      this.darkHint = this.hintLabel( this.panel );

      this.darkFlatEdit = new Edit( this.panel );
      this.darkFlatEdit.toolTip = "<p>Master dark for the flats. Empty = the shared master dark flat.</p>";
      this.darkFlatEdit.onEditCompleted = function() { let s = self.currentSession(); if ( s ) { s.masterDarkFlat = this.text.trim(); self.updateState(); } };
      this.darkFlatButton = new ToolButton( this.panel );
      this.darkFlatButton.icon = this.scaledResource( ":/icons/select-file.png" );
      this.darkFlatButton.setScaledFixedSize( 22, 22 );
      this.darkFlatButton.toolTip = "<p>Select the master dark flat.</p>";
      this.darkFlatButton.onClick = function()
      {
         let f = self.pickFiles( "Select master dark flat", false );
         let s = self.currentSession();
         if ( s && f.length > 0 )
         {
            s.masterDarkFlat = f[ 0 ];
            self.updateSessionPanel();
         }
      };
      this.darkFlatSizer = this.labeledRow( this.panel, "Master dark flat:", labelWidth, this.darkFlatEdit, this.darkFlatButton );
      this.darkFlatHint = this.hintLabel( this.panel );

      // v5: per-session output folder (used when 'Use shared output folder' is off)
      this.sesOutEdit = new Edit( this.panel );
      this.sesOutEdit.toolTip = "<p>Output folder of this session (calibrated/, masters/, temp/). Used only when " +
                                "'Use shared output folder for all sessions' is off; empty = the shared folder.</p>";
      this.sesOutEdit.onEditCompleted = function() { let s = self.currentSession(); if ( s ) { s.outputDir = this.text.trim(); self.updateSessionPanel(); } };
      this.sesOutButton = new ToolButton( this.panel );
      this.sesOutButton.icon = this.scaledResource( ":/icons/select-file.png" );
      this.sesOutButton.setScaledFixedSize( 22, 22 );
      this.sesOutButton.toolTip = "<p>Select the output folder of this session.</p>";
      this.sesOutButton.onClick = function()
      {
         let s = self.currentSession();
         if ( !s )
            return;
         let d = new GetDirectoryDialog;
         d.caption = "Select session output folder";
         d.initialPath = s.outputDir || self.params.outputDir || self.params.lastDir;
         if ( d.execute() )
         {
            s.outputDir = d.directoryPath;
            self.updateSessionPanel();
         }
      };
      this.sesOutSizer = this.labeledRow( this.panel, "Output folder:", labelWidth, this.sesOutEdit, this.sesOutButton );
      this.sesOutHint = this.hintLabel( this.panel );

      // CFA
      this.cfaModeCombo = new ComboBox( this.panel );
      [ "Auto", "Mono", "CFA" ].forEach( t => this.cfaModeCombo.addItem( t ) );
      this.cfaModeCombo.toolTip = "<p>Treat frames as mono or CFA mosaics. Auto reads the Bayer keyword.</p>";
      this.cfaModeCombo.onItemSelected = function( i )
      {
         let s = self.currentSession();
         if ( s )
         {
            s.cfaMode = [ "auto", "mono", "cfa" ][ i ];
            self.updateSessionPanel();   // channel-wise availability and labels
         }
      };
      this.cfaPatternCombo = new ComboBox( this.panel );
      [ "Auto", "RGGB", "BGGR", "GBRG", "GRBG" ].forEach( t => this.cfaPatternCombo.addItem( t ) );
      this.cfaPatternCombo.toolTip = "<p>Bayer pattern; auto reads it from the file.</p>";
      this.cfaPatternCombo.onItemSelected = function( i )
      {
         let s = self.currentSession();
         if ( s )
            s.cfaPattern = i == 0 ? "auto" : self.cfaPatternCombo.itemText( i );
      };
      let patLabel = new Label( this.panel );
      patLabel.text = "Pattern:";
      patLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.cwCheck = new CheckBox( this.panel );
      this.cwCheck.text = "Channel-wise (CFA)";
      this.cwCheck.toolTip = "<p>Set the flat strength separately for red, green and blue pixels of the Bayer mosaic. " +
                             "No debayering: each colour is calibrated with its own flat strength. CFA frames only.</p>";
      this.cwCheck.onCheck = function( checked )
      {
         let s = self.currentSession();
         if ( s )
         {
            pswSetChannelWise( s, checked );
            self.updateSessionPanel();
         }
      };
      this.cfaSizer = this.labeledRow( this.panel, "CFA:", labelWidth, this.cfaModeCombo, patLabel, this.cfaPatternCombo );
      this.cfaSizer.addSpacing( 16 );
      this.cfaSizer.add( this.cwCheck );
      this.cfaSizer.addStretch();

      // Strength
      this.strengthLabel = new Label( this.panel );
      this.strengthLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
      this.strengthLabel.useRichText = true;
      this.strengthButton = this.button( this.panel, "Flat Strength...",
         "<p>Open the preview for the selected session (and the selected light, if any) to choose the flat strength.</p>",
         function() { self.openPreview(); } );
      this.resetStrengthButton = this.button( this.panel, "Reset session to 0",
         "<p>Set the session strength to 0 (scalar and channel-wise) and clear all frame overrides.</p>", function()
      {
         let s = self.currentSession();
         if ( s )
         {
            s.strength = 0;
            if ( s.strengthRGB )
               s.strengthRGB = [ 0, 0, 0 ];
            s.lights.forEach( l => { l.strength = null; l.strengthRGB = null; } );
            self.updateSessionPanel();
         }
      } );
      this.strengthSizer = new HorizontalSizer;
      this.strengthSizer.spacing = 6;
      this.strengthSizer.add( this.strengthLabel );
      this.strengthSizer.addStretch();
      this.strengthSizer.add( this.strengthButton );
      this.strengthSizer.add( this.resetStrengthButton );

      this.panel.sizer = new VerticalSizer;
      this.panel.sizer.spacing = 6;
      this.panel.sizer.add( this.nameSizer );
      this.panel.sizer.add( this.lightsSizer, 100 );
      this.panel.sizer.add( this.flatsSizer, 60 );
      this.panel.sizer.add( this.darkSizer );
      this.panel.sizer.add( this.darkHint );
      this.panel.sizer.add( this.darkFlatSizer );
      this.panel.sizer.add( this.darkFlatHint );
      this.panel.sizer.add( this.sesOutSizer );
      this.panel.sizer.add( this.sesOutHint );
      this.panel.sizer.add( this.cfaSizer );
      this.panel.sizer.add( this.strengthSizer );

      // ---------------------------------------------------------- shared masters (v5)
      const sharedTip = "<p>Used by every session whose own field is empty.</p>";
      this.sharedDarkEdit = new Edit( this );
      this.sharedDarkEdit.text = params.sharedMasterDark;
      this.sharedDarkEdit.toolTip = "<p>Shared master dark. " + sharedTip.substr( 3 );
      this.sharedDarkEdit.onEditCompleted = function() { self.params.sharedMasterDark = this.text.trim(); self.updateSessionPanel(); };
      this.sharedDarkButton = new ToolButton( this );
      this.sharedDarkButton.icon = this.scaledResource( ":/icons/select-file.png" );
      this.sharedDarkButton.setScaledFixedSize( 22, 22 );
      this.sharedDarkButton.toolTip = "<p>Select the shared master dark.</p>";
      this.sharedDarkButton.onClick = function()
      {
         let f = self.pickFiles( "Select shared master dark", false );
         if ( f.length > 0 )
         {
            self.params.sharedMasterDark = f[ 0 ];
            self.sharedDarkEdit.text = f[ 0 ];
            self.updateSessionPanel();
         }
      };
      this.sharedDarkSizer = this.labeledRow( this, "Master dark:", labelWidth, this.sharedDarkEdit, this.sharedDarkButton );

      this.sharedDarkFlatEdit = new Edit( this );
      this.sharedDarkFlatEdit.text = params.sharedMasterDarkFlat;
      this.sharedDarkFlatEdit.toolTip = "<p>Shared master dark flat. " + sharedTip.substr( 3 );
      this.sharedDarkFlatEdit.onEditCompleted = function() { self.params.sharedMasterDarkFlat = this.text.trim(); self.updateSessionPanel(); };
      this.sharedDarkFlatButton = new ToolButton( this );
      this.sharedDarkFlatButton.icon = this.scaledResource( ":/icons/select-file.png" );
      this.sharedDarkFlatButton.setScaledFixedSize( 22, 22 );
      this.sharedDarkFlatButton.toolTip = "<p>Select the shared master dark flat.</p>";
      this.sharedDarkFlatButton.onClick = function()
      {
         let f = self.pickFiles( "Select shared master dark flat", false );
         if ( f.length > 0 )
         {
            self.params.sharedMasterDarkFlat = f[ 0 ];
            self.sharedDarkFlatEdit.text = f[ 0 ];
            self.updateSessionPanel();
         }
      };
      this.sharedDarkFlatSizer = this.labeledRow( this, "Master dark flat:", labelWidth, this.sharedDarkFlatEdit, this.sharedDarkFlatButton );

      this.sharedGroup = new GroupBox( this );
      this.sharedGroup.title = "Shared masters (a session's own file overrides)";
      this.sharedGroup.sizer = new VerticalSizer;
      this.sharedGroup.sizer.margin = 6;
      this.sharedGroup.sizer.spacing = 4;
      this.sharedGroup.sizer.add( this.sharedDarkSizer );
      this.sharedGroup.sizer.add( this.sharedDarkFlatSizer );

      this.sessionsGroup = new GroupBox( this );
      this.sessionsGroup.title = "Sessions";
      this.sessionsGroup.sizer = new HorizontalSizer;
      this.sessionsGroup.sizer.margin = 6;
      this.sessionsGroup.sizer.spacing = 8;
      this.sessionsGroup.sizer.add( this.leftSizer );
      this.sessionsGroup.sizer.add( this.panel, 100 );

      // ---------------------------------------------------------- output
      this.outEdit = new Edit( this );
      this.outEdit.text = params.outputDir;
      this.outEdit.toolTip = "<p>Shared output folder for all sessions: calibrated lights (calibrated/), master flats (masters/) and temporary files (temp/).</p>";
      this.outEdit.onEditCompleted = function() { self.params.outputDir = this.text.trim(); self.updateState(); };
      this.outButton = new ToolButton( this );
      this.outButton.icon = this.scaledResource( ":/icons/select-file.png" );
      this.outButton.setScaledFixedSize( 22, 22 );
      this.outButton.toolTip = "<p>Select the output folder.</p>";
      this.outButton.onClick = function()
      {
         let d = new GetDirectoryDialog;
         d.caption = "Select output folder";
         d.initialPath = self.params.outputDir || self.params.lastDir;
         if ( d.execute() )
         {
            self.params.outputDir = d.directoryPath;
            self.outEdit.text = d.directoryPath;
            self.updateState();
         }
      };
      this.outSizer = this.labeledRow( this, "Output folder:", labelWidth, this.outEdit, this.outButton );

      this.sharedOutCheck = new CheckBox( this );
      this.sharedOutCheck.text = "Use shared output folder for all sessions";
      this.sharedOutCheck.checked = !!params.useSharedOutput;
      this.sharedOutCheck.toolTip = "<p>On: every session writes into the shared output folder. Off: each session writes into " +
                                    "its own output folder (empty = the shared folder).</p>";
      this.sharedOutCheck.onCheck = function( c ) { self.params.useSharedOutput = c; self.updateSessionPanel(); };
      this.sharedOutSizer = new HorizontalSizer;
      this.sharedOutSizer.addSpacing( labelWidth + 6 );
      this.sharedOutSizer.add( this.sharedOutCheck );
      this.sharedOutSizer.addStretch();

      this.subLabel = new Label( this );
      this.subLabel.text = "Writes calibrated lights to calibrated/<session>/, master flats to masters/ and temporary files to temp/ (removed after the run).";

      this.keepCheck = new CheckBox( this );
      this.keepCheck.text = "Keep intermediates";
      this.keepCheck.checked = !!params.keepIntermediates;
      this.keepCheck.toolTip = "<p>Keep calibrated flats and derived flats in temp/ after the run.</p>";
      this.keepCheck.onCheck = function( c ) { self.params.keepIntermediates = c; };

      this.reuseCheck = new CheckBox( this );
      this.reuseCheck.text = "Reuse existing masters";
      this.reuseCheck.checked = !!params.reuseMasters;
      this.reuseCheck.toolTip = "<p>Reuse an existing master flat in masters/ if its inputs have not changed.</p>";
      this.reuseCheck.onCheck = function( c ) { self.params.reuseMasters = c; };

      this.checksSizer = new HorizontalSizer;
      this.checksSizer.spacing = 16;
      this.checksSizer.addSpacing( labelWidth + 6 );
      this.checksSizer.add( this.keepCheck );
      this.checksSizer.add( this.reuseCheck );
      this.checksSizer.addStretch();

      this.outputGroup = new GroupBox( this );
      this.outputGroup.title = "Output";
      this.outputGroup.sizer = new VerticalSizer;
      this.outputGroup.sizer.margin = 6;
      this.outputGroup.sizer.spacing = 4;
      this.outputGroup.sizer.add( this.outSizer );
      this.outputGroup.sizer.add( this.sharedOutSizer );
      this.outputGroup.sizer.add( this.subLabel );
      this.outputGroup.sizer.add( this.checksSizer );

      // ---------------------------------------------------------- advanced
      this.advControl = new Control( this );
      this.optDarkCheck = new CheckBox( this.advControl );
      this.optDarkCheck.text = "Optimize master dark";
      this.optDarkCheck.checked = !!params.optimizeDark;
      this.optDarkCheck.toolTip = "<p>Let ImageCalibration scale the master dark for the lights. Leave off when dark and " +
                                  "lights share exposure and temperature.</p>";
      this.optDarkCheck.onCheck = function( c ) { self.params.optimizeDark = c; };

      this.pedCombo = new ComboBox( this.advControl );
      [ "Auto", "None", "Literal" ].forEach( t => this.pedCombo.addItem( t ) );
      this.pedCombo.currentItem = Math.max( 0, [ "auto", "none", "literal" ].indexOf( params.pedestalMode ) );
      this.pedCombo.toolTip = "<p>Output pedestal for calibrated lights: Auto adds a pedestal only if values would go negative.</p>";
      this.pedCombo.onItemSelected = function( i )
      {
         self.params.pedestalMode = [ "auto", "none", "literal" ][ i ];
         self.pedSpin.enabled = i == 2;
      };
      this.pedSpin = new SpinBox( this.advControl );
      this.pedSpin.minValue = 0;
      this.pedSpin.maxValue = 1000;
      this.pedSpin.value = params.pedestal;
      this.pedSpin.enabled = params.pedestalMode == "literal";
      this.pedSpin.toolTip = "<p>Literal output pedestal in DN (16-bit units).</p>";
      this.pedSpin.onValueUpdated = function( v ) { self.params.pedestal = v; };
      let dnLabel = new Label( this.advControl );
      dnLabel.text = "DN";
      dnLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
      this.pedSizer = this.labeledRow( this.advControl, "Output pedestal:", labelWidth, this.pedCombo, this.pedSpin, dnLabel );
      this.pedSizer.addStretch();

      this.rejCombo = new ComboBox( this.advControl );
      [ "Auto", "None", "Percentile", "Winsorized sigma", "ESD" ].forEach( t => this.rejCombo.addItem( t ) );
      this.rejCombo.currentItem = Math.max( 0, [ "auto", "none", "percentile", "winsorized", "esd" ].indexOf( params.flatRejection ) );
      this.rejCombo.toolTip = "<p>Pixel rejection used when integrating flats. Auto chooses by frame count " +
                              "(&lt;3 none, 3-7 percentile, 8-19 Winsorized sigma, 20+ ESD).</p>";
      this.rejCombo.onItemSelected = function( i ) { self.params.flatRejection = [ "auto", "none", "percentile", "winsorized", "esd" ][ i ]; };
      this.rejSizer = this.labeledRow( this.advControl, "Flat rejection:", labelWidth, this.rejCombo );
      this.rejSizer.addStretch();

      let optSizer = new HorizontalSizer;
      optSizer.addSpacing( labelWidth + 6 );
      optSizer.add( this.optDarkCheck );
      optSizer.addStretch();

      this.advControl.sizer = new VerticalSizer;
      this.advControl.sizer.spacing = 4;
      this.advControl.sizer.add( optSizer );
      this.advControl.sizer.add( this.pedSizer );
      this.advControl.sizer.add( this.rejSizer );

      this.advBar = new SectionBar( this, "Advanced" );
      this.advBar.setSection( this.advControl );
      this.advBar.onToggleSection = function( bar, toggleBegin )
      {
         if ( !toggleBegin )
            self.adjustToContents();
      };
      this.advControl.hide();

      // ---------------------------------------------------------- bottom
      this.statusLabel = new Label( this );
      this.statusLabel.text = "Ready.";

      this.helpButton = this.button( this, "Help", "<p>How to use this script.</p>", function() { self.showHelp(); } );
      this.saveListButton = this.button( this, "Save list...", "<p>Save the session list to a JSON file.</p>", function() { self.saveList(); } );
      this.loadListButton = this.button( this, "Load list...", "<p>Load a session list from a JSON file.</p>", function() { self.loadList(); } );
      this.calibrateButton = this.button( this, "Calibrate", "<p>Calibrate all sessions.</p>", function() { self.calibrate(); } );
      this.calibrateButton.icon = this.scaledResource( ":/icons/power.png" );
      this.closeButton = this.button( this, "Close", "<p>Close the dialog (settings are kept).</p>", function() { self.ok(); } );
      this.closeButton.icon = this.scaledResource( ":/icons/close.png" );

      this.buttonsSizer = new HorizontalSizer;
      this.buttonsSizer.spacing = 6;
      this.buttonsSizer.add( this.helpButton );
      this.buttonsSizer.add( this.saveListButton );
      this.buttonsSizer.add( this.loadListButton );
      this.buttonsSizer.addStretch();
      this.buttonsSizer.add( this.calibrateButton );
      this.buttonsSizer.add( this.closeButton );

      this.bodySizer = new VerticalSizer;
      this.bodySizer.margin = 8;
      this.bodySizer.spacing = 8;
      this.bodySizer.add( this.helpLabel );
      this.bodySizer.add( this.sharedGroup );
      this.bodySizer.add( this.sessionsGroup, 100 );
      this.bodySizer.add( this.outputGroup );
      this.bodySizer.add( this.advBar );
      this.bodySizer.add( this.advControl );
      this.bodySizer.add( this.statusLabel );
      this.bodySizer.add( this.buttonsSizer );

      this.header = PSW_BRANDED ? new PSWHeader( this ) : null;
      this.sizer = new VerticalSizer;
      this.sizer.margin = 0;
      this.sizer.spacing = 0;
      if ( this.header != null )
         this.sizer.add( this.header );
      this.sizer.add( this.bodySizer, 100 );

      this.windowTitle = PSW_TITLE;
      this.refreshSessions( 0 );
      this.adjustToContents();
      this.setScaledMinWidth( 760 );
   }

   // ---------------------------------------------------------- layout helpers

   button( parent, text, tip, onClick )
   {
      let b = new PushButton( parent );
      b.text = text;
      b.toolTip = tip;
      b.onClick = onClick;
      return b;
   }

   hintLabel( parent )
   {
      let l = new Label( parent );
      l.text = "";
      l.useRichText = false;
      l.styleSheet = "QLabel { color: #888888; }";
      l.visible = false;
      return l;
   }

   // v5: grey hint under a session field: shown only when the field is empty.
   setHint( label, text )
   {
      label.text = text;
      label.visible = !!( text && text.length > 0 );
   }

   // v5: effective values of a session (own value, else shared / shared output policy).
   effDark( s ) { return PSWEngine.sessionDark( s, this.params ); }
   effDarkFlat( s ) { return PSWEngine.sessionDarkFlat( s, this.params ); }
   effOutDir( s ) { return PSWEngine.sessionOutputDir( s, this.params ); }

   labeledRow( parent, text, width )
   {
      let l = new Label( parent );
      l.text = text;
      l.minWidth = width;
      l.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      let s = new HorizontalSizer;
      s.spacing = 6;
      s.add( l );
      for ( let i = 3; i < arguments.length; ++i )
         s.add( arguments[ i ], i == 3 ? 100 : 0 );
      return s;
   }

   listBlock( title, tree, buttons )
   {
      let l = new Label( this.panel );
      l.text = title;
      l.useRichText = false;
      let bs = new VerticalSizer;
      bs.spacing = 4;
      buttons.forEach( b => bs.add( b ) );
      bs.addStretch();
      let hs = new HorizontalSizer;
      hs.spacing = 6;
      hs.add( tree, 100 );
      hs.add( bs );
      let vs = new VerticalSizer;
      vs.spacing = 2;
      vs.add( l );
      vs.add( hs, 100 );
      return vs;
   }

   pickFiles( caption, multiple )
   {
      let d = new OpenFileDialog;
      d.caption = caption;
      d.multipleSelections = multiple;
      d.filters = PSW_FILE_FILTERS;
      if ( this.params.lastDir && File.directoryExists( this.params.lastDir ) )
         d.initialPath = this.params.lastDir;
      if ( !d.execute() )
         return [];
      let files = multiple ? d.fileNames : [ d.fileName ];
      if ( files.length > 0 )
         this.params.lastDir = File.extractDrive( files[ 0 ] ) + File.extractDirectory( files[ 0 ] );
      return files;
   }

   // ---------------------------------------------------------- state

   currentSessionIndex()
   {
      let n = this.sessionTree.currentNode;
      if ( !n )
         return -1;
      let i = this.sessionTree.childIndex( n );
      return ( i >= 0 && i < this.params.sessions.length ) ? i : -1;
   }

   currentSession()
   {
      let i = this.currentSessionIndex();
      return i >= 0 ? this.params.sessions[ i ] : null;
   }

   selectedLightIndices()
   {
      let sel = [];
      for ( let i = 0; i < this.lightsTree.numberOfChildren; ++i )
         if ( this.lightsTree.child( i ).selected )
            sel.push( i );
      return sel;
   }

   refreshSessions( select )
   {
      this.updating = true;
      try
      {
         this.sessionTree.clear();
         this.params.sessions.forEach( ( s, i ) =>
         {
            PSWParameters.sessionDefaults( s, i );
            let node = new TreeBoxNode( this.sessionTree );
            node.setText( 0, s.name );
         } );
         if ( this.params.sessions.length > 0 )
         {
            let i = Math.max( 0, Math.min( this.params.sessions.length - 1, select || 0 ) );
            this.sessionTree.currentNode = this.sessionTree.child( i );
            this.sessionTree.child( i ).selected = true;
         }
      }
      finally
      {
         this.updating = false;
      }
      this.updateSessionPanel();
   }

   applyName()
   {
      let i = this.currentSessionIndex();
      if ( i < 0 )
         return;
      let name = this.nameEdit.text.trim();
      if ( name.length == 0 )
      {
         this.nameEdit.text = this.params.sessions[ i ].name;
         return;
      }
      let safe = PSWEngine.safeName( name ).toLowerCase();
      for ( let j = 0; j < this.params.sessions.length; ++j )
         if ( j != i && PSWEngine.safeName( this.params.sessions[ j ].name ).toLowerCase() == safe )
         {
            pswMessage( "Another session already uses this name.", StdIcon.Warning );
            this.nameEdit.text = this.params.sessions[ i ].name;
            return;
         }
      this.params.sessions[ i ].name = name;
      this.sessionTree.child( i ).setText( 0, name );
   }

   updateSessionPanel()
   {
      let s = this.currentSession();
      this.panel.enabled = s != null;
      this.removeSessionButton.enabled = s != null;
      this.renameButton.enabled = s != null;
      if ( !s )
      {
         this.lightsTree.clear();
         this.flatsTree.clear();
         this.nameEdit.text = "";
         this.darkEdit.text = "";
         this.darkFlatEdit.text = "";
         this.strengthLabel.text = "Session strength: +0.00";
         this.cwCheck.checked = false;
         this.updateState();
         return;
      }
      this.nameEdit.text = s.name;
      // v5: channel-wise availability. A session that resolves to mono shows the box
      // unchecked and disabled, but its channelWise flag is kept (validation reports it).
      let isCFA = pswSessionIsCFA( s );
      let cw = isCFA && !!s.channelWise;
      this.cwCheck.enabled = isCFA;
      this.cwCheck.checked = cw;
      let overrides = 0;
      let setStrength = ( node, l ) =>
      {
         let t = cw ? PSWEngine.strengthTriple( l.strengthRGB ) : null;
         if ( cw ? !t : ( l.strength === null || l.strength === undefined || l.strength === "" ) )
         {
            node.setText( 1, "-" );
            node.setTextColor( 1, node.textColor( 0 ) );
         }
         else
         {
            ++overrides;
            node.setText( 1, cw ? pswFormatTriple( t, true ) : pswFormatStrength( PSWEngine.normStrength( l.strength ) ) );
            node.setTextColor( 1, 0xff2060e0 );
         }
      };
      let T = this.lightsTree;
      let same = T.numberOfChildren == s.lights.length;
      for ( let i = 0; same && i < s.lights.length; ++i )
         if ( T.child( i ).toolTip( 0 ) != s.lights[ i ].path )
            same = false;
      if ( same )
      {
         // Same list (e.g. after Apply): update the strength column in place, so
         // selection and scroll position stay and nothing flickers.
         for ( let i = 0; i < s.lights.length; ++i )
            setStrength( T.child( i ), s.lights[ i ] );
      }
      else
      {
         // Rebuild, keeping the selected paths and the current row in view.
         let selPaths = {};
         for ( let i = 0; i < T.numberOfChildren; ++i )
            if ( T.child( i ).selected )
               selPaths[ T.child( i ).toolTip( 0 ) ] = true;
         let cur = T.currentNode ? T.currentNode.toolTip( 0 ) : "";
         T.enabled = false;
         T.clear();
         let curNode = null;
         s.lights.forEach( l =>
         {
            let node = new TreeBoxNode( T );
            node.setText( 0, File.extractNameAndExtension( l.path ) );
            node.setToolTip( 0, l.path );
            node.setAlignment( 1, TextAlignment.Center );
            setStrength( node, l );
            if ( selPaths[ l.path ] )
               node.selected = true;
            if ( l.path == cur )
               curNode = node;
         } );
         if ( curNode )
         {
            T.currentNode = curNode;
            T.setNodeIntoView( curNode );
         }
         T.adjustColumnWidthToContents( 0 );
         T.adjustColumnWidthToContents( 1 );
         T.enabled = true;
      }
      let F = this.flatsTree;
      let sameF = F.numberOfChildren == s.flats.length;
      for ( let i = 0; sameF && i < s.flats.length; ++i )
         if ( F.child( i ).toolTip( 0 ) != s.flats[ i ] )
            sameF = false;
      if ( !sameF )
      {
         F.clear();
         s.flats.forEach( f =>
         {
            let node = new TreeBoxNode( F );
            node.setText( 0, File.extractNameAndExtension( f ) );
            node.setToolTip( 0, f );
         } );
      }
      this.darkEdit.text = s.masterDark;
      this.darkFlatEdit.text = s.masterDarkFlat;
      this.setHint( this.darkHint, ( !s.masterDark && this.params.sharedMasterDark ) ?
                    "Using shared: " + File.extractNameAndExtension( this.params.sharedMasterDark ) : "" );
      this.setHint( this.darkFlatHint, ( !s.masterDarkFlat && this.params.sharedMasterDarkFlat ) ?
                    "Using shared: " + File.extractNameAndExtension( this.params.sharedMasterDarkFlat ) : "" );
      this.sesOutEdit.text = s.outputDir;
      this.sesOutEdit.enabled = this.sesOutButton.enabled = !this.params.useSharedOutput;
      this.setHint( this.sesOutHint, ( this.params.useSharedOutput || !s.outputDir ) ?
                    "Using shared output folder" : "" );
      this.cfaModeCombo.currentItem = Math.max( 0, [ "auto", "mono", "cfa" ].indexOf( String( s.cfaMode ).toLowerCase() ) );
      let pi = [ "AUTO", "RGGB", "BGGR", "GBRG", "GRBG" ].indexOf( String( s.cfaPattern ).toUpperCase() );
      this.cfaPatternCombo.currentItem = Math.max( 0, pi );
      let sesTriple = PSWEngine.strengthTriple( s.strengthRGB );
      if ( !sesTriple )
      {
         let v = PSWEngine.normStrength( s.strength );
         sesTriple = [ v, v, v ];
      }
      this.strengthLabel.text = "Session strength: <b>" +
                                ( cw ? pswFormatTriple( sesTriple ) : pswFormatStrength( PSWEngine.normStrength( s.strength ) ) ) + "</b>" +
                                " &nbsp; (" + s.lights.length + " lights, " + overrides + " frame override(s), " +
                                s.flats.length + " flats)";
      this.updateState();
   }

   updateState()
   {
      let s = this.currentSession();
      let effOut = s ? this.effOutDir( s ) : "";
      let hasOut = !!( effOut && File.directoryExists( effOut ) );
      let canPreview = !!( s != null && hasOut && s.lights.length > 0 && this.effDark( s ) != "" );
      this.strengthButton.enabled = canPreview;
      if ( !hasOut )
         this.strengthButton.toolTip = "<p>Set the output folder first: the preview builds the master flat there.</p>";
      else if ( !canPreview )
         this.strengthButton.toolTip = "<p>Add lights and a master dark (and flats with a master dark flat) first.</p>";
      else
         this.strengthButton.toolTip = "<p>Open the preview for the selected session (and the selected light, if any) to choose the flat strength.</p>";
   }

   // ---------------------------------------------------------- actions

   openPreview()
   {
      let si = this.currentSessionIndex();
      if ( si < 0 )
         return;
      let s = this.params.sessions[ si ];
      let effOut = this.effOutDir( s );
      if ( !effOut || !File.directoryExists( effOut ) )
      {
         pswMessage( "Please set an existing output folder first (for this session or the shared one): the preview builds the master flat there.", StdIcon.Warning );
         return;
      }
      // Validate this session as the preview needs it (flats and dark flat required),
      // so size mismatches, missing files or an unknown CFA pattern give a clear message.
      let probe = {};
      for ( let key in this.params )
         probe[ key ] = this.params[ key ];
      let sc = {};
      for ( let key in s )
         sc[ key ] = s[ key ];
      sc.strength = 0;
      sc.channelWise = false;   // the preview itself is checked like a v2 session (flats required)
      sc.strengthRGB = null;
      sc.lights = s.lights.map( l => ( { path: l.path, strength: null, strengthRGB: null } ) );
      sc.flats = s.flats.slice();
      probe.sessions = [ sc ];
      this.cursor = new Cursor( StdCursor.Hourglass );
      let verr = PSWEngine.validate( probe );
      this.cursor = new Cursor( StdCursor.Arrow );
      if ( verr.length > 0 )
      {
         pswMessage( "The preview cannot be opened:\n\n" + verr.join( "\n" ), StdIcon.Error );
         return;
      }
      let sel = this.selectedLightIndices();
      let li = sel.length > 0 ? sel[ 0 ] : 0;
      let ctx = null;
      this.statusLabel.text = "Preparing the preview (building the master flat if needed)...";
      this.cursor = new Cursor( StdCursor.Hourglass );
      try
      {
         console.show();
         ctx = PSWEngine.preparePreview( s, li, this.params );
      }
      catch ( e )
      {
         this.cursor = new Cursor( StdCursor.Arrow );
         this.statusLabel.text = "Preview failed.";
         pswMessage( "Cannot open the preview:\n" + ( e.message || e ), StdIcon.Error );
         return;
      }
      this.cursor = new Cursor( StdCursor.Arrow );
      this.statusLabel.text = "Ready.";
      let dlg = new PSWPreviewDialog( this.params, si, ctx, sel, this );
      dlg.mainDialog = this;
      try
      {
         dlg.execute();
      }
      finally
      {
         dlg.timer.stop();
         PSWEngine.closePreview( dlg.ctx );
      }
      this.updateSessionPanel();
   }

   calibrate()
   {
      let errors = PSWEngine.validate( this.params );
      if ( errors.length > 0 )
      {
         pswMessage( "Please fix the following problems:\n\n" + errors.join( "\n" ), StdIcon.Error );
         return;
      }
      if ( errors.warnings.length > 0 )
      {
         let r = ( new MessageBox( "Warnings:\n\n" + errors.warnings.join( "\n" ) + "\n\nContinue?", PSW_TITLE,
                                   StdIcon.Warning, StdButton.Yes, StdButton.No ) ).execute();
         if ( r != StdButton.Yes )
            return;
      }
      this.params.save();
      console.show();
      this.enabled = false;
      this.statusLabel.text = "Calibrating... (use the Process Console Abort button to stop)";
      let R = null;
      try
      {
         R = PSWEngine.run( null, this.params, errors );   // already validated: no second header pass
      }
      catch ( e )
      {
         console.criticalln( "*** " + ( e.message || e ) );
         pswMessage( "Calibration failed:\n" + ( e.message || e ), StdIcon.Error );
      }
      finally
      {
         this.enabled = true;
      }
      if ( R )
      {
         let msg = ( R.aborted ? "Aborted.\n\n" : "Done.\n\n" ) +
                   R.lightsOk + " light(s) calibrated, " + R.lightsFailed + " failed.\n" +
                   R.icRuns + " ImageCalibration run(s), " + R.masterFlatsBuilt + " master flat(s) built, " +
                   R.derivedFlatsBuilt + " derived flat(s).\n" + format( "Time: %.1f s", R.seconds ) +
                   ( R.failed.length > 0 ? "\n\nFailed:\n" + R.failed.slice( 0, 10 ).join( "\n" ) : "" ) +
                   "\n\nOutput:\n" + this.params.sessions.map( q => q.name + ": " + PSWEngine.sessionOutputDir( q, this.params ) +
                                                                      "/calibrated/" + PSWEngine.safeName( q.name ) ).join( "\n" );
         this.statusLabel.text = format( "Last run: %d calibrated, %d failed, %.1f s", R.lightsOk, R.lightsFailed, R.seconds );
         pswMessage( msg, R.lightsFailed > 0 || R.aborted ? StdIcon.Warning : StdIcon.Information );
      }
      else
         this.statusLabel.text = "Last run failed.";
   }

   saveList()
   {
      let d = new SaveFileDialog;
      d.caption = "Save session list";
      d.filters = [ [ "JSON files", "*.json" ] ];
      if ( this.params.lastDir )
         d.initialPath = this.params.lastDir + "/sessions.json";
      if ( !d.execute() )
         return;
      try
      {
         File.writeTextFile( d.filePath, JSON.stringify( {
            version: PSW_VERSION,
            sharedMasterDark: this.params.sharedMasterDark,
            sharedMasterDarkFlat: this.params.sharedMasterDarkFlat,
            useSharedOutput: this.params.useSharedOutput,
            sessions: this.params.sessions }, null, 1 ) );
      }
      catch ( e )
      {
         pswMessage( "Cannot save the list:\n" + ( e.message || e ), StdIcon.Error );
      }
   }

   loadList()
   {
      let d = new OpenFileDialog;
      d.caption = "Load session list";
      d.filters = [ [ "JSON files", "*.json" ] ];
      if ( this.params.lastDir && File.directoryExists( this.params.lastDir ) )
         d.initialPath = this.params.lastDir;
      if ( !d.execute() )
         return;
      try
      {
         let j = JSON.parse( File.readTextFile( d.fileName ) );
         let sessions = Array.isArray( j ) ? j : j.sessions;
         if ( !Array.isArray( sessions ) )
            throw new Error( "No session list in this file." );
         sessions.forEach( ( s, i ) => PSWParameters.sessionDefaults( s, i ) );
         this.params.sessions = sessions;
         if ( !Array.isArray( j ) )
         {
            if ( typeof j.sharedMasterDark == "string" ) this.params.sharedMasterDark = j.sharedMasterDark;
            if ( typeof j.sharedMasterDarkFlat == "string" ) this.params.sharedMasterDarkFlat = j.sharedMasterDarkFlat;
            if ( typeof j.useSharedOutput == "boolean" ) this.params.useSharedOutput = j.useSharedOutput;
            this.sharedDarkEdit.text = this.params.sharedMasterDark;
            this.sharedDarkFlatEdit.text = this.params.sharedMasterDarkFlat;
            this.sharedOutCheck.checked = !!this.params.useSharedOutput;
         }
         this.refreshSessions( 0 );
      }
      catch ( e )
      {
         pswMessage( "Cannot load the list:\n" + ( e.message || e ), StdIcon.Error );
      }
   }

   showHelp()
   {
      pswMessage(
         "Flat Strength Calibration calibrates light frames with a master dark and a master flat per session, " +
         "without WBPP, and lets you choose how strongly the flat is applied.\n\n" +
         "1. Add a session per night/optical setup. Add its lights, flats, the master dark for the lights and the " +
         "master dark for the flats (both already bias-calibrated).\n" +
         "Shared masters: set a master dark and/or master dark flat once; every session whose own field is empty uses them, a session's own file overrides.\n" +
         "2. Choose an output folder; untick 'Use shared output folder for all sessions' to give each session its own folder (empty = the shared one). The master flat is built in masters/, calibrated lights go to " +
         "calibrated/<session>/ as 32-bit XISF. CFA data stay CFA (not debayered).\n" +
         "3. Optional: 'Flat Strength...' opens a before/after preview. Strength 0 is the standard calibration, " +
         "-1 applies no flat, +1 applies the flat twice (exponent k = 1 + s). Apply the value to one frame, the " +
         "selected frames or the whole session.\n" +
         "4. Press Calibrate. Lights are grouped by strength: one ImageCalibration run per distinct strength.\n\n" +
         "The preview is auto-stretched for display only: Stretch 'Unlinked' (default) stretches each colour on its own " +
         "and removes the colour cast of raw OSC data, 'Linked' uses one stretch for all colours. In the gray mosaic " +
         "(debayer off) the preview is binned per CFA colour, so each pixel keeps its colour and the unlinked stretch " +
         "works per CFA colour. 'Lock stretch' freezes the stretch of the current After image, so moving the " +
         "strength slider shows the real brightness and vignetting change; Before always uses its own stretch. " +
         "In the preview, 'Channel' R, G or B shows a bin2 image built only from the pixels of that colour " +
         "(G = mean of the two green pixels).\n\n" +
         "Channel-wise calibration (CFA only): tick 'Channel-wise (CFA)' in the session (or 'Channel-wise' in the " +
         "preview) to set the flat strength separately for the red, green and blue pixels, e.g. when the flats do not " +
         "match the lights equally well in every colour. Nothing is debayered and no extra files are written: one " +
         "derived flat with a per-colour exponent is used, so ImageCalibration applies each colour's own strength in a " +
         "single run and the output stays a CFA mosaic. In the preview, the R, G or B view edits that colour only; the " +
         "All view moves the three strengths together and keeps their differences. Turning channel-wise off keeps the " +
         "per-colour values stored but calibrates with the single strength again.\n\n" +
         "The mosaic mode keeps two full-size images " +
         "in memory, four while loading (about 210 to 420 MB for 26 MP); the debayered preview stays below about 150 MB.\n" +
         "Abort a running calibration with the Process Console Abort button." );
   }
};
