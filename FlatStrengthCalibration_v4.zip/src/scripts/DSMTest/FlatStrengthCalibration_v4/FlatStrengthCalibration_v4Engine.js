// FlatStrengthCalibration_v4Engine.js - processing logic, no GUI objects allowed here.
//
// Contract used by the GUI and by the headless test harness:
//   new PSWParameters()            -> object with defaults, .load(), .save()
//   PSWParameters.defaults( [p] )  -> fills missing fields of a plain params object
//   PSWEngine.run( view, params )  -> calibrates every session (view is ignored),
//                                     returns an object with numbers worth logging
//
// Math (see spec section 4):
//   L_cal = (L - D) * mean(n^k) / n^k,   k = 1 + s,  n = normalised master flat.
//   k = 1 -> the original master flat is passed to ImageCalibration (plain calibration)
//   k = 0 -> no flat at all (dark only)
//   other -> derived flat F_k = (max(Fm,eps)/Fmax)^k, normalised again by ImageCalibration.
//   v4 channel-wise (CFA): k_c per CFA colour; the derived flat takes the exponent of each
//   pixel's colour (parity map from the session pattern) and ImageCalibration's per-CFA-channel
//   flat scaling normalises each colour separately, so colour c gets exactly the v2 result at s_c.

// Input/output format hints copied from WBPP (BPP-Processing.js).
var PSW_HINTS_IN  = "fits-keywords normalize only-first-image raw cfa use-roworder-keywords signed-is-physical";
var PSW_HINTS_OUT = "properties fits-keywords no-compress-data block-alignment 4096 max-inline-block-size 3072 no-embedded-data no-resolution";

// CFA pattern names in the ImageCalibration / Debayer enumeration order.
var PSW_CFA_PATTERNS = [ "Auto", "RGGB", "BGGR", "GBRG", "GRBG", "GRGB", "GBGR", "RGBG", "BGRG" ];

var PSWParameters = class
{
   constructor()
   {
      let d = PSWParameters.defaults();
      for ( let key in d )
         this[ key ] = d[ key ];
   }

   // Without argument: a fresh object holding the documented defaults.
   // With a (plain) object: missing fields are filled in place and the object is returned.
   static defaults( p )
   {
      let d = {
         sessions: [],
         outputDir: "",
         sharedMasterDark: "",       // v4: used by every session whose own dark is empty
         sharedMasterDarkFlat: "",
         useSharedOutput: true,      // v4: true = outputDir for all sessions, false = per-session folders
         keepIntermediates: false,
         reuseMasters: true,
         optimizeDark: false,
         pedestalMode: "auto",
         pedestal: 0,
         flatRejection: "auto",
         previewMaxSize: 1400,
         previewStretchMode: "unlinked",   // preview display stretch: "linked" or "unlinked"
         lastDir: ""
      };
      if ( p === undefined || p === null )
         return d;
      for ( let key in d )
         if ( p[ key ] === undefined || p[ key ] === null )
            p[ key ] = d[ key ];
      for ( let i = 0; i < p.sessions.length; ++i )
         PSWParameters.sessionDefaults( p.sessions[ i ], i );
      return p;
   }

   static newSession( index )
   {
      return PSWParameters.sessionDefaults( {}, index );
   }

   static sessionDefaults( s, index )
   {
      if ( s.name === undefined || s.name === null || String( s.name ).trim().length == 0 )
         s.name = "Session " + ( ( index || 0 ) + 1 );
      if ( !s.lights ) s.lights = [];
      // Accept plain path strings for lights.
      for ( let i = 0; i < s.lights.length; ++i )
         if ( typeof s.lights[ i ] == "string" )
            s.lights[ i ] = { path: s.lights[ i ], strength: null, strengthRGB: null };
         else
         {
            if ( s.lights[ i ].strength === undefined )
               s.lights[ i ].strength = null;
            if ( s.lights[ i ].strengthRGB === undefined )
               s.lights[ i ].strengthRGB = null;
         }
      if ( !s.flats ) s.flats = [];
      if ( !s.masterDark ) s.masterDark = "";
      if ( !s.masterDarkFlat ) s.masterDarkFlat = "";
      if ( !s.outputDir ) s.outputDir = "";   // v4: per-session output folder
      if ( s.strength === undefined || s.strength === null ) s.strength = 0;
      if ( !s.cfaMode ) s.cfaMode = "auto";
      if ( !s.cfaPattern ) s.cfaPattern = "auto";
      // v4: channel-wise (per CFA colour) strengths; the scalar fields above stay untouched.
      if ( s.channelWise === undefined || s.channelWise === null ) s.channelWise = false;
      if ( s.strengthRGB === undefined ) s.strengthRGB = null;
      return s;
   }

   load()
   {
      const K = PSW_SETTINGS + "/";
      let v;
      v = Settings.read( K + "outputDir", DataType.String );         if ( Settings.lastReadOK ) this.outputDir = v;
      v = Settings.read( K + "sharedMasterDark", DataType.String );  if ( Settings.lastReadOK ) this.sharedMasterDark = v;
      v = Settings.read( K + "sharedMasterDarkFlat", DataType.String ); if ( Settings.lastReadOK ) this.sharedMasterDarkFlat = v;
      v = Settings.read( K + "useSharedOutput", DataType.Boolean );  if ( Settings.lastReadOK ) this.useSharedOutput = v;
      v = Settings.read( K + "lastDir", DataType.String );           if ( Settings.lastReadOK ) this.lastDir = v;
      v = Settings.read( K + "keepIntermediates", DataType.Boolean ); if ( Settings.lastReadOK ) this.keepIntermediates = v;
      v = Settings.read( K + "reuseMasters", DataType.Boolean );     if ( Settings.lastReadOK ) this.reuseMasters = v;
      v = Settings.read( K + "optimizeDark", DataType.Boolean );     if ( Settings.lastReadOK ) this.optimizeDark = v;
      v = Settings.read( K + "pedestalMode", DataType.String );      if ( Settings.lastReadOK && [ "auto", "none", "literal" ].indexOf( v ) >= 0 ) this.pedestalMode = v;
      v = Settings.read( K + "pedestal", DataType.Int32 );           if ( Settings.lastReadOK ) this.pedestal = Math.max( 0, Math.min( 1000, v ) );
      v = Settings.read( K + "flatRejection", DataType.String );     if ( Settings.lastReadOK && [ "auto", "none", "percentile", "winsorized", "esd" ].indexOf( v ) >= 0 ) this.flatRejection = v;
      v = Settings.read( K + "previewMaxSize", DataType.Int32 );     if ( Settings.lastReadOK ) this.previewMaxSize = Math.max( 400, Math.min( 4000, v ) );
      v = Settings.read( K + "previewStretchMode", DataType.String ); if ( Settings.lastReadOK && [ "linked", "unlinked" ].indexOf( v ) >= 0 ) this.previewStretchMode = v;
   }

   save()
   {
      const K = PSW_SETTINGS + "/";
      Settings.write( K + "outputDir", DataType.String, this.outputDir );
      Settings.write( K + "sharedMasterDark", DataType.String, this.sharedMasterDark );
      Settings.write( K + "sharedMasterDarkFlat", DataType.String, this.sharedMasterDarkFlat );
      Settings.write( K + "useSharedOutput", DataType.Boolean, this.useSharedOutput );
      Settings.write( K + "lastDir", DataType.String, this.lastDir );
      Settings.write( K + "keepIntermediates", DataType.Boolean, this.keepIntermediates );
      Settings.write( K + "reuseMasters", DataType.Boolean, this.reuseMasters );
      Settings.write( K + "optimizeDark", DataType.Boolean, this.optimizeDark );
      Settings.write( K + "pedestalMode", DataType.String, this.pedestalMode );
      Settings.write( K + "pedestal", DataType.Int32, this.pedestal );
      Settings.write( K + "flatRejection", DataType.String, this.flatRejection );
      Settings.write( K + "previewMaxSize", DataType.Int32, this.previewMaxSize );
      Settings.write( K + "previewStretchMode", DataType.String, this.previewStretchMode );
   }
};

var PSWEngine = {

   _idCounter: 0,
   _derivedCache: {},   // derived flat path -> "<master path|size|mtime>|<kk>" it was built from
   _masterCache: {},    // master flat path -> { signature, stamp, stats } built/verified in this script session

   // Error thrown when the user aborts; run() turns it into { aborted: true }.
   abortError: function()
   {
      let e = new Error( "Aborted by the user." );
      e.pswAbort = true;
      return e;
   },

   // Runs a process globally; converts a user abort (throw or false) into abortError().
   execGlobal: function( P, what )
   {
      let ok = false;
      try
      {
         ok = P.executeGlobal();
      }
      catch ( e )
      {
         if ( console.abortRequested )
            throw this.abortError();
         throw e;
      }
      if ( !ok && console.abortRequested )
         throw this.abortError();
      if ( !ok )
         throw new Error( what + " failed." );
      return ok;
   },

   // ---------------------------------------------------------------- small helpers

   uniqueId: function( prefix )
   {
      ++this._idCounter;
      return "FSC_" + prefix + "_" + this._idCounter;
   },

   // NaN -> 0, clamp to [-1,1], round to 0.01.
   normStrength: function( s )
   {
      let v = Number( s );
      if ( s === null || s === "" || !isFinite( v ) )
         v = 0;
      v = Math.max( -1, Math.min( 1, v ) );
      return Math.round( v*100 )/100;
   },

   // Strength of one light: per-frame override or the session value.
   effectiveStrength: function( light, session )
   {
      if ( light.strength !== null && light.strength !== undefined && light.strength !== "" )
         return this.normStrength( light.strength );
      return this.normStrength( session.strength );
   },

   // v4: a valid [sR, sG, sB] triple (normalised copy) or null.
   strengthTriple: function( t )
   {
      if ( !t || !Array.isArray( t ) || t.length != 3 )
         return null;
      return t.map( v => this.normStrength( v ) );
   },

   // v4: per-CFA-colour strengths [sR, sG, sB] of one light. 'rs' is a resolved session
   // (or any object with channelWise, isCFA, strengthRGB and src/strength).
   //   channel-wise CFA: light.strengthRGB || session.strengthRGB || [s, s, s] (s = session scalar)
   //   otherwise:        [e, e, e] with e = effectiveStrength (v2)
   effectiveStrengthRGB: function( light, rs )
   {
      let src = rs.src || rs;
      if ( rs.channelWise && rs.isCFA )
      {
         let t = this.strengthTriple( light.strengthRGB ) || this.strengthTriple( rs.strengthRGB );
         if ( t )
            return t;
         let s = this.normStrength( src.strength );
         return [ s, s, s ];
      }
      let e = this.effectiveStrength( light, src );
      return [ e, e, e ];
   },

   // v4: a number s or a triple -> normalised triple.
   toTriple: function( s )
   {
      if ( Array.isArray( s ) )
         return this.strengthTriple( s ) || [ 0, 0, 0 ];
      let v = this.normStrength( s );
      return [ v, v, v ];
   },

   // k = 1 + s rounded to 0.01 (v2 formula).
   strengthToK: function( s )
   {
      return Math.round( ( 1 + s )*100 )/100;
   },

   isEqualTriple: function( t )
   {
      return t[ 0 ] === t[ 1 ] && t[ 1 ] === t[ 2 ];
   },

   kKey: function( k )
   {
      if ( Array.isArray( k ) )
         return "R" + k[ 0 ].toFixed( 2 ) + "_G" + k[ 1 ].toFixed( 2 ) + "_B" + k[ 2 ].toFixed( 2 );
      return k.toFixed( 2 );
   },

   // v4: the four k values of a CFA pattern in parity order (y%2)*2 + x%2, from [kR, kG, kB].
   // Same convention as the mosaic preview and the unlinked CFA stretch.
   parityValues: function( pattern, v )
   {
      return [ 0, 1, 2, 3 ].map( i => v[ "RGB".indexOf( pattern.charAt( i ) ) ] );
   },

   // PixelMath symbols kPowR, kPowG, kPowB for a k triple.
   kSymbols: function( k )
   {
      return "kPowR=" + k[ 0 ].toFixed( 2 ) + ", kPowG=" + k[ 1 ].toFixed( 2 ) + ", kPowB=" + k[ 2 ].toFixed( 2 );
   },

   // PixelMath iif selecting one of four strings by pixel parity.
   parityIif: function( v4 )
   {
      return "iif(y()%2==0, iif(x()%2==0," + v4[ 0 ] + "," + v4[ 1 ] + "), iif(x()%2==0," + v4[ 2 ] + "," + v4[ 3 ] + "))";
   },

   safeName: function( name )
   {
      return String( name ).trim().replace( /[^A-Za-z0-9_.-]/g, "_" );
   },

   ensureDir: function( dir )
   {
      if ( !File.directoryExists( dir ) )
         File.createDirectory( dir, true );
      return dir;
   },

   fileStamp: function( path )
   {
      let fi = new FileInfo( path );
      if ( !fi.exists )
         return [ path, -1, 0 ];
      return [ path, fi.size, fi.lastModified.getTime() ];
   },

   isDirEmpty: function( dir )
   {
      let ff = new FileFind;
      let empty = true;
      if ( ff.begin( dir + "/" + "*" ) )
      {
         do
         {
            if ( ff.name != "." && ff.name != ".." )
            {
               empty = false;
               break;
            }
         }
         while ( ff.next() );
      }
      ff.end();
      return empty;
   },

   removeDirIfEmpty: function( dir )
   {
      try
      {
         if ( File.directoryExists( dir ) && this.isDirEmpty( dir ) )
            File.removeDirectory( dir );
      }
      catch ( e )
      {
         console.warningln( "** Could not remove folder " + dir + ": " + e );
      }
   },

   removeFiles: function( paths )
   {
      for ( let i = 0; i < paths.length; ++i )
         try
         {
            if ( paths[ i ] && File.exists( paths[ i ] ) )
               File.remove( paths[ i ] );
         }
         catch ( e )
         {
            console.warningln( "** Could not remove " + paths[ i ] + ": " + e );
         }
   },

   // Drops derived-flat cache entries built from a given master flat.
   forgetDerived: function( masterFlatPath )
   {
      let prefix = JSON.stringify( [ masterFlatPath ] ).slice( 0, -1 );
      for ( let key in this._derivedCache )
         if ( this._derivedCache[ key ].indexOf( prefix ) == 0 )
            delete this._derivedCache[ key ];
   },

   closeWindow: function( w )
   {
      try
      {
         if ( w && !w.isNull )
            w.forceClose();
      }
      catch ( e )
      {
      }
   },

   // Header-only read: geometry, CFA pattern and exposure. Never loads pixels.
   readHeader: function( path )
   {
      let ext = File.extractExtension( path ).toLowerCase();
      let F = new FileFormat( ext, true, false );
      if ( F.isNull )
         throw new Error( "No installed file format can read '" + ext + "' files: " + path );
      let f = new FileFormatInstance( F );
      if ( f.isNull )
         throw new Error( "Unable to instantiate file format for: " + path );
      let d = f.open( path, "verbosity 0 " + PSW_HINTS_IN );
      if ( !d || d.length < 1 )
         throw new Error( "Unable to open file: " + path );
      let info = { width: d[ 0 ].width, height: d[ 0 ].height, channels: d[ 0 ].numberOfChannels,
                   pattern: "", exptime: NaN };
      try
      {
         if ( F.canStoreKeywords )
         {
            let kw = f.keywords;
            for ( let i = 0; i < kw.length; ++i )
            {
               let n = kw[ i ].name.trim().toUpperCase();
               if ( ( n == "BAYERPAT" || n == "CFAPAT" || n == "CFA-PAT" ) && !info.pattern )
                  info.pattern = kw[ i ].strippedValue.trim().toUpperCase();
               else if ( ( n == "EXPTIME" || n == "EXPOSURE" ) && isNaN( info.exptime ) )
                  info.exptime = parseFloat( kw[ i ].strippedValue );
            }
         }
         // XISF property (FITS readers do not implement image properties).
         if ( !info.pattern && ext == ".xisf" )
         {
            let v = f.readImageProperty( "PCL:CFASourcePattern" );
            if ( v )
               info.pattern = String( v ).trim().toUpperCase();
         }
      }
      finally
      {
         f.close();
      }
      if ( PSW_CFA_PATTERNS.indexOf( info.pattern ) < 1 )
         info.pattern = "";
      return info;
   },

   // Reads an image file into a hidden 32-bit float window (like WBPP readImage).
   readFloatWindow: function( path, id )
   {
      let ext = File.extractExtension( path ).toLowerCase();
      let F = new FileFormat( ext, true, false );
      if ( F.isNull )
         throw new Error( "No installed file format can read '" + ext + "' files: " + path );
      let f = new FileFormatInstance( F );
      let d = f.open( path, "verbosity 0 " + PSW_HINTS_IN );
      if ( !d || d.length < 1 )
         throw new Error( "Unable to open file: " + path );
      let w = new ImageWindow( 1, 1, 1, 32, true, false, id );
      try
      {
         let v = w.mainView;
         v.beginProcess( UndoFlag.NoSwapFile );
         let ok = f.readImage( v.image );
         if ( F.canStoreKeywords )
            w.keywords = f.keywords;
         v.endProcess();
         if ( !ok )
            throw new Error( "Unable to read file: " + path );
      }
      catch ( e )
      {
         w.forceClose();
         throw e;
      }
      finally
      {
         f.close();
      }
      return w;
   },

   // ---------------------------------------------------------------- session resolution

   // Returns a resolved copy of a session: normalised strengths, CFA mode and pattern.
   // v4: effective per-session values (own file/folder, else the shared one).
   sessionDark: function( session, params )
   {
      return session.masterDark || ( params && params.sharedMasterDark ) || "";
   },

   sessionDarkFlat: function( session, params )
   {
      return session.masterDarkFlat || ( params && params.sharedMasterDarkFlat ) || "";
   },

   sessionOutputDir: function( session, params )
   {
      if ( !params )
         return session.outputDir || "";
      if ( params.useSharedOutput === false )
         return session.outputDir || params.outputDir || "";
      return params.outputDir || "";
   },

   // A session resolved without params (old callers) gets its effective values filled in.
   withParams: function( rs, params )
   {
      if ( !rs.outputDir ) rs.outputDir = this.sessionOutputDir( rs.src, params );
      if ( !rs.masterDark ) rs.masterDark = this.sessionDark( rs.src, params );
      if ( !rs.masterDarkFlat ) rs.masterDarkFlat = this.sessionDarkFlat( rs.src, params );
      return rs;
   },

   // 'params' (v4) supplies the shared masters and the output folder policy.
   resolveSession: function( session, index, params )
   {
      PSWParameters.sessionDefaults( session, index || 0 );
      let rs = {
         src: session,
         name: String( session.name ).trim(),
         safe: this.safeName( session.name ),
         lights: [],
         flats: session.flats.slice(),
         masterDark: this.sessionDark( session, params ),
         masterDarkFlat: this.sessionDarkFlat( session, params ),
         outputDir: this.sessionOutputDir( session, params ),
         isCFA: false,
         pattern: "",
         patternEnum: 0,
         lightHdr: null,
         flatHdr: null,
         channelWise: !!session.channelWise,
         strengthRGB: this.strengthTriple( session.strengthRGB )
      };
      if ( session.lights.length > 0 && File.exists( session.lights[ 0 ].path ) )
         rs.lightHdr = this.readHeader( session.lights[ 0 ].path );
      if ( rs.flats.length > 0 && File.exists( rs.flats[ 0 ] ) )
         rs.flatHdr = this.readHeader( rs.flats[ 0 ] );

      let mode = String( session.cfaMode ).toLowerCase();
      let forced = String( session.cfaPattern ).toUpperCase();
      let filePattern = rs.lightHdr ? rs.lightHdr.pattern : "";
      if ( mode == "cfa" )
         rs.isCFA = true;
      else if ( mode == "mono" )
         rs.isCFA = false;
      else
         rs.isCFA = filePattern != "" && rs.lightHdr != null && rs.lightHdr.channels == 1;
      if ( rs.isCFA )
      {
         rs.pattern = ( forced != "AUTO" && PSW_CFA_PATTERNS.indexOf( forced ) > 0 ) ? forced : filePattern;
         rs.patternEnum = Math.max( 0, PSW_CFA_PATTERNS.indexOf( rs.pattern ) );
      }
      // Per light: sRGB = [sR, sG, sB] (equal unless channel-wise CFA); s = the v2 scalar
      // (the G value in channel-wise mode, used for the v2 CSV columns).
      rs.lights = session.lights.map( l =>
      {
         let t = this.effectiveStrengthRGB( l, rs );
         return { path: l.path, s: t[ 1 ], sRGB: t };
      } );
      rs.needsFlat = rs.lights.some( l => Math.max( l.sRGB[ 0 ], l.sRGB[ 1 ], l.sRGB[ 2 ] ) > -1 );
      return rs;
   },

   // ---------------------------------------------------------------- validation

   // Returns an array of error messages (empty when everything is fine).
   // Warnings are in the returned array's 'warnings' property, the resolved
   // sessions in 'resolved'.
   validate: function( params )
   {
      PSWParameters.defaults( params );
      let errors = [];
      let warnings = [];
      let resolved = [];
      errors.warnings = warnings;
      errors.resolved = resolved;

      if ( params.useSharedOutput !== false )
      {
         if ( !params.outputDir || String( params.outputDir ).trim().length == 0 )
            errors.push( "No output folder is set." );
         else if ( !File.directoryExists( params.outputDir ) )
            errors.push( "The output folder does not exist: " + params.outputDir );
      }

      if ( params.sessions.length == 0 )
         errors.push( "No sessions defined." );

      let names = {};
      for ( let si = 0; si < params.sessions.length; ++si )
      {
         let s = params.sessions[ si ];
         PSWParameters.sessionDefaults( s, si );
         let nErr = errors.length;
         let label = "Session '" + s.name + "': ";
         let safe = this.safeName( s.name );
         if ( safe.length == 0 )
            errors.push( "Session " + ( si + 1 ) + " has an empty name." );
         else if ( /^[\s.]+$/.test( String( s.name ) ) )
            errors.push( label + "the name must contain letters or digits (only dots/spaces is not a valid folder name)." );
         else if ( names[ safe.toLowerCase() ] )
            errors.push( label + "duplicate session name (after sanitising: " + safe + ")." );
         names[ safe.toLowerCase() ] = true;

         if ( s.lights.length == 0 )
         {
            errors.push( label + "no light frames." );
            continue;
         }
         let base = {};
         let missingLights = 0;
         for ( let i = 0; i < s.lights.length; ++i )
         {
            let p = s.lights[ i ].path;
            if ( !File.exists( p ) )
            {
               if ( ++missingLights <= 5 )
                  errors.push( label + "light frame not found: " + p );
               continue;
            }
            let b = File.extractName( p ).toLowerCase();
            if ( base[ b ] )
               errors.push( label + "two light frames share the file name '" + File.extractName( p ) +
                            "' (output names would clash): " + base[ b ] + " and " + p );
            base[ b ] = p;
         }
         if ( missingLights > 5 )
            errors.push( label + ( missingLights - 5 ) + " more light frames not found." );

         let effOut = this.sessionOutputDir( s, params );
         let effDark = this.sessionDark( s, params );
         let effDarkFlat = this.sessionDarkFlat( s, params );
         if ( params.useSharedOutput === false )
         {
            if ( !effOut || String( effOut ).trim().length == 0 )
               errors.push( label + "no output folder is set (set one for the session or a shared output folder)." );
            else if ( !File.directoryExists( effOut ) )
               errors.push( label + "the output folder does not exist: " + effOut );
         }
         if ( !effDark )
            errors.push( label + "no master dark (set one for the session or a shared master dark)." );
         else if ( !File.exists( effDark ) )
            errors.push( label + "master dark not found: " + effDark );

         // Channel-wise: a flat is needed if any colour of any light is above -1. A channel-wise
         // session that turns out mono is reported below, so assuming CFA here is safe.
         let cwProbe = { src: s, channelWise: !!s.channelWise, isCFA: true, strengthRGB: s.strengthRGB };
         let needsFlat = s.lights.some( l =>
         {
            let t = this.effectiveStrengthRGB( l, cwProbe );
            return Math.max( t[ 0 ], t[ 1 ], t[ 2 ] ) > -1;
         } );
         if ( needsFlat )
         {
            if ( s.flats.length == 0 )
               errors.push( label + "no flat frames (required unless every light is at strength -1)." );
            for ( let i = 0; i < s.flats.length; ++i )
               if ( !File.exists( s.flats[ i ] ) )
                  errors.push( label + "flat frame not found: " + s.flats[ i ] );
            if ( !effDarkFlat )
               errors.push( label + "no master dark flat (set one for the session or a shared master dark flat; required unless every light is at strength -1)." );
            else if ( !File.exists( effDarkFlat ) )
               errors.push( label + "master dark flat not found: " + effDarkFlat );
            if ( s.flats.length > 0 && s.flats.length < 3 )
               warnings.push( label + "only " + s.flats.length + " flat frame(s): no pixel rejection." );
         }
         if ( errors.length > nErr )
            continue;

         // Header checks (no pixel reads).
         let rs;
         try
         {
            rs = this.resolveSession( s, si, params );
            let L = rs.lightHdr;
            for ( let i = 1; i < rs.lights.length; ++i )
            {
               let h = this.readHeader( rs.lights[ i ].path );
               if ( h.width != L.width || h.height != L.height || h.channels != L.channels )
                  errors.push( label + "light frame size differs from the first light (" +
                               h.width + "x" + h.height + "x" + h.channels + " vs " +
                               L.width + "x" + L.height + "x" + L.channels + "): " + rs.lights[ i ].path );
            }
            if ( rs.channelWise && ( !rs.isCFA || L.channels != 1 ) )
               errors.push( label + "channel-wise calibration needs CFA (one-channel Bayer) frames." );
            let D = this.readHeader( rs.masterDark );
            if ( D.width != L.width || D.height != L.height || D.channels != L.channels )
               errors.push( label + "master dark size " + D.width + "x" + D.height + "x" + D.channels + " does not match the lights " +
                            L.width + "x" + L.height + "x" + L.channels + ": " + rs.masterDark );
            if ( rs.isCFA )
            {
               if ( L.channels != 1 )
                  errors.push( label + "CFA mode needs one-channel (mosaic) lights: " + rs.lights[ 0 ].path );
               if ( !rs.pattern )
                  errors.push( label + "CFA mode is selected but no Bayer pattern was found in the file; choose a pattern." );
               if ( D.pattern && rs.pattern && D.pattern != rs.pattern )
                  warnings.push( label + "master dark Bayer pattern " + D.pattern + " differs from " + rs.pattern + "." );
            }
            if ( rs.needsFlat && rs.flatHdr )
            {
               let F = rs.flatHdr;
               if ( F.width != L.width || F.height != L.height || F.channels != L.channels )
                  errors.push( label + "flat size " + F.width + "x" + F.height + "x" + F.channels + " does not match the lights " +
                               L.width + "x" + L.height + "x" + L.channels + ": " + rs.flats[ 0 ] );
               let DF = this.readHeader( rs.masterDarkFlat );
               if ( DF.width != F.width || DF.height != F.height || DF.channels != F.channels )
                  errors.push( label + "master dark flat size " + DF.width + "x" + DF.height + "x" + DF.channels +
                               " does not match the flats " + F.width + "x" + F.height + "x" + F.channels + ": " + rs.masterDarkFlat );
               if ( String( s.cfaMode ).toLowerCase() == "auto" )
               {
                  let flatCFA = F.pattern != "" && F.channels == 1;
                  if ( flatCFA != rs.isCFA )
                     errors.push( label + "lights are " + ( rs.isCFA ? "CFA" : "mono" ) + " but flats are " +
                                  ( flatCFA ? "CFA" : "mono" ) + " (" + rs.flats[ 0 ] + ")." );
               }
               if ( rs.isCFA && F.pattern && rs.pattern && F.pattern != rs.pattern )
                  warnings.push( label + "flat Bayer pattern " + F.pattern + " differs from the light pattern " + rs.pattern + "." );
               let e0 = F.exptime;
               for ( let i = 1; i < rs.flats.length; ++i )
               {
                  let h = this.readHeader( rs.flats[ i ] );
                  if ( h.width != F.width || h.height != F.height || h.channels != F.channels )
                     errors.push( label + "flat frame size differs from the first flat: " + rs.flats[ i ] );
                  if ( isFinite( e0 ) && isFinite( h.exptime ) && e0 > 0 && Math.abs( h.exptime - e0 )/e0 > 0.1 )
                  {
                     warnings.push( label + "flat exposure times differ by more than 10 % (" + e0 + " s vs " + h.exptime + " s)." );
                     e0 = NaN; // warn once
                  }
               }
            }
         }
         catch ( e )
         {
            errors.push( label + ( e.message || String( e ) ) );
            continue;
         }
         if ( errors.length == nErr )
            resolved.push( rs );
      }
      return errors;
   },

   // ---------------------------------------------------------------- process factories

   pedestalSetup: function( IC, params )
   {
      let mode = String( params.pedestalMode ).toLowerCase();
      if ( mode == "literal" )
      {
         // Verified: outputPedestal is in DN (16-bit units); 100 -> +100/65535.
         IC.outputPedestalMode = ImageCalibration.OutputPedestal_Literal;
         IC.outputPedestal = Math.round( Math.max( 0, Math.min( 1000, Number( params.pedestal ) || 0 ) ) );
      }
      else if ( mode == "none" )
      {
         IC.outputPedestalMode = ImageCalibration.OutputPedestal_Literal;
         IC.outputPedestal = 0;
      }
      else
      {
         IC.outputPedestalMode = ImageCalibration.OutputPedestal_Auto;
         IC.outputPedestal = 0;
         IC.autoPedestalLimit = 0.0001;
      }
   },

   newIC: function( rs, outDir )
   {
      let IC = new ImageCalibration;
      IC.enableCFA = rs.isCFA;
      if ( rs.isCFA )
         IC.cfaPattern = rs.patternEnum; // IC and Debayer share the enumeration
      IC.inputHints = PSW_HINTS_IN;
      IC.outputHints = PSW_HINTS_OUT;
      IC.masterBiasEnabled = false;
      IC.calibrateBias = false;
      IC.calibrateDark = false;
      IC.calibrateFlat = false;
      IC.evaluateNoise = false;
      IC.evaluateSignal = false;
      IC.cosmeticCorrectionLow = false;
      IC.cosmeticCorrectionHigh = false;
      IC.outputDirectory = outDir;
      IC.outputExtension = ".xisf";
      IC.outputPrefix = "";
      IC.outputPostfix = "_c";
      IC.outputSampleFormat = ImageCalibration.f32;
      IC.overwriteExistingFiles = true;
      IC.noGUIMessages = true;
      IC.generateHistoryProperties = true;
      IC.generateFITSKeywords = true;
      IC.useFileThreads = true;
      IC.fileThreadOverload = 1.0;
      return IC;
   },

   chooseRejection: function( n, mode )
   {
      let m = String( mode || "auto" ).toLowerCase();
      if ( m == "auto" )
         m = n < 3 ? "none" : ( n < 8 ? "percentile" : ( n < 20 ? "winsorized" : "esd" ) );
      if ( n < 3 )
         m = "none";
      return m;
   },

   // ---------------------------------------------------------------- master flat (4.3)

   masterFlatPaths: function( rs, params )
   {
      let dir = ( rs.outputDir || params.outputDir ) + "/masters";
      return { dir: dir, path: dir + "/" + rs.safe + "_master_flat.xisf", sidecar: dir + "/" + rs.safe + "_master_flat.json" };
   },

   buildMasterFlat: function( session, params )
   {
      PSWParameters.defaults( params );
      let rs = ( session && session.src ) ? this.withParams( session, params ) : this.resolveSession( session, 0, params );
      let t0 = Date.now();
      if ( rs.flats.length < 1 )
         throw new Error( "Session '" + rs.name + "': no flat frames." );
      if ( !rs.masterDarkFlat || !File.exists( rs.masterDarkFlat ) )
         throw new Error( "Session '" + rs.name + "': master dark flat not found: " + rs.masterDarkFlat );
      if ( !rs.outputDir || !File.directoryExists( rs.outputDir ) )
         throw new Error( "The output folder does not exist: " + rs.outputDir );
      if ( rs.flats.length < 3 )
         console.warningln( "** Session '" + rs.name + "': only " + rs.flats.length + " flat frame(s), no rejection." );

      let mp = this.masterFlatPaths( rs, params );
      let rejection = this.chooseRejection( rs.flats.length, params.flatRejection );
      let signature = JSON.stringify( {
         version: PSW_VERSION,
         flats: rs.flats.slice().sort().map( p => this.fileStamp( p ) ),
         darkFlat: this.fileStamp( rs.masterDarkFlat ),
         rejection: rejection,
         isCFA: rs.isCFA,
         pattern: rs.patternEnum
      } );

      // In-memory cache: a master built or verified in this script session, honoured
      // regardless of reuseMasters, as long as the file on disk is still the one we wrote.
      let mem = this._masterCache[ mp.path ];
      if ( mem && mem.signature === signature && File.exists( mp.path ) &&
           JSON.stringify( this.fileStamp( mp.path ) ) === mem.stamp )
      {
         console.noteln( "<end><cbr>* Session '" + rs.name + "': using master flat built in this session " + mp.path );
         return { path: mp.path, N: rs.flats.length, rejection: rejection, seconds: ( Date.now() - t0 )/1000,
                  cached: true, stats: mem.stats };
      }

      if ( params.reuseMasters && File.exists( mp.path ) && File.exists( mp.sidecar ) )
         try
         {
            let j = JSON.parse( File.readTextFile( mp.sidecar ) );
            if ( j.signature === signature && j.stats && j.stats.nonPositive !== undefined )
            {
               console.noteln( "<end><cbr>* Session '" + rs.name + "': reusing master flat " + mp.path );
               this._masterCache[ mp.path ] = { signature: signature, stamp: JSON.stringify( this.fileStamp( mp.path ) ), stats: j.stats };
               return { path: mp.path, N: rs.flats.length, rejection: rejection, seconds: ( Date.now() - t0 )/1000,
                        cached: true, stats: j.stats };
            }
         }
         catch ( e )
         {
            // Unreadable sidecar: rebuild.
         }

      console.noteln( "<end><cbr>* Session '" + rs.name + "': building master flat from " + rs.flats.length +
                      " flats (rejection: " + rejection + ")" );
      this.ensureDir( mp.dir );
      // The old master/sidecar no longer describe what will be written.
      delete this._masterCache[ mp.path ];
      this.removeFiles( [ mp.sidecar ] );
      this.forgetDerived( mp.path );
      let tempDir = this.ensureDir( rs.outputDir + "/temp/" + rs.safe + "/flats" );
      let calibrated = [];
      let win = null;
      let stats = null;
      try
      {
         // Run A: calibrate every flat with the master dark flat.
         let IC = this.newIC( rs, tempDir );
         IC.targetFrames = rs.flats.map( p => [ true, p ] );
         IC.masterDarkEnabled = true;
         IC.masterDarkPath = rs.masterDarkFlat;
         IC.masterFlatEnabled = false;
         IC.optimizeDarks = false;
         IC.separateCFAFlatScalingFactors = false;
         IC.outputPedestalMode = ImageCalibration.OutputPedestal_Literal;
         IC.outputPedestal = 0;
         IC.onError = ImageCalibration.Abort;
         this.execGlobal( IC, "ImageCalibration of the flats (session '" + rs.name + "')" );
         let od = IC.outputData;
         for ( let i = 0; i < od.length; ++i )
            if ( od[ i ][ 0 ] && File.exists( od[ i ][ 0 ] ) )
               calibrated.push( od[ i ][ 0 ] );
         if ( calibrated.length != rs.flats.length )
            throw new Error( "ImageCalibration produced " + calibrated.length + " of " + rs.flats.length + " calibrated flats." );
         if ( console.abortRequested )
            throw this.abortError();

         if ( calibrated.length == 1 )
            win = this.readFloatWindow( calibrated[ 0 ], this.uniqueId( "MF" ) );
         else
         {
            let II = new ImageIntegration;
            II.images = calibrated.map( p => [ true, p, "", "" ] );
            II.inputHints = PSW_HINTS_IN;
            II.combination = ImageIntegration.Average;
            II.weightMode = ImageIntegration.DontCare;
            II.normalization = ImageIntegration.Multiplicative;
            II.rejectionNormalization = ImageIntegration.EqualizeFluxes;
            switch ( rejection )
            {
            case "percentile":
               II.rejection = ImageIntegration.PercentileClip;
               II.pcClipLow = 0.2;
               II.pcClipHigh = 0.1;
               break;
            case "winsorized":
               II.rejection = ImageIntegration.WinsorizedSigmaClip;
               II.sigmaLow = 4;
               II.sigmaHigh = 3;
               II.winsorizationCutoff = 5;
               break;
            case "esd":
               II.rejection = ImageIntegration.Rejection_ESD;
               II.esdOutliersFraction = 0.3;
               II.esdAlpha = 0.05;
               II.esdLowRelaxation = 1.0;
               break;
            default:
               II.rejection = ImageIntegration.NoRejection;
               break;
            }
            II.evaluateSNR = false;
            II.generateRejectionMaps = false;
            II.generateIntegratedImage = true;
            II.generate64BitResult = false;
            II.generateDrizzleData = false;
            II.clipLow = true;
            II.clipHigh = true;
            II.rangeClipLow = false;
            II.rangeClipHigh = false;
            II.largeScaleClipHigh = false;
            II.largeScaleClipLow = false;
            II.subtractPedestals = false;
            II.truncateOnOutOfRange = true;
            II.useCache = false;
            II.noGUIMessages = true;
            II.showImages = false;
            II.useFileThreads = true;
            II.fileThreadOverload = 1.0;
            try
            {
               this.execGlobal( II, "ImageIntegration of the flats (session '" + rs.name + "')" );
            }
            finally
            {
               // Close anything else II may have created.
               [ II.lowRejectionMapImageId, II.highRejectionMapImageId, II.slopeMapImageId ].forEach( id =>
               {
                  if ( id )
                     this.closeWindow( ImageWindow.windowById( id ) );
               } );
            }
            win = ImageWindow.windowById( II.integrationImageId );
            if ( !win || win.isNull )
               throw new Error( "ImageIntegration produced no image (session '" + rs.name + "')." );
         }

         // Keep the Bayer pattern keyword on the master.
         if ( rs.isCFA && rs.pattern )
         {
            let kw = win.keywords;
            if ( !kw.some( k => k.name.trim().toUpperCase() == "BAYERPAT" ) )
            {
               kw.push( new FITSKeyword( "BAYERPAT", "'" + rs.pattern + "'", "Bayer pattern" ) );
               win.keywords = kw;
            }
         }

         // Statistics, computed once and stored in the sidecar.
         let img = win.mainView.image;
         stats = { mean: img.mean(), min: img.minimum(), max: img.maximum(), nonPositive: 0 };
         if ( stats.min <= 0 )
         {
            // Count pixels <= 0 (only when there are any). The master itself is NOT modified.
            let zid = this.uniqueId( "Z" );
            let ZP = new PixelMath;
            ZP.expression = "iif($T<=0,1,0)";
            ZP.useSingleExpression = true;
            ZP.createNewImage = true;
            ZP.showNewImage = false;
            ZP.newImageId = zid;
            ZP.executeOn( win.mainView, false );
            let zw = ImageWindow.windowById( zid );
            try
            {
               stats.nonPositive = Math.round( zw.mainView.image.mean()*img.width*img.height*img.numberOfChannels );
            }
            finally
            {
               this.closeWindow( zw );
            }
         }
         if ( !win.saveAs( mp.path, false, false, false, false ) )
            throw new Error( "Could not save the master flat: " + mp.path );
         File.writeTextFile( mp.sidecar, JSON.stringify( { signature: signature, stats: stats }, null, 1 ) );
         this._masterCache[ mp.path ] = { signature: signature, stamp: JSON.stringify( this.fileStamp( mp.path ) ), stats: stats };
      }
      finally
      {
         this.closeWindow( win );
         if ( !params.keepIntermediates )
         {
            this.removeFiles( calibrated );
            this.removeDirIfEmpty( tempDir );
            this.removeDirIfEmpty( rs.outputDir + "/temp/" + rs.safe );
            this.removeDirIfEmpty( rs.outputDir + "/temp" );
         }
      }

      console.writeln( format( "Master flat: mean %.5f  min %.5f  max %.5f", stats.mean, stats.min, stats.max ) );
      if ( stats.max > 0.95 )
         console.warningln( "** Warning: the master flat maximum is " + stats.max.toFixed( 4 ) + " (possible saturation)." );
      if ( stats.min <= 0 )
         console.warningln( "** Warning: the master flat has " + stats.nonPositive + " pixel(s) <= 0 (min " + stats.min.toFixed( 6 ) +
                            "); kept unchanged. Derived flats clamp them to eps; at strength 0 ImageCalibration handles them." );
      let seconds = ( Date.now() - t0 )/1000;
      console.noteln( format( "* Master flat written in %.2f s: ", seconds ) + mp.path );
      return { path: mp.path, N: rs.flats.length, rejection: rejection, seconds: seconds, cached: false, stats: stats };
   },

   // ---------------------------------------------------------------- derived flat (4.4)

   // File name of a derived flat: flat_k<k>.xisf (v2) or flat_kR<kR>_G<kG>_B<kB>.xisf (v4 triple).
   derivedFlatName: function( k )
   {
      return "flat_k" + this.kKey( k ) + ".xisf";
   },

   // Returns the path of F_k = (max(Fm,eps)/Fmax)^k. 'stats' (optional) holds Fmax.
   // v4: k may be a triple [kR, kG, kB]; then the exponent depends on the CFA colour of
   // each pixel (parity map from the resolved session pattern, the same pattern string
   // ImageCalibration gets). An equal triple is the v2 scalar flat.
   buildDerivedFlat: function( session, masterFlatPath, k, params, stats )
   {
      PSWParameters.defaults( params );
      if ( Array.isArray( k ) && this.isEqualTriple( k ) )
         k = k[ 0 ];
      let triple = Array.isArray( k );
      let kExpr = triple ? "" : k.toFixed( 2 );
      let pattern = "";
      let rsd = session.src ? this.withParams( session, params ) : this.resolveSession( session, 0, params );
      if ( triple )
      {
         pattern = rsd.pattern;
         if ( !pattern || PSW_CFA_PATTERNS.indexOf( pattern ) < 1 )
            throw new Error( "Session '" + session.name + "': a channel-wise derived flat needs a known CFA pattern." );
         kExpr = this.parityIif( this.parityValues( pattern, [ "kPowR", "kPowG", "kPowB" ] ) );
      }
      let safe = this.safeName( session.name );
      let kk = this.kKey( k ) + ( triple ? "|" + pattern : "" );
      let dir = this.ensureDir( rsd.outputDir + "/temp/derived/" + safe );
      let path = dir + "/" + this.derivedFlatName( k );
      let cacheKey = JSON.stringify( this.fileStamp( masterFlatPath ) ) + "|" + kk;
      if ( this._derivedCache[ path ] === cacheKey && File.exists( path ) )
         return path;
      // Stale or foreign file: never reuse it.
      delete this._derivedCache[ path ];
      this.removeFiles( [ path ] );

      let t0 = Date.now();
      let w = null, wk = null;
      try
      {
         let ws = ImageWindow.open( masterFlatPath, this.uniqueId( "Fm" ), PSW_HINTS_IN );
         if ( !ws || ws.length < 1 )
            throw new Error( "Cannot open the master flat: " + masterFlatPath );
         w = ws[ 0 ];
         let fmax = ( stats && stats.max > 0 ) ? stats.max : w.mainView.image.maximum();
         if ( !( fmax > 0 ) )
            throw new Error( "The master flat is empty (maximum 0): " + masterFlatPath );
         let eps = 1e-4*fmax;
         let id = this.uniqueId( "Fk" );
         let PM = new PixelMath;
         PM.useSingleExpression = true;
         if ( triple )
         {
            PM.expression = "(max($T,fEps)/fMax)^" + kExpr;
            PM.symbols = "fEps=" + eps.toPrecision( 17 ) + ", fMax=" + fmax.toPrecision( 17 ) + ", " + this.kSymbols( k );
         }
         else
         {
            PM.expression = "(max($T,fEps)/fMax)^kPow";
            PM.symbols = "fEps=" + eps.toPrecision( 17 ) + ", fMax=" + fmax.toPrecision( 17 ) + ", kPow=" + kExpr;
         }
         PM.rescale = false;
         PM.truncate = true;
         PM.generateOutput = true;
         PM.optimization = true;
         PM.use64BitWorkingImage = false;
         PM.createNewImage = true;
         PM.showNewImage = false;
         PM.newImageId = id;
         PM.newImageSampleFormat = PixelMath.SameAsTarget;
         PM.executeOn( w.mainView, false );
         wk = ImageWindow.windowById( id );
         if ( !wk || wk.isNull )
            throw new Error( "PixelMath did not create the derived flat." );
         wk.keywords = w.keywords;
         if ( !wk.saveAs( path, false, false, false, false ) )
            throw new Error( "Could not save the derived flat: " + path );
      }
      catch ( e )
      {
         this.removeFiles( [ path ] );   // no partial file left behind
         throw e;
      }
      finally
      {
         this.closeWindow( wk );
         this.closeWindow( w );
      }
      this._derivedCache[ path ] = cacheKey;
      console.writeln( format( "Derived flat k=%s written in %.2f s: ", this.kKey( k ), ( Date.now() - t0 )/1000 ) + path );
      return path;
   },

   // ---------------------------------------------------------------- main run (4.5)

   emptyResult: function()
   {
      return { sessions: 0, groups: 0, lightsOk: 0, lightsFailed: 0, masterFlatsBuilt: 0, derivedFlatsBuilt: 0,
               icRuns: 0, seconds: 0, aborted: false, done: 0, outputs: [], failed: [], timings: [] };
   },

   csvField: function( v )
   {
      return '"' + String( v ).replace( /"/g, '""' ) + '"';
   },

   // 'prevalidated' (optional): the array returned by validate( params ) just before,
   // so the GUI does not read all headers twice.
   run: function( view, params, prevalidated )
   {
      // 'view' is ignored: this script works on files.
      PSWParameters.defaults( params );
      let t0 = Date.now();
      let R = this.emptyResult();
      if ( params.sessions.length == 0 )
      {
         console.warningln( "** " + PSW_TITLE + ": no sessions defined, nothing to do." );
         return R;
      }

      let errors = ( prevalidated && prevalidated.resolved ) ? prevalidated : this.validate( params );
      errors.warnings.forEach( w => console.warningln( "** Warning: " + w ) );
      if ( errors.length > 0 )
         throw new Error( errors.join( "\n" ) );

      console.abortEnabled = true;
      let outs = {};   // distinct effective output folders (final temp cleanup)
      errors.resolved.forEach( q => { outs[ q.outputDir ] = true; } );
      try
      {
         for ( let si = 0; si < errors.resolved.length && !R.aborted; ++si )
         {
            let rs = errors.resolved[ si ];
            R.sessions++;
            let out = rs.outputDir;
            let outDir = this.ensureDir( out + "/calibrated/" + rs.safe );

            // Group lights by k (one IC run per distinct strength). v4: the key is the
            // k triple; an equal triple uses the v2 scalar key and the v2 code path.
            let groupMap = {};
            rs.lights.forEach( l =>
            {
               let kt = l.sRGB.map( v => this.strengthToK( v ) );
               let equal = this.isEqualTriple( kt );
               let k = equal ? kt[ 0 ] : kt;
               let kk = this.kKey( k );
               if ( !groupMap[ kk ] )
                  groupMap[ kk ] = { k: k, kk: kk, kG: kt[ 1 ], kRGB: kt, sRGB: l.sRGB.slice(), equal: equal, lights: [] };
               groupMap[ kk ].lights.push( l );
            } );
            let groups = Object.keys( groupMap ).map( key => groupMap[ key ] ).sort( ( a, b ) =>
               ( a.kG - b.kG ) || ( a.kk < b.kk ? -1 : ( a.kk > b.kk ? 1 : 0 ) ) );
            console.noteln( "<end><cbr><br>* Session '" + rs.name + "': " + rs.lights.length + " lights in " +
                            groups.length + " strength group(s)" + ( rs.isCFA ? ", CFA " + rs.pattern : ", mono" ) );

            let master = null;
            let csv = [ "file,session,strength,k,flat,strengthR,strengthG,strengthB,kR,kG,kB" ];
            try
            {
               for ( let gi = 0; gi < groups.length && !R.aborted; ++gi )
               {
                  CoreApplication.processEvents();
                  if ( console.abortRequested )
                  {
                     R.aborted = true;
                     break;
                  }
                  let g = groups[ gi ];
                  let flatPath = "";
                  let derived = "";
                  try
                  {
                     if ( !g.equal || g.k > 0 )
                     {
                        if ( !master )
                        {
                           master = this.buildMasterFlat( rs, params );
                           if ( !master.cached )
                              R.masterFlatsBuilt++;
                           R.timings.push( { step: rs.safe + " master flat", seconds: master.seconds } );
                        }
                        if ( g.kk == "1.00" )
                           flatPath = master.path;
                        else
                        {
                           let td = Date.now();
                           derived = this.derivedDir( out, rs ) + "/" + this.derivedFlatName( g.k ); // registered before it exists
                           flatPath = this.buildDerivedFlat( rs, master.path, g.k, params, master.stats );
                           derived = flatPath;
                           R.derivedFlatsBuilt++;
                           R.timings.push( { step: rs.safe + " derived flat k=" + g.kk, seconds: ( Date.now() - td )/1000 } );
                        }
                     }
                     if ( console.abortRequested )
                        throw this.abortError();

                     let fmtS = v => ( v >= 0 ? "+" : "" ) + v.toFixed( 2 );
                     let s = Math.round( ( g.kG - 1 )*100 )/100;
                     let sT = g.kRGB.map( v => Math.round( ( v - 1 )*100 )/100 );
                     let what = g.equal ? "strength " + fmtS( s ) + " (k = " + g.kk + ")" :
                                "strength R " + fmtS( sT[ 0 ] ) + " G " + fmtS( sT[ 1 ] ) + " B " + fmtS( sT[ 2 ] ) +
                                " (k = " + g.kRGB.map( v => v.toFixed( 2 ) ).join( "/" ) + ")";
                     console.noteln( "<end><cbr>* Session '" + rs.name + "', " + what + ": calibrating " + g.lights.length + " light(s)" +
                                     ( flatPath ? "" : " without flat" ) );
                     let tg = Date.now();
                     let IC = this.newIC( rs, outDir );
                     IC.targetFrames = g.lights.map( l => [ true, l.path ] );
                     IC.masterDarkEnabled = true;
                     IC.masterDarkPath = rs.masterDark;
                     IC.masterFlatEnabled = flatPath != "";
                     IC.masterFlatPath = flatPath;
                     IC.optimizeDarks = !!params.optimizeDark;
                     IC.separateCFAFlatScalingFactors = rs.isCFA;
                     IC.flatScaleClippingFactor = 0.05;
                     this.pedestalSetup( IC, params );
                     IC.onError = ImageCalibration.Continue;
                     let ok = false;
                     try
                     {
                        ok = IC.executeGlobal();
                     }
                     catch ( e )
                     {
                        if ( console.abortRequested )
                           throw this.abortError();
                        throw e;
                     }
                     R.icRuns++;
                     // Match outputs to lights by file name (<name>_c.xisf); unmatched = failed.
                     let byName = {};
                     let od = IC.outputData || [];
                     for ( let i = 0; i < od.length; ++i )
                        if ( od[ i ][ 0 ] && File.exists( od[ i ][ 0 ] ) )
                           byName[ File.extractName( od[ i ][ 0 ] ).toLowerCase() ] = od[ i ][ 0 ];
                     for ( let i = 0; i < g.lights.length; ++i )
                     {
                        let o = byName[ ( File.extractName( g.lights[ i ].path ) + "_c" ).toLowerCase() ];
                        if ( o )
                        {
                           R.lightsOk++;
                           R.outputs.push( o );
                           csv.push( [ this.csvField( g.lights[ i ].path ), this.csvField( rs.name ), s.toFixed( 2 ), g.kG.toFixed( 2 ),
                                       this.csvField( flatPath ? File.extractNameAndExtension( flatPath ) : "none" ) ]
                                     .concat( sT.map( v => v.toFixed( 2 ) ), g.kRGB.map( v => v.toFixed( 2 ) ) ).join( "," ) );
                        }
                        else
                        {
                           R.lightsFailed++;
                           R.failed.push( g.lights[ i ].path );
                        }
                     }
                     R.groups++;
                     R.timings.push( { step: rs.safe + " IC k=" + g.kk + " (" + g.lights.length + " lights)",
                                       seconds: ( Date.now() - tg )/1000 } );
                     if ( !ok && console.abortRequested )
                        R.aborted = true;
                  }
                  catch ( e )
                  {
                     if ( e && e.pswAbort )
                        R.aborted = true;
                     else
                        throw e;
                  }
                  finally
                  {
                     // A derived flat is needed only by its own group: delete it right away.
                     if ( derived && !params.keepIntermediates )
                     {
                        this.removeFiles( [ derived ] );
                        delete this._derivedCache[ derived ];
                     }
                  }
               }
            }
            finally
            {
               if ( csv.length > 1 )
                  try
                  {
                     File.writeTextFile( outDir + "/strength_log.csv", csv.join( "\n" ) + "\n" );
                  }
                  catch ( e )
                  {
                     console.warningln( "** Could not write strength_log.csv: " + e );
                  }
               if ( !params.keepIntermediates )
                  this.removeDirIfEmpty( this.derivedDir( out, rs ) );
            }
         }
      }
      finally
      {
         if ( !params.keepIntermediates )
         {
            for ( let o in outs )
            {
               this.removeDirIfEmpty( o + "/temp/derived" );
               this.removeDirIfEmpty( o + "/temp" );
            }
         }
      }

      R.seconds = ( Date.now() - t0 )/1000;
      R.done = R.lightsOk;
      if ( R.aborted )
         console.warningln( "<end><cbr>** Aborted. " + R.lightsOk + " light(s) were calibrated before the abort." );
      console.noteln( format( "<end><cbr>* Done: %d light(s) calibrated, %d failed, %d ImageCalibration run(s), %.2f s",
                              R.lightsOk, R.lightsFailed, R.icRuns, R.seconds ) );
      R.failed.forEach( p => console.warningln( "** Failed: " + p ) );
      return R;
   },

   // temp/derived/<session> folder.
   derivedDir: function( out, rs )
   {
      return out + "/temp/derived/" + rs.safe;
   },

   // ---------------------------------------------------------------- preview (4.7)

   // Opens the context for one light: builds/reuses the master flat (needs outputDir).
   // The caller (GUI) runs validate() for the session first; this throws clear errors
   // instead of silently degrading (no flat, unknown CFA pattern).
   preparePreview: function( session, lightIndex, params )
   {
      PSWParameters.defaults( params );
      let rs = ( session && session.src ) ? this.withParams( session, params ) : this.resolveSession( session, 0, params );
      if ( rs.lights.length == 0 )
         throw new Error( "Session '" + rs.name + "' has no light frames." );
      let li = Math.max( 0, Math.min( rs.lights.length - 1, lightIndex || 0 ) );
      if ( !rs.masterDark || !File.exists( rs.masterDark ) )
         throw new Error( "Session '" + rs.name + "': master dark not found: " + rs.masterDark );
      if ( rs.flats.length == 0 )
         throw new Error( "Session '" + rs.name + "': the preview needs flat frames." );
      if ( !rs.masterDarkFlat || !File.exists( rs.masterDarkFlat ) )
         throw new Error( "Session '" + rs.name + "': the preview needs the master dark flat (not found: '" + rs.masterDarkFlat + "')." );
      let mf = this.buildMasterFlat( rs, params );
      let ctx = this._openPreview( rs.lights[ li ].path, mf.path, rs.masterDark, rs.isCFA, rs.pattern, mf.stats );
      ctx.lightIndex = li;
      ctx.channels = rs.lightHdr ? rs.lightHdr.channels : 1;
      return ctx;
   },

   // Switches the preview to another light of the same session. Keeps the reduced dark,
   // flat, F_k means and the mosaic ln-flat; only light-dependent images are dropped.
   switchPreviewLight: function( ctx, lightPath, lightIndex )
   {
      if ( !File.exists( lightPath ) )
         throw new Error( "Light frame not found: " + lightPath );
      if ( ctx.red )
      {
         this.closeWindow( ctx.red.L );
         ctx.red.L = null;
      }
      this._dropChBefore( ctx );
      if ( ctx.mos )
      {
         this.closeWindow( ctx.mos.LD );
         this.closeWindow( ctx.mos.B );
         ctx.mos = null;
      }
      this._dropAfter( ctx );
      ctx.lightPath = lightPath;
      ctx.lightIndex = lightIndex;
      return ctx;
   },

   // Test convenience: prepare + render + close; never writes files.
   calibratePreview: function( lightPath, masterFlatPath, masterDarkPath, s, opts )
   {
      let h = this.readHeader( lightPath );
      let isCFA = h.pattern != "" && h.channels == 1;
      let ctx = this._openPreview( lightPath, masterFlatPath || "", masterDarkPath, isCFA, h.pattern, null );
      ctx.channels = h.channels;
      try
      {
         return this.renderPreview( ctx, s, opts );
      }
      finally
      {
         this.closePreview( ctx );
      }
   },

   _openPreview: function( lightPath, flatPath, darkPath, isCFA, pattern, stats )
   {
      let pe = PSW_CFA_PATTERNS.indexOf( pattern || "" );
      if ( isCFA && pe < 1 )
         throw new Error( "Unknown CFA pattern for " + lightPath + ": choose the Bayer pattern in the session." );
      return {
         lightPath: lightPath, lightIndex: 0, flatPath: flatPath, darkPath: darkPath,
         isCFA: isCFA, pattern: isCFA ? pattern : "", patternEnum: isCFA ? pe : 0,
         fmax: ( stats && stats.max > 0 ) ? stats.max : 0,
         red: null,       // reduced cache { maxSize, f, L, D, F, FK, fkKey, means } (each image lazy)
         mos: null,       // mosaic light cache { maxSize, f, LD, B }
         mLNF: null,      // mosaic ln(max(F,eps)/Fmax), full resolution, light independent
         scratch: null,   // reused stretch window
         after: null,     // last After image { key, w } (previewAfterWindow), owned by ctx
         chAfter: null,   // v4 channel view: { key, src, w } one channel of 'after'
         chBefore: null,  // v4 channel view: { key, src, w } one channel of the reduced L
         calcRuns: 0,     // number of calibration renders (renderPreview without 'before')
         channels: 1      // channels of the light files
      };
   },

   _resample: function( w, f )
   {
      if ( f <= 1 )
         return;
      let IR = new IntegerResample;
      IR.zoomFactor = -f;
      IR.downsamplingMode = IntegerResample.Average;
      IR.noGUIMessages = true;
      IR.executeOn( w.mainView, false );
   },

   _debayer: function( w, patternEnum )
   {
      let DB = new Debayer;
      DB.debayerMethod = Debayer.SuperPixel;
      DB.cfaPattern = patternEnum;
      DB.evaluateNoise = false;
      DB.evaluateSignal = false;
      DB.noGUIMessages = true;
      DB.showImages = false;
      // Verified: Debayer.executeOn() on a mono view does NOT work in place;
      // it creates a new (hidden) window whose id is in DB.outputImage.
      try
      {
         DB.executeOn( w.mainView, false );
      }
      catch ( e )
      {
         if ( DB.outputImage )
            this.closeWindow( ImageWindow.windowById( DB.outputImage ) );
         throw e;
      }
      let out = ImageWindow.windowById( DB.outputImage );
      if ( !out || out.isNull )
         throw new Error( "Debayer did not create an output image." );
      return out;
   },

   // Reduced cache, one image at a time: (debayered) L, D or F reduced by factor f.
   // The mosaic path only needs F (for the per-channel F_k means).
   _reduced: function( ctx, maxSize, which )
   {
      if ( ctx.red && ctx.red.maxSize != maxSize )
         this._dropReduced( ctx );
      if ( !ctx.red )
         ctx.red = { maxSize: maxSize, f: 0, L: null, D: null, F: null, FK: null, fkKey: "", means: {} };
      let red = ctx.red;
      if ( red[ which ] )
         return red;
      let path = which == "L" ? ctx.lightPath : ( which == "D" ? ctx.darkPath : ctx.flatPath );
      let w = this.readFloatWindow( path, this.uniqueId( "R" + which ) );
      try
      {
         if ( which == "F" && !( ctx.fmax > 0 ) )
            ctx.fmax = w.mainView.image.maximum();
         if ( ctx.isCFA )
         {
            let d;
            try
            {
               d = this._debayer( w, ctx.patternEnum );
            }
            finally
            {
               w.forceClose();
            }
            w = d;
         }
         // All frames share the geometry (validated), so f is the same for L, D and F.
         if ( red.f == 0 )
            red.f = Math.max( 1, Math.ceil( Math.max( w.mainView.image.width, w.mainView.image.height )/maxSize ) );
         this._resample( w, red.f );
      }
      catch ( e )
      {
         this.closeWindow( w );
         throw e;
      }
      red[ which ] = w;
      return red;
   },

   _dropReduced: function( ctx )
   {
      if ( !ctx.red )
         return;
      [ "L", "D", "F", "FK" ].forEach( k => this.closeWindow( ctx.red[ k ] ) );
      ctx.red = null;
      this._dropChBefore( ctx );
   },

   // Full-resolution mosaic cache (CFA with debayer off). Lossless restructuring of
   // (L - D)/(max(F,eps)/Fmax)^k: keep LD = L - D and LNF = ln(max(F,eps)/Fmax) once,
   // so a slider change costs one PixelMath LD*mm*exp(-k*LNF) on two full-size images
   // instead of three, and no per-render ln/max/divide. The binned Before image is
   // made at load time, so the raw L is not kept.
   _ensureMosaic: function( ctx, maxSize, needFlat )
   {
      let PM = new PixelMath;
      PM.useSingleExpression = true;
      PM.rescale = false;
      PM.truncate = false;
      PM.use64BitWorkingImage = false;
      PM.createNewImage = true;
      PM.showNewImage = false;
      PM.newImageSampleFormat = PixelMath.SameAsTarget;

      if ( ctx.mos && ctx.mos.maxSize != maxSize )
      {
         this.closeWindow( ctx.mos.LD );
         this.closeWindow( ctx.mos.B );
         ctx.mos = null;
      }
      if ( !ctx.mos )
      {
         let m = { maxSize: maxSize, f: 1, LD: null, B: null };
         let L = null, D = null;
         try
         {
            L = this.readFloatWindow( ctx.lightPath, this.uniqueId( "ML" ) );
            D = this.readFloatWindow( ctx.darkPath, this.uniqueId( "MD" ) );
            let im = L.mainView.image;
            m.f = Math.max( 1, Math.ceil( Math.max( im.width, im.height )/maxSize ) );
            // Binned Before image (raw L), CFA parity kept (_cfaBin).
            if ( m.f > 1 )
               m.B = this._cfaBin( L, m.f );
            else
            {
               let bid = this.uniqueId( "MB" );
               PM.expression = "$T";
               PM.newImageId = bid;
               PM.executeOn( L.mainView, false );
               m.B = ImageWindow.windowById( bid );
            }
            // LD = L - D (unclipped).
            let ldid = this.uniqueId( "MLD" );
            PM.expression = L.mainView.id + " - " + D.mainView.id;
            PM.newImageId = ldid;
            PM.executeOn( L.mainView, false );
            m.LD = ImageWindow.windowById( ldid );
         }
         catch ( e )
         {
            this.closeWindow( m.B );
            this.closeWindow( m.LD );
            throw e;
         }
         finally
         {
            this.closeWindow( L );
            this.closeWindow( D );
         }
         ctx.mos = m;
      }
      if ( needFlat && !ctx.mLNF )
      {
         let F = this.readFloatWindow( ctx.flatPath, this.uniqueId( "MF" ) );
         try
         {
            if ( !( ctx.fmax > 0 ) )
               ctx.fmax = F.mainView.image.maximum();
            let lnid = this.uniqueId( "MLNF" );
            PM.expression = "ln(max($T,fEps)/fMax)";
            PM.symbols = "fEps=" + ( 1e-4*ctx.fmax ).toPrecision( 17 ) + ", fMax=" + ctx.fmax.toPrecision( 17 );
            PM.newImageId = lnid;
            PM.executeOn( F.mainView, false );
            ctx.mLNF = ImageWindow.windowById( lnid );
         }
         finally
         {
            this.closeWindow( F );
         }
      }
      return ctx.mos;
   },

   _dropMosaic: function( ctx )
   {
      if ( ctx.mos )
      {
         this.closeWindow( ctx.mos.LD );
         this.closeWindow( ctx.mos.B );
         ctx.mos = null;
      }
      this.closeWindow( ctx.mLNF );
      ctx.mLNF = null;
   },

   // Per-channel means of F_k on the reduced flat (cached per k); FK holds F_k for 'k'.
   // v4: k may be a triple [kR, kG, kB] (debayered flat: channel c gets exponent k_c).
   _flatMeans: function( ctx, maxSize, k )
   {
      if ( Array.isArray( k ) && this.isEqualTriple( k ) )
         k = k[ 0 ];
      let red = this._reduced( ctx, maxSize, "F" );
      let kk = this.kKey( k );
      if ( red.means[ kk ] && red.FK && red.fkKey == kk )
         return red.means[ kk ];
      let fi = red.F.mainView.image;
      if ( !red.FK )
         red.FK = new ImageWindow( fi.width, fi.height, fi.numberOfChannels, 32, true, fi.numberOfChannels > 1, this.uniqueId( "FK" ) );
      let PM = new PixelMath;
      if ( Array.isArray( k ) && fi.numberOfChannels == 3 )
      {
         let e = c => "(max(" + red.F.mainView.id + ",fEps)/fMax)^" + [ "kPowR", "kPowG", "kPowB" ][ c ];
         PM.useSingleExpression = false;
         PM.expression = e( 0 );
         PM.expression1 = e( 1 );
         PM.expression2 = e( 2 );
         PM.symbols = "fEps=" + ( 1e-4*ctx.fmax ).toPrecision( 17 ) + ", fMax=" + ctx.fmax.toPrecision( 17 ) +
                      ", " + this.kSymbols( k );
      }
      else
      {
         PM.expression = "(max(" + red.F.mainView.id + ",fEps)/fMax)^kPow";
         PM.useSingleExpression = true;
         PM.symbols = "fEps=" + ( 1e-4*ctx.fmax ).toPrecision( 17 ) + ", fMax=" + ctx.fmax.toPrecision( 17 ) + ", kPow=" +
                      ( Array.isArray( k ) ? k[ 1 ] : k ).toFixed( 2 );
      }
      PM.rescale = false;
      PM.truncate = true;
      PM.createNewImage = false;
      PM.use64BitWorkingImage = false;
      PM.executeOn( red.FK.mainView, false );
      let img = red.FK.mainView.image;
      let means = [];
      for ( let c = 0; c < img.numberOfChannels; ++c )
         means.push( img.mean( img.bounds, c, c ) );
      red.fkKey = kk;
      red.means[ kk ] = means;
      return means;
   },

   // The cached Before image itself (raw light, reduced/binned). Owned by ctx: do NOT close.
   // v4 channel view R/G/B: channel c of the reduced debayered L (cached in ctx.chBefore).
   previewBeforeWindow: function( ctx, opts )
   {
      opts = opts || {};
      let maxSize = Math.max( 64, opts.maxSize || 1400 );
      let debayer = opts.debayer === undefined ? true : !!opts.debayer;
      let ch = this.previewChannel( ctx, opts );
      if ( ch )
      {
         let red = this._reduced( ctx, maxSize, "L" );
         let key = ch + "|" + maxSize;
         if ( ctx.chBefore && ctx.chBefore.key == key && ctx.chBefore.src === red.L && !ctx.chBefore.w.isNull )
            return ctx.chBefore.w;
         this._dropChBefore( ctx );
         ctx.chBefore = { key: key, src: red.L, w: this._extractChannel( red.L, "RGB".indexOf( ch ) ) };
         return ctx.chBefore.w;
      }
      if ( ctx.isCFA && !debayer )
         return this._ensureMosaic( ctx, maxSize, false ).B;
      return this._reduced( ctx, maxSize, "L" ).L;
   },

   // v4: channel view of the preview: "R", "G", "B" (CFA only) or "" (all channels).
   previewChannel: function( ctx, opts )
   {
      let c = String( ( opts && opts.channel ) || "all" ).toUpperCase();
      return ( ctx.isCFA && ( c == "R" || c == "G" || c == "B" ) ) ? c : "";
   },

   // v4: k of a preview strength (number or triple): a number when all colours are equal
   // (or the data are mono), else the triple [kR, kG, kB]. No flat -> 0.
   previewK: function( ctx, s )
   {
      let kt = this.toTriple( s ).map( v => this.strengthToK( v ) );
      if ( !ctx.flatPath )
         return 0;   // only calibratePreview() can be called without a flat (explicitly)
      if ( this.isEqualTriple( kt ) )
         return kt[ 0 ];
      return ctx.isCFA ? kt : kt[ 1 ];
   },

   // v4: copies channel c of a window into a new hidden 1-channel float window (bit exact).
   _extractChannel: function( win, c )
   {
      let img = win.mainView.image;
      let W = img.width, H = img.height;
      let data = new Float32Array( W*H );
      img.getSamples( data, new Rect( 0, 0, W, H ), c );
      let out = new ImageWindow( W, H, 1, 32, true, false, this.uniqueId( "CH" ) );
      try
      {
         out.mainView.beginProcess( UndoFlag.NoSwapFile );
         out.mainView.image.setSamples( data, new Rect( 0, 0, W, H ), 0 );
         out.mainView.endProcess();
      }
      catch ( e )
      {
         this.closeWindow( out );
         throw e;
      }
      return out;
   },

   // Returns a hidden float ImageWindow with the preview; the caller closes it.
   // opts: { debayer: bool (CFA only), maxSize: int, before: bool, channel: "all"|"R"|"G"|"B" }
   // s: strength (number) or v4 triple [sR, sG, sB]. Channel R/G/B: the bin2 image of that
   // CFA colour = channel c of the SuperPixel-debayered reduced path (1-channel output).
   renderPreview: function( ctx, s, opts )
   {
      opts = opts || {};
      let ch = this.previewChannel( ctx, opts );
      if ( ch )
      {
         let o = {};
         for ( let key in opts )
            o[ key ] = opts[ key ];
         o.channel = "all";
         o.debayer = true;
         let full = this.renderPreview( ctx, s, o );
         try
         {
            return this._extractChannel( full, "RGB".indexOf( ch ) );
         }
         finally
         {
            this.closeWindow( full );
         }
      }
      let maxSize = Math.max( 64, opts.maxSize || 1400 );
      let debayer = opts.debayer === undefined ? true : !!opts.debayer;
      let k = this.previewK( ctx, s );
      let mosaicPath = ctx.isCFA && !debayer;
      let outId = this.uniqueId( "P" );
      let PM = new PixelMath;
      PM.useSingleExpression = true;
      PM.rescale = false;
      PM.truncate = true;
      PM.use64BitWorkingImage = false;
      PM.createNewImage = true;
      PM.showNewImage = false;
      PM.newImageId = outId;
      PM.newImageSampleFormat = PixelMath.SameAsTarget;

      if ( opts.before )
      {
         let b = this.previewBeforeWindow( ctx, opts );
         PM.expression = "$T";
         PM.executeOn( b.mainView, false );
      }
      else if ( !mosaicPath )
      {
         this._reduced( ctx, maxSize, "L" );
         let red = this._reduced( ctx, maxSize, "D" );
         let Lid = red.L.mainView.id, Did = red.D.mainView.id;
         if ( k == 0 )
            PM.expression = Lid + " - " + Did;
         else
         {
            let means = this._flatMeans( ctx, maxSize, k );
            let FKid = red.FK.mainView.id;
            let e = c => "(" + Lid + " - " + Did + ")*" + means[ c ].toPrecision( 12 ) + "/" + FKid;
            if ( means.length == 1 )
               PM.expression = e( 0 );
            else
            {
               PM.useSingleExpression = false;
               PM.expression = e( 0 );
               PM.expression1 = e( 1 );
               PM.expression2 = e( 2 );
            }
         }
         PM.executeOn( red.L.mainView, false );
      }
      else
      {
         // Mosaic path: full-resolution calibrated mosaic, then mean-binned.
         let m = this._ensureMosaic( ctx, maxSize, k != 0 );
         let LDid = m.LD.mainView.id;
         if ( k == 0 )
            PM.expression = LDid;
         else
         {
            // Per-channel F_k means [R, G, B] from the debayered reduced flat only (G = G1+G2).
            let means = this._flatMeans( ctx, maxSize, k );
            let byLetter = { R: means[ 0 ], G: means[ 1 ], B: means[ 2 ] };
            let p = ctx.pattern;
            let mv = [ 0, 1, 2, 3 ].map( i => byLetter[ p.charAt( i ) ].toPrecision( 12 ) );
            let mm = "iif(y()%2==0, iif(x()%2==0," + mv[ 0 ] + "," + mv[ 1 ] + "), iif(x()%2==0," + mv[ 2 ] + "," + mv[ 3 ] + "))";
            if ( !Array.isArray( k ) )
               PM.expression = LDid + "*" + mm + "*exp(-" + k.toFixed( 2 ) + "*" + ctx.mLNF.mainView.id + ")";
            else
            {
               // v4 triple: one parity iif selecting the whole term LD*m_c*exp(-k_c*LNF)
               // (same operation order as the scalar form; measured 638 -> 367 ms at 4096x3072
               // versus two separate iifs for m and k, bit-identical output).
               let kv = this.parityValues( p, k.map( v => v.toFixed( 2 ) ) );
               PM.expression = this.parityIif( [ 0, 1, 2, 3 ].map( i =>
                  LDid + "*" + mv[ i ] + "*exp(-" + kv[ i ] + "*" + ctx.mLNF.mainView.id + ")" ) );
            }
         }
         PM.executeOn( m.LD.mainView, false );
      }
      let w = ImageWindow.windowById( outId );
      if ( !w || w.isNull )
         throw new Error( "Preview rendering failed." );
      if ( !opts.before )
         ++ctx.calcRuns;
      if ( mosaicPath && !opts.before && ctx.mos.f > 1 )
      {
         // Parity-preserving binning: every displayed pixel keeps its CFA colour,
         // so the stretch can be computed and applied per CFA channel.
         let b;
         try
         {
            b = this._cfaBin( w, ctx.mos.f );
         }
         finally
         {
            this.closeWindow( w );
         }
         w = b;
      }
      return w;
   },

   // Cached After image for (strength, debayer, maxSize) of the current light, owned
   // by ctx (do NOT close it): a stretch-mode or lock change re-stretches this image
   // without rerunning the calibration PixelMath.
   // v4: s may be a triple. Channel view R/G/B: channel c extracted from the cached
   // debayered After (ctx.chAfter). Extracting is cheaper than a one-channel PixelMath
   // as soon as the user switches channels: the 3-channel After is computed once per
   // triple and a channel switch is a copy + stretch, no new calibration.
   previewAfterWindow: function( ctx, s, opts )
   {
      opts = opts || {};
      let maxSize = Math.max( 64, opts.maxSize || 1400 );
      let ch = this.previewChannel( ctx, opts );
      if ( ch )
      {
         let full = this.previewAfterWindow( ctx, s, { debayer: true, maxSize: maxSize } );
         let ckey = ctx.after.key + "|" + ch;
         if ( ctx.chAfter && ctx.chAfter.key == ckey && ctx.chAfter.src === full && !ctx.chAfter.w.isNull )
            return ctx.chAfter.w;
         this._dropChAfter( ctx );
         ctx.chAfter = { key: ckey, src: full, w: this._extractChannel( full, "RGB".indexOf( ch ) ) };
         return ctx.chAfter.w;
      }
      let debayer = ( opts.debayer === undefined ? true : !!opts.debayer ) || !ctx.isCFA;
      let k = this.previewK( ctx, s );
      let key = this.kKey( k ) + "|" + debayer + "|" + maxSize;
      if ( ctx.after && ctx.after.key == key && ctx.after.w && !ctx.after.w.isNull )
         return ctx.after.w;
      this._dropAfter( ctx );
      let w = this.renderPreview( ctx, s, { debayer: debayer, maxSize: maxSize } );
      ctx.after = { key: key, w: w };
      return w;
   },

   _dropAfter: function( ctx )
   {
      this._dropChAfter( ctx );
      if ( ctx.after )
         this.closeWindow( ctx.after.w );
      ctx.after = null;
   },

   _dropChAfter: function( ctx )
   {
      if ( ctx.chAfter )
         this.closeWindow( ctx.chAfter.w );
      ctx.chAfter = null;
   },

   _dropChBefore: function( ctx )
   {
      if ( ctx.chBefore )
         this.closeWindow( ctx.chBefore.w );
      ctx.chBefore = null;
   },

   // Parity-preserving mean binning of a CFA mosaic by f (f >= 2). Each of the four
   // CFA planes (x%2, y%2) is averaged over f x f plane pixels (a 2f x 2f mosaic
   // block) and the planes are interleaved again: output pixel (X, Y) has the CFA
   // colour of source pixel (X%2, Y%2). IntegerResample would mix the colours.
   // Output: new hidden 1-channel float window, 2*floor(W/2/f) x 2*floor(H/2/f).
   // One pass over the source: 2f rows per getSamples call, typed arrays only.
   _cfaBin: function( win, f )
   {
      let src = win.mainView.image;
      let pw = Math.floor( Math.floor( src.width/2 )/f ), ph = Math.floor( Math.floor( src.height/2 )/f );
      if ( pw < 1 || ph < 1 )
         throw new Error( "Preview: image too small for a reduction factor of " + f + "." );
      let OW = 2*pw, OH = 2*ph, SW = OW*f, f2 = 2*f;
      // Source column -> output column (same parity).
      let map = new Int32Array( SW );
      for ( let sx = 0; sx < SW; ++sx )
         map[ sx ] = 2*Math.floor( ( sx >> 1 )/f ) + ( sx & 1 );
      let block = new Float32Array( SW*f2 );
      let acc = new Float64Array( 2*OW );
      let outData = new Float32Array( OW*OH );
      let inv = 1/( f*f );
      for ( let by = 0; by < ph; ++by )
      {
         src.getSamples( block, new Rect( 0, by*f2, SW, by*f2 + f2 ), 0 );
         acc.fill( 0 );
         for ( let r = 0; r < f2; ++r )
         {
            let base = ( r & 1 )*OW, o = r*SW;
            for ( let sx = 0; sx < SW; ++sx )
               acc[ base + map[ sx ] ] += block[ o + sx ];
         }
         let o = 2*by*OW;
         for ( let i = 0; i < 2*OW; ++i )
            outData[ o + i ] = acc[ i ]*inv;
      }
      let out = new ImageWindow( OW, OH, 1, 32, true, false, this.uniqueId( "CB" ) );
      try
      {
         out.mainView.beginProcess( UndoFlag.NoSwapFile );
         out.mainView.image.setSamples( outData, new Rect( 0, 0, OW, OH ), 0 );
         out.mainView.endProcess();
      }
      catch ( e )
      {
         this.closeWindow( out );
         throw e;
      }
      return out;
   },

   // Total reduction factor relative to the raw frame (for the status line).
   // v4: channel = true -> relative to the bin2 image of one CFA colour.
   previewFactor: function( ctx, debayer, channel )
   {
      if ( channel && ctx.isCFA )
         return ctx.red ? ctx.red.f : 0;
      if ( ctx.isCFA && !debayer )
         return ctx.mos ? ctx.mos.f : 0;
      return ctx.red ? ctx.red.f*( ctx.isCFA ? 2 : 1 ) : 0;
   },

   closePreview: function( ctx )
   {
      if ( !ctx )
         return;
      this._dropReduced( ctx );
      this._dropMosaic( ctx );
      this._dropAfter( ctx );
      this._dropChBefore( ctx );
      this.closeWindow( ctx.scratch );
      ctx.scratch = null;
   },

   // ---------------------------------------------------------------- display stretch (4.8)

   mtf: function( m, x )
   {
      if ( x <= 0 ) return 0;
      if ( x >= 1 ) return 1;
      if ( x == m ) return 0.5;
      return ( m - 1 )*x/( ( 2*m - 1 )*x - m );
   },

   // STF-style parameters from a median and MAD: { c0, m } (shadows -2.8, target 0.25).
   _stf: function( med, mad )
   {
      let c0 = Math.max( 0, Math.min( 1, med - 2.8*1.4826*mad ) );
      let x = med - c0;
      let m = ( x > 0 && x < 1 ) ? this.mtf( 0.25, x ) : 0.5;
      return { c0: c0, m: m };
   },

   // Auto stretch parameters (display only).
   //   opts.unlinked false (default): linked, one { c0, m } from median/MAD averaged over
   //     channels -> { unlinked: false, c0, m }.
   //   opts.unlinked true, RGB image: one { c0, m } per channel -> { unlinked: true, ch: [3] }.
   //   opts.unlinked true, opts.pattern set (1-channel CFA mosaic whose pixel (0,0) has
   //     colour pattern[0]): statistics per CFA colour R, G (G1 and G2 together), B from
   //     the pixels of that parity -> { unlinked: true, cfa: pattern, ch: [R, G, B] }.
   //   A mono image without pattern always gets the linked form (same numbers).
   computeStretch: function( win, opts )
   {
      opts = opts || {};
      let img = win.mainView.image;
      let n = img.numberOfChannels;
      let pattern = ( opts.pattern && n == 1 ) ? opts.pattern : "";
      if ( opts.unlinked && pattern )
         return { unlinked: true, cfa: pattern, ch: this._cfaStats( img, pattern ).map( a => this._stf( a[ 0 ], a[ 1 ] ) ) };
      let med = [], mad = [];
      for ( let c = 0; c < n; ++c )
      {
         let mc = img.median( img.bounds, c, c );
         med.push( mc );
         mad.push( img.MAD( mc, img.bounds, c, c ) );
      }
      if ( opts.unlinked && n > 1 )
         return { unlinked: true, ch: med.map( ( v, c ) => this._stf( v, mad[ c ] ) ) };
      let sm = 0, sd = 0;
      for ( let c = 0; c < n; ++c )
      {
         sm += med[ c ];
         sd += mad[ c ];
      }
      let st = this._stf( sm/n, sd/n );
      return { unlinked: false, c0: st.c0, m: st.m };
   },

   // [[median, MAD] for R, G, B] of a 1-channel CFA mosaic, split by pixel parity.
   _cfaStats: function( img, pattern )
   {
      let W = img.width, H = img.height;
      let data = new Float32Array( W*H );
      img.getSamples( data, img.bounds, 0 );
      let letters = [ 0, 1, 2, 3 ].map( i => "RGB".indexOf( pattern.charAt( i ) ) );
      let count = [ 0, 0, 0 ];
      for ( let y = 0; y < H; ++y )
         for ( let x = 0; x < W; ++x )
            ++count[ letters[ ( ( y & 1 ) << 1 ) | ( x & 1 ) ] ];
      let arr = count.map( c => new Float32Array( Math.max( 1, c ) ) );
      let pos = [ 0, 0, 0 ];
      for ( let y = 0, i = 0; y < H; ++y )
      {
         let l0 = letters[ ( y & 1 ) << 1 ], l1 = letters[ ( ( y & 1 ) << 1 ) | 1 ];
         let a0 = arr[ l0 ], a1 = arr[ l1 ];
         for ( let x = 0; x < W; ++x, ++i )
            if ( x & 1 )
               a1[ pos[ l1 ]++ ] = data[ i ];
            else
               a0[ pos[ l0 ]++ ] = data[ i ];
      }
      return arr.map( a =>
      {
         let im = new Image( a, a.length, 1 );
         let md = im.median();
         let r = [ md, im.MAD( md ) ];
         im.free();
         return r;
      } );
   },

   // Applies the stretch (computeStretch result) on a reused scratch window and returns
   // a Bitmap. Linked: one mtf for all pixels; unlinked RGB: one expression per channel;
   // unlinked CFA: one expression, c0 and m chosen by pixel parity like the mosaic flat.
   stretchedBitmap: function( ctx, win, st )
   {
      let img = win.mainView.image;
      let sc = ctx.scratch;
      if ( !sc || sc.isNull || sc.mainView.image.width != img.width || sc.mainView.image.height != img.height ||
           sc.mainView.image.numberOfChannels != img.numberOfChannels )
      {
         this.closeWindow( sc );
         sc = ctx.scratch = new ImageWindow( img.width, img.height, img.numberOfChannels, 32, true,
                                             img.numberOfChannels > 1, this.uniqueId( "S" ) );
      }
      let id = win.mainView.id;
      let expr = ( m, c0, a ) => "mtf(" + m + ", max(0," + id + " - " + c0 + ")/" + a + ")";
      let PM = new PixelMath;
      PM.useSingleExpression = true;
      if ( !st.unlinked )
      {
         let c0 = Math.min( st.c0, 0.999 );
         PM.expression = expr( st.m.toPrecision( 12 ), c0.toPrecision( 12 ), ( 1 - c0 ).toPrecision( 12 ) );
      }
      else
      {
         let c0 = st.ch.map( p => Math.min( p.c0, 0.999 ) );
         if ( st.cfa )
         {
            let idx = [ 0, 1, 2, 3 ].map( i => "RGB".indexOf( st.cfa.charAt( i ) ) );
            let sel = v => "iif(y()%2==0, iif(x()%2==0," + v[ idx[ 0 ] ] + "," + v[ idx[ 1 ] ] + "), iif(x()%2==0," +
                           v[ idx[ 2 ] ] + "," + v[ idx[ 3 ] ] + "))";
            PM.expression = expr( sel( st.ch.map( p => p.m.toPrecision( 12 ) ) ),
                                  sel( c0.map( v => v.toPrecision( 12 ) ) ),
                                  sel( c0.map( v => ( 1 - v ).toPrecision( 12 ) ) ) );
         }
         else
         {
            let e = c => expr( st.ch[ c ].m.toPrecision( 12 ), c0[ c ].toPrecision( 12 ), ( 1 - c0[ c ] ).toPrecision( 12 ) );
            PM.useSingleExpression = false;
            PM.expression = e( 0 );
            PM.expression1 = e( 1 );
            PM.expression2 = e( 2 );
         }
      }
      PM.rescale = false;
      PM.truncate = true;
      PM.createNewImage = false;
      PM.executeOn( sc.mainView, false );
      return sc.mainView.image.render();
   }
};
