// SmartFrameSelection_v4GUI.js - dialog only. Reads/writes PSWParameters, never processes pixels.
// V8 engine style: ES6 class extends Dialog, enums as Namespace.Value (FrameStyle.Box ...).

// Branded header strip (reference/branding.md). Pure display, never throws:
// a missing asset is simply skipped. SVGs are rendered once at physical size;
// onPaint only blits. Keep it unless the user asks to remove branding.
var PSWHeader = class extends Control
{
   constructor( parent )
   {
      super( parent );
      let self = this;
      this.iconBitmap = null;
      this.logoBitmap = null;
      this.titleFont = null;
      this.subFont = null;
      let s = 1;
      try { s = this.logicalPixelsToPhysical( 1 ); } catch ( e ) {}
      this.s = s;
      this.setScaledFixedHeight( 64 );
      let dir = File.extractDrive( #__FILE__ ) + File.extractDirectory( #__FILE__ ) + "/";
      try
      {
         if ( File.exists( dir + PSW_ICON ) )
            this.iconBitmap = Bitmap.fromSVGFile( dir + PSW_ICON, Math.round( 44*s ), Math.round( 44*s ) );
      }
      catch ( e ) { this.iconBitmap = null; }
      try
      {
         // brand_logo.svg: white logotype on transparent background; keep its aspect ratio.
         let f = dir + "brand_logo.svg";
         if ( File.exists( f ) )
         {
            let h = Math.round( 22*s );
            let w = 4*h;
            let vb = /viewBox="\s*[-\d.]+[\s,]+[-\d.]+[\s,]+([\d.]+)[\s,]+([\d.]+)/.exec( File.readTextFile( f ) );
            if ( vb != null && parseFloat( vb[2] ) > 0 )
               w = Math.round( h*parseFloat( vb[1] )/parseFloat( vb[2] ) );
            this.logoBitmap = Bitmap.fromSVGFile( f, w, h );
         }
      }
      catch ( e ) { this.logoBitmap = null; }
      try
      {
         let base = this.font;
         this.subFont = new Font( base.family, base.pointSize );
         this.titleFont = new Font( base.family, base.pointSize*1.35 );
         this.titleFont.bold = true;
      }
      catch ( e ) { this.titleFont = this.subFont = null; }

      this.onPaint = function( x0, y0, x1, y1 )
      {
         let g = new Graphics( self );
         try { self.paintHeader( g, self.width, self.height ); }
         catch ( e ) {}
         finally { g.end(); }
      };
   }

   paintHeader( g, w, h )
   {
      let s = this.s;
      g.fillRect( 0, 0, w, h, new Brush( 0xff0B1121 ) );
      let textX = Math.round( 12*s );
      if ( this.iconBitmap != null && this.iconBitmap.width > 0 )
      {
         g.drawBitmap( Math.round( 12*s ), Math.round( (h - this.iconBitmap.height)/2 ), this.iconBitmap );
         textX += this.iconBitmap.width + Math.round( 12*s );
      }
      if ( this.titleFont != null && this.subFont != null )
      {
         g.antialiasing = true;
         g.textAntialiasing = true;
         let th = this.titleFont.height, sh = this.subFont.height;
         let top = Math.round( (h - th - sh)/2 );
         g.font = this.titleFont;
         g.pen = new Pen( 0xffF8F9F9 );
         g.drawText( textX, top + this.titleFont.ascent, PSW_TITLE );
         g.font = this.subFont;
         g.pen = new Pen( 0xff9AA3B5 );
         g.drawText( textX, top + th + this.subFont.ascent, PSW_TAGLINE + "  ·  v" + PSW_VERSION );
      }
      if ( this.logoBitmap != null && this.logoBitmap.width > 0 )
      {
         g.smoothInterpolation = true;
         g.drawBitmap( w - Math.round( 14*s ) - this.logoBitmap.width, Math.round( (h - this.logoBitmap.height)/2 ), this.logoBitmap );
      }
   }
};

// ----------------------------------------------------------------------------
// Shared texts
// ----------------------------------------------------------------------------
var PSW_AUTO_RULE_TEXT =
   "<p><b>Auto rule</b> (robust statistics of this session plus absolute caps). A frame is rejected when:</p>" +
   "<ul>" +
   "<li>FWHM &gt; median + 2.5&sigma; (bad seeing, focus drift; high side only)</li>" +
   "<li>Eccentricity &gt; max(median + 3&sigma;, 0.70); never below 0.55</li>" +
   "<li>PSF Signal Weight &lt; median &minus; 2.5&sigma;</li>" +
   "<li>Stars &lt; 50% of the median (clouds, dew)</li>" +
   "<li>Median (background) &gt; median + 3&sigma; (moon, dawn, light pollution)</li>" +
   "</ul>" +
   "<p>&sigma; = 1.4826&middot;MAD with a small floor, so a very uniform session is not cut for noise. " +
   "Two passes (the second on the survivors). Fewer than 5 frames: only the absolute caps. " +
   "If more than 40% would be rejected, the best 60% by PSF Signal Weight are kept.</p>";

var PSW_KIND_ITEMS = [ [ "abs", "Absolute value" ], [ "sigma", "Sigma from median" ], [ "pct", "% of median" ] ];

var PSW_METRIC_TIPS = {
   FWHM: "Full width at half maximum of the stars, in arcseconds (the image scale is applied). Smaller is sharper; " +
         "large values mean bad seeing, focus drift or tracking blur.",
   Eccentricity: "Star elongation: 0 = round, 1 = a line. High values mean tracking or guiding errors, wind or tilt.",
   PSFSignalWeight: "PSF Signal Weight: a combined signal-to-noise quality estimate of the stars. Larger is better.",
   PSFSNR: "PSF SNR: signal-to-noise ratio estimated from the star fits. Larger is better.",
   SNR: "SNR estimate of the whole measured area (SubframeSelector SNR weight). Larger is better.",
   Stars: "Number of detected stars. A drop means clouds, dew or haze.",
   Median: "Median (background level), in electrons when the gain is known, else in data numbers. " +
           "High values mean moon, dawn or light pollution.",
   Noise: "Noise estimate, in electrons when the gain is known, else in data numbers. Smaller is better.",
   MStar: "M*: mean star signal estimate (SubframeSelector), in electrons when the gain is known, else in data numbers.",
   PSFFlux: "Total flux of the fitted stars (SubframeSelector PSF flux). A drop means clouds or haze."
};

var PSW_KIND_TIP =
   "<p>How the numbers of this row are read:</p>" +
   "<p><b>Absolute value</b>: the limits are values of the metric itself.<br/>" +
   "<b>Sigma from median</b>: a number k &ge; 0; reject below = median &minus; k&middot;sigma, " +
   "reject above = median + k&middot;sigma (sigma = 1.4826&middot;MAD of all measured frames; 3 = the third sigma).<br/>" +
   "<b>% of median</b>: a percentage p &ge; 0; reject below = median&middot;(1 &minus; p/100), " +
   "reject above = median&middot;(1 + p/100).</p>";

function pswMetricKeys( available )
{
   return PSW_METRICS.map( m => m.key ).filter( k => !available || available.indexOf( k ) >= 0 );
}

function pswHtml( s )
{
   return String( s ).replace( /&/g, "&amp;" ).replace( /</g, "&lt;" ).replace( />/g, "&gt;" );
}

// ----------------------------------------------------------------------------
// Rule table: one fixed row per available metric (Use | Metric | Limit type |
// Reject below | Reject above), built from real controls (one HorizontalSizer per
// row, fixed column widths). Reused by the main dialog and the review dialog.
// onChange( table ) gets the full table; a cell that is not a number is NaN there.
// ----------------------------------------------------------------------------
var PSWRuleTable = class extends Control
{
   constructor( parent, table, available, onChange )
   {
      super( parent );
      let self = this;
      this.onChange = onChange || null;
      this.syncing = false;
      this.keys = pswMetricKeys( available );
      this.table = PSWEngine.normalizeRuleTable( table );   // all metrics; hidden ones are kept as they are
      this.texts = {};
      this.rows = [];

      let F = this.font;
      this.wUse = F.width( "Use" ) + 24;
      this.wMetric = Math.max( ...PSW_METRICS.map( m => F.width( m.title ) ) ) + 16;
      this.wKind = F.width( "Sigma from median" ) + 48;
      this.wCell = F.width( "Reject below" ) + 24;

      let mkHead = ( text, w, tip, right ) =>
      {
         let l = new Label( this );
         l.text = text;
         l.setFixedWidth( w );
         l.textAlignment = ( right ? TextAlignment.Right : TextAlignment.Left ) | TextAlignment.VertCenter;
         l.toolTip = tip;
         return l;
      };
      this.headSizer = new HorizontalSizer;
      this.headSizer.spacing = 6;
      this.headSizer.add( mkHead( "Use", this.wUse, "<p>Check a row to use it. Unchecked rows are ignored. " +
                                  "A frame is approved only if it passes every checked row.</p>" ) );
      this.headSizer.add( mkHead( "Metric", this.wMetric, "<p>The measured value tested by the row (units in brackets). " +
                                  "Hover over a metric name for details.</p>" ) );
      this.headSizer.add( mkHead( "Limit type", this.wKind, PSW_KIND_TIP ) );
      this.headSizer.add( mkHead( "Reject below", this.wCell, "<p>Frames with a value below this limit are rejected. " +
                                  "Empty = no lower limit. The number is read according to the limit type " +
                                  "(a value, k sigma or a percentage).</p>" ) );
      this.headSizer.add( mkHead( "Reject above", this.wCell, "<p>Frames with a value above this limit are rejected. " +
                                  "Empty = no upper limit. Both sides may be set on the same row (a band).</p>" ) );
      this.headSizer.addStretch();

      this.sizer = new VerticalSizer;
      this.sizer.spacing = 3;
      this.sizer.add( this.headSizer );

      for ( let key of this.keys )
      {
         let k = key;
         let ti = this.indexOf( k );
         let r = this.table[ ti ];
         this.texts[ k ] = { lo: this.cellText( r.lo ), hi: this.cellText( r.hi ) };
         let title = PSWEngine.metricTitle( k );
         let row = { key: k };
         row.use = new CheckBox( this );
         row.use.setFixedWidth( this.wUse );
         row.use.toolTip = "<p>Use the " + pswHtml( title ) + " row: frames outside its limits are rejected. " +
                           "Unchecked = ignored. A checked row needs at least one limit.</p>";
         row.use.onCheck = function( c ) { if ( !self.syncing ) { self.table[ ti ].enabled = c; self.changed(); } };
         row.label = new Label( this );
         row.label.text = title;
         row.label.setFixedWidth( this.wMetric );
         row.label.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
         row.label.toolTip = "<p><b>" + pswHtml( title ) + "</b>: " + pswHtml( PSW_METRIC_TIPS[ k ] || "" ) + "</p>";
         row.kind = new ComboBox( this );
         for ( let it of PSW_KIND_ITEMS ) row.kind.addItem( it[ 1 ] );
         row.kind.setFixedWidth( this.wKind );
         row.kind.toolTip = PSW_KIND_TIP;
         row.kind.onItemSelected = function( ix ) { if ( !self.syncing ) { self.table[ ti ].kind = PSW_KIND_ITEMS[ ix ][ 0 ]; self.changed(); } };
         let mkEdit = side =>
         {
            let e = new Edit( this );
            e.setFixedWidth( this.wCell );
            e.onTextUpdated = function( t ) { if ( !self.syncing ) { self.texts[ k ][ side ] = t; self.table[ ti ][ side ] = PSWEngine.parseCell( t ).value; self.changed(); } };
            return e;
         };
         row.lo = mkEdit( "lo" );
         row.hi = mkEdit( "hi" );
         row.sizer = new HorizontalSizer;
         row.sizer.spacing = 6;
         row.sizer.add( row.use );
         row.sizer.add( row.label );
         row.sizer.add( row.kind );
         row.sizer.add( row.lo );
         row.sizer.add( row.hi );
         row.sizer.addStretch();
         this.sizer.add( row.sizer );
         this.rows.push( row );
      }
      this.sync();
   }

   indexOf( key )
   {
      for ( let i = 0; i < this.table.length; ++i )
         if ( this.table[ i ].metric == key )
            return i;
      return -1;
   }

   cellText( v )
   {
      return v === null || v === undefined ? "" : ( typeof v == "number" && isNaN( v ) ? "" : String( v ) );
   }

   // Copies the model to the controls and refreshes colours/tooltips.
   sync()
   {
      this.syncing = true;
      for ( let row of this.rows )
      {
         let r = this.table[ this.indexOf( row.key ) ];
         row.use.checked = r.enabled;
         row.kind.currentItem = Math.max( 0, PSW_RULE_KINDS.indexOf( r.kind ) );
         if ( row.lo.text != this.texts[ row.key ].lo ) row.lo.text = this.texts[ row.key ].lo;
         if ( row.hi.text != this.texts[ row.key ].hi ) row.hi.text = this.texts[ row.key ].hi;
      }
      this.syncing = false;
      this.decorate();
   }

   cellTip( title, kind, side )
   {
      let below = side == "lo";
      let t = "<p><b>" + pswHtml( title ) + " &mdash; reject " + ( below ? "below" : "above" ) + "</b><br/>";
      if ( kind == "abs" )
         t += "Frames with a value " + ( below ? "smaller" : "greater" ) + " than this number are rejected.";
      else if ( kind == "sigma" )
         t += "Enter k &ge; 0: frames " + ( below ? "below median &minus; k&middot;sigma" : "above median + k&middot;sigma" ) +
              " are rejected (sigma = 1.4826&middot;MAD of all measured frames; e.g. 3).";
      else
         t += "Enter p &ge; 0: frames " + ( below ? "below median&middot;(1 &minus; p/100)" : "above median&middot;(1 + p/100)" ) +
              " are rejected (e.g. 50).";
      return t + "<br/>Empty = no " + ( below ? "lower" : "upper" ) + " limit.</p>";
   }

   // Red cells + error tooltips. Returns the first error ("" when valid).
   decorate()
   {
      let first = "";
      for ( let row of this.rows )
      {
         let r = this.table[ this.indexOf( row.key ) ];
         let title = PSWEngine.metricTitle( row.key );
         let cellErr = {};
         for ( let side of [ "lo", "hi" ] )
         {
            let p = PSWEngine.parseCell( this.texts[ row.key ][ side ] );
            cellErr[ side ] = !p.ok ? "Not a number." :
                              ( r.kind != "abs" && p.value !== null && p.value < 0 ) ? "Must be zero or positive for this limit type." : "";
         }
         let rowErr = PSWEngine.ruleRowError( r );
         for ( let side of [ "lo", "hi" ] )
         {
            let e = cellErr[ side ] || ( rowErr && !cellErr.lo && !cellErr.hi ? rowErr : "" );
            let ed = row[ side ];
            ed.styleSheet = e ? "background-color: #ffc8c8; color: #000000;" : "";
            ed.toolTip = ( e ? "<p><b><font color=\"#C00000\">Error:</font></b> " + pswHtml( e ) + "</p>" : "" ) +
                         this.cellTip( title, r.kind, side );
         }
         if ( !first && rowErr )
            first = rowErr;
      }
      this.error = first;
      return first;
   }

   setTable( table )
   {
      this.table = PSWEngine.normalizeRuleTable( table );
      for ( let k of this.keys )
      {
         let r = this.table[ this.indexOf( k ) ];
         this.texts[ k ] = { lo: this.cellText( r.lo ), hi: this.cellText( r.hi ) };
      }
      this.sync();
   }

   getTable()
   {
      return this.table.map( r => ( { metric: r.metric, enabled: r.enabled, kind: r.kind, lo: r.lo, hi: r.hi } ) );
   }

   changed()
   {
      if ( this.syncing ) return;
      this.decorate();
      if ( typeof this.onChange == "function" )
         this.onChange( this.getTable() );
   }
};

// ----------------------------------------------------------------------------
// Review dialog: table + graph + live rules + manual overrides.
// ----------------------------------------------------------------------------
var PSWReviewDialog = class extends Dialog
{
   constructor( rows, params, available, parent )
   {
      super( parent );
      let self = this;
      this.rows = rows;
      this.params = params;
      this.available = available || pswMetricKeys( null );
      this.metricKeys = pswMetricKeys( this.available );
      this.overrides = {};
      this.table = PSWEngine.normalizeRuleTable( params.ruleTable );   // starts from the main dialog's table
      this.sel = null;
      this.updating = false;
      this.graphMetric = this.metricKeys.indexOf( "FWHM" ) >= 0 ? "FWHM" : this.metricKeys[ 0 ];
      // "All (R, G, B)" sessions: one column per metric and channel, three graph series.
      this.chans = PSWEngine.selectionChannels( rows );
      this.viewCh = "All";

      // Decimals per metric (over all channels), so that space-padded text sorts numerically.
      this.decimals = {};
      for ( let k of this.metricKeys )
      {
         let mx = 0;
         for ( let r of rows )
            for ( let c of this.chans || [ "" ] )
            {
               let v = PSWEngine.metricsOf( r, c )[ k ];
               if ( isFinite( v ) ) mx = Math.max( mx, Math.abs( v ) );
            }
         this.decimals[ k ] = k == "Stars" ? 0 : Math.max( 0, Math.min( 8, 4 - Math.floor( Math.log10( mx > 0 ? mx : 1 ) ) ) );
      }
      this.cols = [];
      for ( let k of this.metricKeys )
         for ( let c of this.chans || [ "" ] )
            this.cols.push( { key: k, ch: c } );

      // Table
      this.tree = new TreeBox( this );
      this.tree.alternateRowColor = true;
      this.tree.rootDecoration = false;
      this.tree.multipleSelection = false;
      this.tree.headerVisible = true;
      this.tree.headerSorting = true;
      this.colMetric0 = 3;
      this.tree.numberOfColumns = 3 + this.cols.length + 1;
      this.tree.setHeaderText( 0, "#" );
      this.tree.setHeaderText( 1, "File" );
      this.tree.setHeaderText( 2, "Status" );
      for ( let j = 0; j < this.cols.length; ++j )
      {
         this.tree.setHeaderText( this.colMetric0 + j, this.cols[ j ].key + ( this.cols[ j ].ch ? " " + this.cols[ j ].ch : "" ) );
         this.tree.setHeaderAlignment( this.colMetric0 + j, TextAlignment.Right | TextAlignment.VertCenter );
      }
      this.colReason = this.colMetric0 + this.cols.length;
      this.tree.setHeaderText( this.colReason, "Reason" );
      this.tree.setScaledMinSize( 760, 220 );
      this.tree.toolTip = "<p>Measured frames. The check box approves or rejects a frame manually (manual overrides win over the rules). " +
                          "Click a column header to sort (metric columns sort by number). Rejected frames are shown in red.</p>" +
                          ( this.chans ? "<p>All (R, G, B): one column per metric and channel (\"FWHM R\", \"FWHM G\", \"FWHM B\"); " +
                                         "use the Channel selector to show one channel only.</p>" : "" );
      this.nodes = [];
      for ( let i = 0; i < rows.length; ++i )
      {
         let r = rows[ i ];
         let n = new TreeBoxNode( this.tree );
         n.checkable = !r.failed;
         n.setText( 0, this.pad( String( i + 1 ), 5 ) );
         n.setText( 1, r.name );
         n.setToolTip( 1, r.path );
         for ( let j = 0; j < this.cols.length; ++j )
         {
            let v = PSWEngine.metricsOf( r, this.cols[ j ].ch )[ this.cols[ j ].key ];
            n.setText( this.colMetric0 + j, this.pad( isFinite( v ) ? v.toFixed( this.decimals[ this.cols[ j ].key ] ) : "-", 14 ) );
            n.setAlignment( this.colMetric0 + j, TextAlignment.Right | TextAlignment.VertCenter );
         }
         this.nodes.push( n );
      }
      this.tree.onNodeUpdated = function( node, col )
      {
         if ( self.updating ) return;
         let i = parseInt( node.text( 0 ) ) - 1;
         if ( !( i >= 0 && i < self.rows.length ) || self.rows[ i ].failed ) return;
         if ( self.sel && node.checked != self.sel.approved[ i ] )
         {
            self.overrides[ i ] = node.checked;
            self.refresh();
         }
      };
      this.tree.onCurrentNodeUpdated = function() { self.graph.repaint(); };

      // Graph
      this.metricLabel = new Label( this );
      this.metricLabel.text = "Graph:";
      this.metricLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.metricLabel.toolTip = "<p>Metric shown in the graph.</p>";
      this.metricCombo = new ComboBox( this );
      for ( let k of this.metricKeys ) this.metricCombo.addItem( k );
      this.metricCombo.currentItem = Math.max( 0, this.metricKeys.indexOf( this.graphMetric ) );
      this.metricCombo.toolTip = "<p>Metric shown in the graph versus the frame index. The horizontal lines are the " +
                                 "limits of the checked rule-table rows (both reject below and reject above), or of the Auto rule.</p>";
      this.metricCombo.onItemSelected = function( ix ) { self.graphMetric = self.metricKeys[ ix ]; self.graph.repaint(); };

      // Channel selector (All (R, G, B) sessions only): table columns and graph series.
      this.chLabel = new Label( this );
      this.chLabel.text = "Channel:";
      this.chLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.chCombo = new ComboBox( this );
      for ( let it of [ "All (R, G, B)", "R", "G", "B" ] ) this.chCombo.addItem( it );
      this.chCombo.toolTip = this.chLabel.toolTip =
         "<p>Channel shown in the table columns and in the graph. <b>All</b>: the three channels side by side and three " +
         "graph series in red, green and blue. The selection always uses every channel: a frame is approved only if it " +
         "passes in all three.</p>";
      this.chCombo.onItemSelected = function( ix ) { self.viewCh = [ "All", "R", "G", "B" ][ ix ]; self.applyChannelView(); };
      this.chLabel.visible = this.chCombo.visible = !!this.chans;

      this.graph = new Control( this );
      this.graph.setScaledMinSize( 760, 240 );
      this.graph.toolTip = "<p>Selected metric per frame. Filled dot = approved, hollow red = rejected, square = manual override. " +
                           "Click a point to toggle its approval (manual override) and select its table row.</p>" +
                           ( this.chans ? "<p>All (R, G, B): one series per channel in red, green and blue (filled = approved, " +
                                          "hollow = rejected) with the threshold lines of each channel in the same colour. " +
                                          "Clicking any point toggles the whole frame.</p>" : "" );
      this.graph.onPaint = function() { self.paintGraph(); };
      this.graph.onMousePress = function( x, y, button ) { self.graphClick( x, y ); };
      this.points = [];

      // Rule table (live, debounced)
      this.ruleTable = new PSWRuleTable( this, this.table, this.available,
         function( table )
         {
            self.table = table;
            self.timer.stop();
            self.timer.start();
         } );
      this.ruleTable.toolTip = "<p>Rule table applied live to the cached measurements (nothing is measured again). " +
                               "Only checked rows reject: with no checked row every measured frame is approved (the Auto rule " +
                               "is not used in Review mode). Invalid rows are ignored until corrected." +
                               ( this.chans ? " With All (R, G, B) each row is tested in every channel against that channel's statistics." : "" ) +
                               "</p>";
      this.timer = new Timer;
      this.timer.interval = 0.15;
      this.timer.periodic = false;
      this.timer.onTimeout = function() { self.refresh(); };

      this.rulesGroup = new GroupBox( this );
      this.rulesGroup.title = "Rule table (live)";
      this.rulesGroup.sizer = new VerticalSizer;
      this.rulesGroup.sizer.margin = 6;
      this.rulesGroup.sizer.add( this.ruleTable );
      this.rulesGroup.toolTip = this.ruleTable.toolTip;

      this.countLabel = new Label( this );
      this.countLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
      this.countLabel.toolTip = "<p>Approved frames / measured frames. Failed frames are never approved.</p>";
      this.ruleInfo = new Label( this );
      this.ruleInfo.toolTip = "<p>Which selection is active: the checked rule-table rows, or none (every measured frame " +
                              "approved unless you reject it). Manual overrides always win.</p>";

      this.resetButton = new PushButton( this );
      this.resetButton.text = "Reset overrides";
      this.resetButton.icon = this.scaledResource( ":/icons/reload.png" );
      this.resetButton.toolTip = "<p>Remove every manual approval/rejection; the rules decide again.</p>";
      this.resetButton.onClick = function() { self.overrides = {}; self.refresh(); };

      this.exportButton = new PushButton( this );
      this.exportButton.text = "Export";
      this.exportButton.icon = this.scaledResource( ":/icons/ok.png" );
      this.exportButton.toolTip = "<p>Accept this selection: copy the approved frames to the output folder and write the report.</p>";
      this.exportButton.onClick = function()
      {
         let err = PSWEngine.validateRuleTable( self.table, false );
         if ( err )
         {
            ( new MessageBox( "The rule table is invalid:\n" + err, PSW_TITLE, StdIcon.Error, StdButton.Ok ) ).execute();
            return;
         }
         self.params.ruleTable = PSWEngine.normalizeRuleTable( self.table );
         self.ok();
      };
      this.cancelButton = new PushButton( this );
      this.cancelButton.text = "Cancel";
      this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
      this.cancelButton.toolTip = "<p>Close without exporting anything. Input files are never touched.</p>";
      this.cancelButton.onClick = function() { self.cancel(); };

      this.graphTopSizer = new HorizontalSizer;
      this.graphTopSizer.spacing = 6;
      this.graphTopSizer.add( this.metricLabel );
      this.graphTopSizer.add( this.metricCombo );
      this.graphTopSizer.addSpacing( 12 );
      this.graphTopSizer.add( this.chLabel );
      this.graphTopSizer.add( this.chCombo );
      this.graphTopSizer.addSpacing( 12 );
      this.graphTopSizer.add( this.ruleInfo, 100 );

      this.buttonsSizer = new HorizontalSizer;
      this.buttonsSizer.spacing = 6;
      this.buttonsSizer.add( this.countLabel );
      this.buttonsSizer.addStretch();
      this.buttonsSizer.add( this.resetButton );
      this.buttonsSizer.add( this.exportButton );
      this.buttonsSizer.add( this.cancelButton );

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 6;
      this.sizer.add( this.tree, 100 );
      this.sizer.add( this.graphTopSizer );
      this.sizer.add( this.graph, 100 );
      this.sizer.add( this.rulesGroup );
      this.sizer.add( this.buttonsSizer );

      this.windowTitle = PSW_TITLE + " - Review";
      this.onHide = function() { self.timer.stop(); };
      this.refresh();
      this.adjustToContents();
   }

   // Shows the metric columns of the selected channel (All = every column) and repaints.
   applyChannelView()
   {
      for ( let j = 0; j < this.cols.length; ++j )
         this.tree.showColumn( this.colMetric0 + j, !this.chans || this.viewCh == "All" || this.cols[ j ].ch == this.viewCh );
      this.graph.repaint();
   }

   pad( s, n )
   {
      s = String( s );
      while ( s.length < n ) s = " " + s;
      return s;
   }

   refresh()
   {
      this.sel = PSWEngine.select( this.rows, "review", this.table, this.overrides, this.available );
      this.updating = true;
      let nA = 0, nV = 0;
      for ( let i = 0; i < this.rows.length; ++i )
      {
         let r = this.rows[ i ], n = this.nodes[ i ];
         let a = this.sel.approved[ i ];
         if ( !r.failed ) { ++nV; if ( a ) ++nA; }
         if ( !r.failed ) n.checked = a;
         let status = r.failed ? "failed" : ( a ? "approved" : "rejected" ) + ( this.sel.manual[ i ] ? " (manual)" : "" );
         n.setText( 2, status );
         let reason = r.failed ? r.failReason : this.sel.reasons[ i ] || "";
         n.setText( this.colReason, reason );
         n.setToolTip( this.colReason, reason );
         let color = r.failed ? 0xff808080 : a ? 0xff000000 : 0xffd02020;
         for ( let c = 0; c <= this.colReason; ++c )
            n.setTextColor( c, color );
      }
      this.updating = false;
      this.countLabel.text = "Approved " + nA + " / " + nV + ( nV < this.rows.length ? " (" + ( this.rows.length - nV ) + " failed)" : "" );
      let nActive = PSWEngine.activeRules( this.table, this.available ).length;
      this.ruleInfo.text = nActive > 0 ? "Selection: rule table (" + nActive + " checked row" + ( nActive == 1 ? "" : "s" ) + ")" +
                                         ( this.chans ? ", every channel" : "" )
                                       : "Selection: no checked row - every measured frame approved";
      if ( PSWEngine.validateRuleTable( this.table, false ) )
         this.ruleInfo.text += " (invalid rows ignored)";
      this.graph.repaint();
   }

   paintGraph()
   {
      let G = this.graph;
      let g = new Graphics( G );
      try
      {
         let W = G.width, H = G.height;
         g.fillRect( 0, 0, W, H, new Brush( 0xff1b1f2a ) );
         g.antialiasing = true;
         let k = this.graphMetric;
         // Series: one (single channel) or one per shown channel ("All (R, G, B)").
         let series = !this.chans ? [ "" ] : this.viewCh == "All" ? this.chans : [ this.viewCh ];
         let xs = [], ys = [], cs = [];
         for ( let c of series )
            for ( let i = 0; i < this.rows.length; ++i )
            {
               let v = PSWEngine.metricsOf( this.rows[ i ], c )[ k ];
               if ( !this.rows[ i ].failed && isFinite( v ) ) { xs.push( i ); ys.push( v ); cs.push( c ); }
            }
         let ths = this.sel ? this.sel.thresholds.filter( t => t.metric == k && ( !t.ch || series.indexOf( t.ch ) >= 0 ) ) : [];
         let chColor = { R: 0xffff5a5a, G: 0xff4fd65a, B: 0xff5a8cff };
         let lo = Infinity, hi = -Infinity;
         for ( let v of ys ) { lo = Math.min( lo, v ); hi = Math.max( hi, v ); }
         for ( let t of ths ) if ( isFinite( t.value ) ) { lo = Math.min( lo, t.value ); hi = Math.max( hi, t.value ); }
         g.font = this.font;
         g.pen = new Pen( 0xffc8ccd4 );
         let fh = this.font.height;
         let ml = this.font.width( "0.000000e-00" ) + 8, mr = 12, mt = fh + 6, mb = fh + 10;
         g.drawText( 6, fh, k + " vs frame index" );
         if ( ys.length == 0 )
         {
            g.drawText( ml, H/2, "No valid values for " + k + "." );
            this.points = [];
            return;
         }
         if ( hi == lo ) { hi += Math.abs( hi )*0.05 + 1e-6; lo -= Math.abs( lo )*0.05 + 1e-6; }
         let pad = ( hi - lo )*0.08; hi += pad; lo -= pad;
         let n = this.rows.length;
         let px = i => ml + ( n <= 1 ? ( W - ml - mr )/2 : i*( W - ml - mr )/( n - 1 ) );
         let py = v => mt + ( hi - v )*( H - mt - mb )/( hi - lo );
         // axes
         g.pen = new Pen( 0xff5a6070 );
         g.drawLine( ml, mt, ml, H - mb );
         g.drawLine( ml, H - mb, W - mr, H - mb );
         g.pen = new Pen( 0xffc8ccd4 );
         g.drawText( 4, mt + fh/2, PSWEngine.fmt( hi ) );
         g.drawText( 4, H - mb, PSWEngine.fmt( lo ) );
         g.drawText( ml, H - 2, "1" );
         g.drawText( W - mr - this.font.width( String( n ) ), H - 2, String( n ) );
         // thresholds
         for ( let t of ths )
         {
            let y = py( t.value );
            g.pen = new Pen( t.ch ? chColor[ t.ch ] : 0xffe0a030, 1 );
            g.drawLine( ml, y, W - mr, y );
            g.drawText( ml + 4, y - 3, t.label );
         }
         // points
         let cur = this.tree.currentNode;
         let curIdx = cur ? parseInt( cur.text( 0 ) ) - 1 : -1;
         this.points = [];
         let r0 = 4;
         for ( let j = 0; j < xs.length; ++j )
         {
            let i = xs[ j ], x = px( i ), y = py( ys[ j ] );
            this.points.push( { i: i, x: x, y: y } );
            let a = this.sel && this.sel.approved[ i ];
            let manual = this.sel && this.sel.manual[ i ];
            let col = cs[ j ] ? chColor[ cs[ j ] ] : 0;
            if ( a )
            {
               g.pen = new Pen( col || 0xff60c0ff, 1 );
               g.brush = new Brush( col || 0xff60c0ff );
            }
            else
            {
               g.pen = new Pen( col || 0xffff4040, 1.5 );
               g.brush = new Brush( 0x00000000 );
            }
            if ( manual )
               g.drawRect( x - r0, y - r0, x + r0, y + r0 );
            else
               g.drawCircle( x, y, r0 );
            if ( i == curIdx )
            {
               g.pen = new Pen( 0xffffffff, 1 );
               g.brush = new Brush( 0x00000000 );
               g.drawCircle( x, y, r0 + 3 );
            }
         }
      }
      catch ( e ) {}
      finally
      {
         g.end();
      }
   }

   graphClick( x, y )
   {
      let best = -1, bd = 1e9;
      for ( let p of this.points )
      {
         let d = ( p.x - x )*( p.x - x ) + ( p.y - y )*( p.y - y );
         if ( d < bd ) { bd = d; best = p.i; }
      }
      if ( best < 0 || bd > 100 )
         return;
      let cur = this.sel ? this.sel.approved[ best ] : true;
      this.overrides[ best ] = !cur;
      this.refresh();
      let n = this.nodes[ best ];
      this.tree.currentNode = n;
      this.tree.setNodeIntoView( n );
   }
};

// ----------------------------------------------------------------------------
// Main dialog
// ----------------------------------------------------------------------------
var PSWDialog = class extends Dialog
{
   constructor( params, parent )
   {
      super( parent );

      this.params = params;
      let self = this;
      this.available = PSWEngine.availableMetrics();
      this.anyCFA = false;
      let labelWidth = this.font.width( "Debayer method:" ) + this.font.width( 'M' );

      this.helpLabel = new Label( this );
      this.helpLabel.frameStyle = FrameStyle.Box;
      this.helpLabel.margin = 6;
      this.helpLabel.wordWrapping = true;
      this.helpLabel.useRichText = true;
      // The branded header already shows the title, so the help text does not repeat it.
      let help = "Measures linear frames with SubframeSelector in small batches, on the central part of the frame " +
                 "(on one or all three debayered colour channels for CFA frames), selects them automatically, with your rules or in a review " +
                 "window, and copies the approved frames to the output folder with a CSV report. Input files are never modified.";
      this.helpLabel.text = PSW_BRANDED ? "<p>" + help + "</p>" : "<p><b>" + PSW_TITLE + "</b> &mdash; " + help + "</p>";
      this.helpLabel.toolTip = "<p>What this script does. Hover over any control for details.</p>";

      // ---------------- Input files
      this.fileTree = new TreeBox( this );
      this.fileTree.alternateRowColor = true;
      this.fileTree.rootDecoration = false;
      this.fileTree.multipleSelection = true;
      this.fileTree.headerVisible = true;
      this.fileTree.numberOfColumns = 4;
      this.fileTree.setHeaderText( 0, "File" );
      this.fileTree.setHeaderText( 1, "Size" );
      this.fileTree.setHeaderText( 2, "Scale" );
      this.fileTree.setHeaderText( 3, "CFA" );
      this.fileTree.setScaledMinSize( 560, 150 );
      this.fileTree.toolTip = "<p>Frames to analyse. Originals are never modified.</p>" +
                              "<p>XISF or FITS (.xisf .fit .fits .fts), linear, mono, RGB or CFA. Size = width x height x channels; " +
                              "Scale = arcsec/px from the header; CFA = Bayer pattern from the header.</p>";

      this.addFilesButton = new PushButton( this );
      this.addFilesButton.text = "Add files";
      this.addFilesButton.icon = this.scaledResource( ":/icons/add.png" );
      this.addFilesButton.toolTip = "<p>Add frames (XISF or FITS). The header of the first new file fills the frame parameters.</p>";
      this.addFilesButton.onClick = function()
      {
         let d = new OpenFileDialog;
         d.caption = "Select frames";
         d.multipleSelections = true;
         d.filters = [ [ "Image files", "*.xisf", "*.fit", "*.fits", "*.fts", "*.XISF", "*.FIT", "*.FITS", "*.FTS" ], [ "All files", "*" ] ];
         if ( self.params.lastDir && File.directoryExists( self.params.lastDir ) )
            d.initialPath = self.params.lastDir;
         if ( !d.execute() )
            return;
         if ( d.fileNames.length > 0 )
            self.params.lastDir = PSWEngine.dirOf( d.fileNames[ 0 ] );
         self.addFiles( d.fileNames );
      };

      this.addFolderButton = new PushButton( this );
      this.addFolderButton.text = "Add folder";
      this.addFolderButton.icon = this.scaledResource( ":/icons/folder.png" );
      this.addFolderButton.toolTip = "<p>Add every XISF/FITS file of a folder (.xisf, .fit, .fits, .fts, any letter case; " +
                                     "subfolders are not searched).</p>";
      this.addFolderButton.onClick = function()
      {
         let d = new GetDirectoryDialog;
         d.caption = "Select a folder of frames";
         if ( self.params.lastDir && File.directoryExists( self.params.lastDir ) )
            d.initialPath = self.params.lastDir;
         if ( !d.execute() )
            return;
         let dir = d.directory.replace( /[\/\\]+$/, "" );
         self.params.lastDir = dir;
         self.addFiles( PSWEngine.searchFolder( dir ) );
      };

      this.removeButton = new PushButton( this );
      this.removeButton.text = "Remove";
      this.removeButton.icon = this.scaledResource( ":/icons/remove.png" );
      this.removeButton.toolTip = "<p>Remove the selected files from the list (the files are not deleted).</p>";
      this.removeButton.onClick = function()
      {
         let sel = {};
         for ( let n of self.fileTree.selectedNodes ) sel[ n.toolTip( 0 ) ] = true;
         self.params.files = self.params.files.filter( p => !sel[ p ] );
         self.rebuildFileTree();
      };

      this.clearButton = new PushButton( this );
      this.clearButton.text = "Clear";
      this.clearButton.icon = this.scaledResource( ":/icons/clear.png" );
      this.clearButton.toolTip = "<p>Remove all files from the list (the files are not deleted).</p>";
      this.clearButton.onClick = function() { self.params.files = []; self.fileInfo = {}; self.rebuildFileTree(); };

      this.countLabel = new Label( this );
      this.countLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.countLabel.toolTip = "<p>Number of frames in the list.</p>";

      this.fileButtonsSizer = new HorizontalSizer;
      this.fileButtonsSizer.spacing = 6;
      this.fileButtonsSizer.add( this.addFilesButton );
      this.fileButtonsSizer.add( this.addFolderButton );
      this.fileButtonsSizer.add( this.removeButton );
      this.fileButtonsSizer.add( this.clearButton );
      this.fileButtonsSizer.addStretch();
      this.fileButtonsSizer.add( this.countLabel );

      this.inputGroup = new GroupBox( this );
      this.inputGroup.title = "Input frames";
      this.inputGroup.toolTip = this.fileTree.toolTip;
      this.inputGroup.sizer = new VerticalSizer;
      this.inputGroup.sizer.margin = 6;
      this.inputGroup.sizer.spacing = 6;
      this.inputGroup.sizer.add( this.fileTree, 100 );
      this.inputGroup.sizer.add( this.fileButtonsSizer );

      // ---------------- Output folder
      this.outLabel = new Label( this );
      this.outLabel.text = "Output folder:";
      this.outLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.outLabel.minWidth = labelWidth;
      this.outLabel.toolTip = "<p>Folder where approved frames and the report are written.</p>";
      this.outEdit = new Edit( this );
      this.outEdit.text = params.outputDir;
      this.outEdit.toolTip = "<p>Folder where approved frames and the report are written. It is created if needed. " +
                             "It must not be the folder of an input file. Existing files are never overwritten (a _1, _2 suffix is added).</p>";
      this.outEdit.onTextUpdated = function( t ) { self.params.outputDir = t.trim(); };
      this.outButton = new ToolButton( this );
      this.outButton.icon = this.scaledResource( ":/icons/select-file.png" );
      this.outButton.setScaledFixedSize( 22, 22 );
      this.outButton.toolTip = "<p>Select the output folder.</p>";
      this.outButton.onClick = function()
      {
         let d = new GetDirectoryDialog;
         d.caption = "Select the output folder";
         if ( self.params.outputDir && File.directoryExists( self.params.outputDir ) )
            d.initialPath = self.params.outputDir;
         else if ( self.params.lastDir && File.directoryExists( self.params.lastDir ) )
            d.initialPath = self.params.lastDir;
         if ( d.execute() )
         {
            self.params.outputDir = d.directory.replace( /[\/\\]+$/, "" );
            self.outEdit.text = self.params.outputDir;
         }
      };
      this.outSizer = new HorizontalSizer;
      this.outSizer.spacing = 4;
      this.outSizer.add( this.outLabel );
      this.outSizer.add( this.outEdit, 100 );
      this.outSizer.add( this.outButton );

      // ---------------- Frame parameters
      this.status = { scale: "", gain: "", bits: "" };
      let mkNum = ( label, tip, lo, hi, prec, value, key, statusKey ) =>
      {
         let ne = new NumericEdit( this );
         ne.label.text = label;
         ne.label.minWidth = labelWidth;
         ne.setReal( true );
         ne.setRange( lo, hi );
         ne.setPrecision( prec );
         ne.setValue( value );
         ne.edit.setFixedWidth( this.font.width( "000000.0000" ) );
         ne.toolTip = tip;
         ne.onValueUpdated = function( v ) { self.params[ key ] = v; self.setStatus( statusKey, "manual" ); };
         return ne;
      };
      this.scaleEdit = mkNum( "Scale (\"/px):",
         "<p>Image scale in arcsec per pixel. Filled from the header (SCALE/PIXSCALE or XPIXSZ/FOCALLEN) when available. " +
         "XPIXSZ is used as written by the capture software (N.I.N.A., SGP and ASIAIR already include binning): " +
         "check if you use binning. Debayered CFA frames keep this scale; only the SuperPixel method doubles it " +
         "(half-resolution image).</p>",
         0.01, 100, 4, params.subframeScale, "subframeScale", "scale" );
      this.gainEdit = mkNum( "Gain (e-/ADU):",
         "<p>Camera gain in e-/ADU (EGAIN). 0 = unknown: values are in data numbers. The GAIN keyword is a camera " +
         "setting, not e-/ADU, and is not used.</p>", 0, 100, 4, params.cameraGain, "cameraGain", "gain" );

      this.bitsLabel = new Label( this );
      this.bitsLabel.text = "Bit depth:";
      this.bitsLabel.minWidth = labelWidth;
      this.bitsLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.bitsLabel.toolTip = "<p>Sample bit depth of the frames (BITPIX). Sets the SFS camera resolution.</p>";
      this.bitsCombo = new ComboBox( this );
      for ( let b of PSW_BIT_DEPTHS ) this.bitsCombo.addItem( b == 32 ? "32 / float" : String( b ) );
      this.bitsCombo.currentItem = Math.max( 0, PSW_BIT_DEPTHS.indexOf( params.bitDepth ) );
      this.bitsCombo.toolTip = "<p>Sample bit depth of the frames (BITPIX). Sets the SFS camera resolution " +
                               "(32-bit and float data use the largest SFS setting, 16 bits).</p>";
      this.bitsCombo.onItemSelected = function( ix ) { self.params.bitDepth = PSW_BIT_DEPTHS[ ix ]; self.setStatus( "bits", "manual" ); };

      let mkStatus = () => { let l = new Label( this ); l.useRichText = true; l.toolTip = "<p>Where the value comes from: (from header), (manual) or (not found). " +
                             "A scale missing from the header keeps the previous value (shown in orange): check it.</p>"; l.minWidth = this.font.width( "(from header: XPIXSZ/FOCALLEN)" ); return l; };
      this.scaleStatus = mkStatus(); this.gainStatus = mkStatus(); this.bitsStatus = mkStatus();

      this.readHeaderButton = new PushButton( this );
      this.readHeaderButton.text = "Read from header";
      this.readHeaderButton.icon = this.scaledResource( ":/icons/document-edit.png" );
      this.readHeaderButton.toolTip = "<p>Fill scale, gain and bit depth from the header of the first file in the list.</p>";
      this.readHeaderButton.onClick = function()
      {
         if ( self.params.files.length == 0 )
         {
            ( new MessageBox( "Add frames first.", PSW_TITLE, StdIcon.Information, StdButton.Ok ) ).execute();
            return;
         }
         self.fillFromHeader( self.params.files[ 0 ] );
      };

      let row = ( a, b ) => { let s = new HorizontalSizer; s.spacing = 6; s.add( a ); s.add( b ); s.addStretch(); return s; };
      this.bitsRow = new HorizontalSizer;
      this.bitsRow.spacing = 4;
      this.bitsRow.add( this.bitsLabel );
      this.bitsRow.add( this.bitsCombo );
      this.frameGroup = new GroupBox( this );
      this.frameGroup.title = "Frame parameters";
      this.frameGroup.toolTip = "<p>Camera and optics values for SubframeSelector. They are read from the header when available.</p>";
      this.frameGroup.sizer = new VerticalSizer;
      this.frameGroup.sizer.margin = 6;
      this.frameGroup.sizer.spacing = 4;
      this.frameGroup.sizer.add( row( this.scaleEdit, this.scaleStatus ) );
      this.frameGroup.sizer.add( row( this.gainEdit, this.gainStatus ) );
      this.frameGroup.sizer.add( row( this.bitsRow, this.bitsStatus ) );
      let hb = new HorizontalSizer; hb.addStretch(); hb.add( this.readHeaderButton );
      this.frameGroup.sizer.add( hb );

      // ---------------- Measurement
      this.roiControl = new NumericControl( this );
      this.roiControl.label.text = "ROI (%):";
      this.roiControl.label.minWidth = labelWidth;
      this.roiControl.setReal( false );
      this.roiControl.setRange( 25, 100 );
      this.roiControl.slider.setRange( 25, 100 );
      this.roiControl.setValue( params.roiFraction );
      this.roiControl.toolTip = "<p>Measured part of width and height, centred. 50 = the central quarter of the area. " +
                                "Faster, and edge aberrations are ignored. 100 = the whole frame. The minimum ROI is 256x256 pixels.</p>";
      this.roiControl.onValueUpdated = function( v ) { self.params.roiFraction = Math.round( v ); };

      let mkCombo = ( label, items, cur, tip, onSel ) =>
      {
         let l = new Label( this );
         l.text = label;
         l.minWidth = labelWidth;
         l.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
         l.toolTip = tip;
         let c = new ComboBox( this );
         for ( let it of items ) c.addItem( it );
         c.currentItem = Math.max( 0, cur );
         c.toolTip = tip;
         c.onItemSelected = onSel;
         let s = new HorizontalSizer;
         s.spacing = 4;
         s.add( l );
         s.add( c );
         s.addStretch();
         return { label: l, combo: c, sizer: s };
      };
      this.cfa = mkCombo( "CFA handling:", [ "Auto (Debayer CFA frames)", "Off", "Debayer" ], PSW_CFA_HANDLING.indexOf( params.cfaHandling ),
         "<p><b>Off</b>: measure the files as they are (a raw CFA mosaic is then measured as a mono image, which " +
         "disturbs the star fits).<br/><b>Debayer</b>: the centred ROI of each CFA frame is debayered with the native " +
         "Debayer process and one colour channel is measured at full resolution.<br/><b>Auto</b>: Debayer for frames " +
         "with a Bayer pattern, Off for the others.</p>" +
         "<p>When a change turns CFA measurement on or off, \"Copy originals unchanged\" is set to match (on for CFA " +
         "measurement, off otherwise); you can change that option afterwards. The full frame is never loaded: only the ROI rows are read, one frame at a time.</p>",
         function( ix ) { self.params.cfaHandling = PSW_CFA_HANDLING[ ix ]; self.updateHint(); self.followMeasureType(); } );
      this.channel = mkCombo( "Channel:", [ "R", "G", "B", "All (R, G, B)" ], PSW_CFA_CHANNELS.indexOf( params.cfaChannel ),
         "<p>Colour channel of the debayered CFA frames that is measured. <b>G</b> (default) has twice as many " +
         "pixels in the Bayer pattern and the best signal for most targets; R and B are useful for narrowband " +
         "or very red/blue targets.</p>" +
         "<p><b>All (R, G, B)</b>: one debayering per frame, the three channels are measured separately (about three " +
         "times the SubframeSelector time). Every channel is tested against its own statistics and a frame is approved " +
         "only if it passes in <i>every</i> channel; reasons name the channel (\"B: FWHM ...\"). The review window, the " +
         "report and the exported metadata show the values per channel.</p>",
         function( ix ) { self.params.cfaChannel = PSW_CFA_CHANNELS[ ix ]; } );
      this.method = mkCombo( "Debayer method:", [ "VNG", "Bilinear", "SuperPixel (fast, half resolution)" ],
         PSW_DEBAYER_METHODS.indexOf( params.debayerMethod ),
         "<p><b>VNG</b> (default): the native Debayer process with variable number of gradients interpolation, full " +
         "ROI resolution; the best star shapes.<br/><b>Bilinear</b>: native Debayer, full resolution, faster and " +
         "slightly softer.<br/><b>SuperPixel</b>: the fast v1 mode without the Debayer process: one pixel per 2x2 " +
         "Bayer cell, a half-resolution image (equal to 2x2 binning, 1/4 of the ROI pixels). The image scale is " +
         "doubled for it, so FWHM in arcsec stays comparable, but small stars are measured on fewer pixels.</p>",
         function( ix ) { self.params.debayerMethod = PSW_DEBAYER_METHODS[ ix ]; } );
      this.bayer = mkCombo( "Bayer pattern:", PSW_BAYER, PSW_BAYER.indexOf( params.bayerOverride ),
         "<p>Pattern of the sensor. Auto reads BAYERPAT and XBAYROFF/YBAYROFF. A manual pattern replaces BAYERPAT; " +
         "the offsets still apply. For FITS frames with ROWORDER='BOTTOM-UP' (rows flipped on reading) the pattern " +
         "is flipped vertically to match.</p>",
         function( ix ) { self.params.bayerOverride = PSW_BAYER[ ix ]; } );
      this.psf = mkCombo( "PSF model:", PSW_PSF_MODELS, PSW_PSF_MODELS.indexOf( params.psfFit ),
         "<p>PSF model used by SFS for the star fits (FWHM, eccentricity, PSF signal weight).</p>",
         function( ix ) { self.params.psfFit = PSW_PSF_MODELS[ ix ]; } );

      this.batchLabel = new Label( this );
      this.batchLabel.text = "Batch size:";
      this.batchLabel.minWidth = labelWidth;
      this.batchLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.batchLabel.toolTip = "<p>Frames per SFS call. Lower values use less memory.</p>";
      this.batchSpin = new SpinBox( this );
      this.batchSpin.setRange( 1, 32 );
      this.batchSpin.value = params.batchSize;
      this.batchSpin.toolTip = "<p>Frames per SFS call (1-32). Lower values use less memory; 6 suits 8 GB of RAM with 26 MP frames.</p>";
      this.batchSpin.onValueUpdated = function( v ) { self.params.batchSize = v; };
      this.batchSizer = new HorizontalSizer;
      this.batchSizer.spacing = 4;
      this.batchSizer.add( this.batchLabel );
      this.batchSizer.add( this.batchSpin );
      this.batchSizer.addStretch();

      this.hintLabel = new Label( this );
      this.hintLabel.useRichText = true;
      this.hintLabel.text = "<font color=\"#E08000\">CFA frames detected: debayer them (CFA handling) for more reliable measurements</font>";
      this.hintLabel.toolTip = "<p>SFS measures a raw CFA mosaic as if it were a mono image; the colour pattern disturbs the star fits. " +
                               "Debayering and measuring one channel (G recommended) gives more reliable values: set CFA handling " +
                               "to Auto or Debayer.</p>";
      this.hintLabel.visible = false;

      this.measureGroup = new GroupBox( this );
      this.measureGroup.title = "Measurement";
      this.measureGroup.toolTip = "<p>How the frames are measured.</p>";
      this.measureGroup.sizer = new VerticalSizer;
      this.measureGroup.sizer.margin = 6;
      this.measureGroup.sizer.spacing = 4;
      this.measureGroup.sizer.add( this.roiControl );
      this.measureGroup.sizer.add( this.cfa.sizer );
      this.measureGroup.sizer.add( this.channel.sizer );
      this.measureGroup.sizer.add( this.method.sizer );
      this.measureGroup.sizer.add( this.bayer.sizer );
      this.measureGroup.sizer.add( this.psf.sizer );
      this.measureGroup.sizer.add( this.batchSizer );
      this.measureGroup.sizer.add( this.hintLabel );

      // ---------------- Mode
      let mkRadio = ( text, mode, tip ) =>
      {
         let r = new RadioButton( this );
         r.text = text;
         r.checked = params.mode == mode;
         r.toolTip = tip;
         r.onCheck = function( c ) { if ( c ) { self.params.mode = mode; self.updateMode(); } };
         return r;
      };
      this.autoRadio = mkRadio( "Auto", "auto", "<p>Auto: automatic robust rule (see the description below). No tuning needed.</p>" );
      this.rulesRadio = mkRadio( "Rule set", "rules", "<p>Rule set: the checked rows of the rule table, defined before measuring.</p>" );
      this.reviewRadio = mkRadio( "Review", "review", "<p>Review: measure, then check and edit the selection in a window " +
                                  "(table, graph, live rule table, manual overrides) before exporting.</p>" );
      this.radioSizer = new HorizontalSizer;
      this.radioSizer.spacing = 12;
      this.radioSizer.add( this.autoRadio );
      this.radioSizer.add( this.rulesRadio );
      this.radioSizer.add( this.reviewRadio );
      this.radioSizer.addStretch();

      this.ruleTable = new PSWRuleTable( this, params.ruleTable, this.available,
         function( table ) { self.params.ruleTable = table; } );
      this.ruleTable.toolTip = "<p>Rule table: a frame is approved if it passes every checked row. An empty cell means no " +
                               "limit on that side. Used in Rule set mode, and as the initial selection in Review mode " +
                               "(no checked row = every measured frame starts approved). Only checked rows reject; the Auto rule " +
                               "is used in Auto mode only. Greyed out in Auto mode.</p>";
      this.ruleHint = new Label( this );
      this.ruleHint.wordWrapping = true;
      this.ruleHint.text = "Empty cell = no limit. Sigma: k times the robust sigma around the median of all measured frames. " +
                           "%: percent of the median. Both sides set = a band.";
      this.ruleHint.toolTip = PSW_KIND_TIP;

      this.autoLabel = new Label( this );
      this.autoLabel.useRichText = true;
      this.autoLabel.wordWrapping = true;
      this.autoLabel.frameStyle = FrameStyle.Box;
      this.autoLabel.margin = 4;
      this.autoLabel.text = PSW_AUTO_RULE_TEXT;
      this.autoLabel.toolTip = "<p>The Auto rule, used in Auto mode only. With \"All (R, G, B)\" it is applied per channel " +
                               "and a frame is rejected when any channel fails it.</p>";

      this.modeGroup = new GroupBox( this );
      this.modeGroup.title = "Selection";
      this.modeGroup.toolTip = "<p>How frames are approved or rejected.</p>";
      this.modeGroup.sizer = new VerticalSizer;
      this.modeGroup.sizer.margin = 6;
      this.modeGroup.sizer.spacing = 6;
      this.modeGroup.sizer.add( this.radioSizer );
      this.modeGroup.sizer.add( this.ruleTable );
      this.modeGroup.sizer.add( this.ruleHint );
      this.modeGroup.sizer.add( this.autoLabel );

      // ---------------- Output options
      this.copyUnchangedCheck = new CheckBox( this );
      this.copyUnchangedCheck.text = "Copy originals unchanged";
      this.copyUnchangedCheck.checked = params.copyUnchanged;
      this.copyUnchangedCheck.toolTip = "<p><b>On</b>: copy the original files byte for byte (fastest, no added metadata).</p>" +
                                        "<p><b>Off</b>: approved frames are written as XISF with the measurements as FITS keywords " +
                                        "(SFS_FWHM, SFS_ECC ...; per channel SFS_FWHM_R/_G/_B ... with \"All (R, G, B)\") and XISF properties " +
                                        "(SmartFrameSelection:FWHM, SmartFrameSelection:R:FWHM ...). The pixels are written losslessly with the " +
                                        "same bit depth and sample format; CFA frames stay raw (never debayered). The original keywords, " +
                                        "image properties, colour filter array and ICC profile are kept (a FITS frame stored bottom-up " +
                                        "is written top-down, with ROWORDER removed and BAYERPAT adjusted).</p>" +
                                        "<p>Set automatically only when CFA measurement turns on or off (CFA handling or file list change): " +
                                        "on for CFA measurement, off for normal measurement. Channel and Debayer method changes never " +
                                        "touch it. You can change it afterwards; a saved choice is kept when the dialog opens.</p>" +
                                        "<p>Frames whose samples cannot be stored exactly in XISF (signed or scaled integer FITS, " +
                                        "scaled floating point FITS) are always copied unchanged; the console says why.</p>";
      this.copyUnchangedCheck.onCheck = function( c ) { self.params.copyUnchanged = c; };
      this.copyRejectedCheck = new CheckBox( this );
      this.copyRejectedCheck.text = "Also copy rejected frames";
      this.copyRejectedCheck.checked = params.copyRejected;
      this.copyRejectedCheck.toolTip = "<p>Also copy rejected frames to the \"rejected\" subfolder (byte copy). " +
                                       "Otherwise they are only listed in the CSV report.</p>";
      this.copyRejectedCheck.onCheck = function( c ) { self.params.copyRejected = c; };
      this.optSizer = new HorizontalSizer;
      this.optSizer.spacing = 12;
      this.optSizer.add( this.copyUnchangedCheck );
      this.optSizer.add( this.copyRejectedCheck );
      this.optSizer.addStretch();
      this.optGroup = new GroupBox( this );
      this.optGroup.title = "Output";
      this.optGroup.toolTip = "<p>What is written to the output folder. SFS_report.csv is always written.</p>";
      this.optGroup.sizer = new VerticalSizer;
      this.optGroup.sizer.margin = 6;
      this.optGroup.sizer.spacing = 4;
      this.optGroup.sizer.add( this.outSizer );
      this.optGroup.sizer.add( this.optSizer );

      // ---------------- Buttons
      this.runButton = new PushButton( this );
      this.runButton.text = "Run";
      this.runButton.icon = this.scaledResource( ":/icons/power.png" );
      this.runButton.toolTip = "<p>Measure, select and export. Press Abort in the Process Console to stop between batches " +
                               "(nothing is exported then).</p>";
      this.runButton.onClick = function() { self.runNow(); };

      this.closeButton = new PushButton( this );
      this.closeButton.text = "Close";
      this.closeButton.icon = this.scaledResource( ":/icons/close.png" );
      this.closeButton.toolTip = "<p>Close the dialog. Settings are saved; nothing is exported.</p>";
      this.closeButton.onClick = function() { self.ok(); };

      this.buttonsSizer = new HorizontalSizer;
      this.buttonsSizer.spacing = 6;
      this.buttonsSizer.addStretch();
      this.buttonsSizer.add( this.runButton );
      this.buttonsSizer.add( this.closeButton );

      // ---------------- Layout
      this.leftSizer = new VerticalSizer;
      this.leftSizer.spacing = 8;
      this.leftSizer.add( this.inputGroup, 100 );
      this.leftSizer.add( this.optGroup );

      this.rightSizer = new VerticalSizer;
      this.rightSizer.spacing = 8;
      this.rightSizer.add( this.frameGroup );
      this.rightSizer.add( this.measureGroup );
      this.rightSizer.addStretch();

      this.topSizer = new HorizontalSizer;
      this.topSizer.spacing = 8;
      this.topSizer.add( this.leftSizer, 100 );
      this.topSizer.add( this.rightSizer );

      this.bodySizer = new VerticalSizer;
      this.bodySizer.margin = 8;
      this.bodySizer.spacing = 8;
      this.bodySizer.add( this.helpLabel );
      this.bodySizer.add( this.topSizer, 100 );
      this.bodySizer.add( this.modeGroup );
      this.bodySizer.add( this.buttonsSizer );

      this.header = PSW_BRANDED ? new PSWHeader( this ) : null;
      this.sizer = new VerticalSizer;
      this.sizer.margin = 0;
      this.sizer.spacing = 0;
      if ( this.header != null )
         this.sizer.add( this.header );
      this.sizer.add( this.bodySizer, 100 );

      this.windowTitle = PSW_TITLE;
      this.fileInfo = {};
      this.params.files = ( this.params.files || [] ).slice();
      this.cfaActive = null;           // unknown until the list is non-empty (set in followMeasureType)
      this.rebuildFileTree();
      this.updateMode();
      this.setStatus( "scale", "" ); this.setStatus( "gain", "" ); this.setStatus( "bits", "" );
      this.setScaledMinWidth( 900 );
      this.adjustToContents();
   }

   setStatus( key, what )
   {
      let map = { scale: this.scaleStatus, gain: this.gainStatus, bits: this.bitsStatus };
      let l = map[ key ];
      if ( !l ) return;
      l.text = what == "" ? "" : what == "manual" ? "(manual)" : what == "missing" ? "(not found)" :
               what == "unknown" ? "(not in header: 0 = unknown)" :
               what == "keep" ? "<font color=\"#E08000\">Not in header: previous value kept, check it!</font>" :
               "(from header: " + what + ")";
   }

   probe( path )
   {
      if ( !( path in this.fileInfo ) )
      {
         try { this.fileInfo[ path ] = PSWEngine.probeFile( path ); }
         catch ( e ) { this.fileInfo[ path ] = { error: String( e.message || e ) }; }
      }
      return this.fileInfo[ path ];
   }

   addFiles( list )
   {
      let have = {};
      for ( let p of this.params.files ) have[ p ] = true;
      let added = [];
      for ( let p of list )
         if ( !have[ p ] ) { have[ p ] = true; this.params.files.push( p ); added.push( p ); }
      if ( added.length > 0 )
         this.fillFromHeader( added[ 0 ] );
      this.rebuildFileTree();
   }

   fillFromHeader( path )
   {
      let h = this.probe( path );
      if ( h.error )
      {
         console.warningln( "** " + path + ": " + h.error );
         return;
      }
      // Scale: kept when missing (it cannot be 0) but flagged; gain: reset to 0 = unknown,
      // so values of a previous camera never remain silently.
      if ( h.scale > 0 )
      {
         this.params.subframeScale = h.scale;
         this.scaleEdit.setValue( h.scale );
         this.setStatus( "scale", h.scaleSrc + ( h.binningAmbiguous ? ", check binning" : "" ) );
      }
      else this.setStatus( "scale", "keep" );
      let g = h.gain > 0 ? h.gain : 0;
      this.params.cameraGain = g;
      this.gainEdit.setValue( g );
      this.setStatus( "gain", g > 0 ? h.gainSrc : "unknown" );
      let bits = h.isFloat ? 32 : h.bitpix;
      let bi = PSW_BIT_DEPTHS.indexOf( bits );
      if ( bi >= 0 )
      {
         this.params.bitDepth = bits;
         this.bitsCombo.currentItem = bi;
         this.setStatus( "bits", h.isFloat ? "float" : "BITPIX" );
      }
      else this.setStatus( "bits", "missing" );
   }

   rebuildFileTree()
   {
      this.fileTree.clear();
      this.anyCFA = false;
      for ( let p of this.params.files )
      {
         let n = new TreeBoxNode( this.fileTree );
         n.setText( 0, File.extractNameAndExtension( p ) );
         n.setToolTip( 0, p );
         let h = this.probe( p );
         if ( h.error )
         {
            n.setText( 1, "error" );
            n.setToolTip( 1, h.error );
            n.setTextColor( 1, 0xffd02020 );
            continue;
         }
         n.setText( 1, h.width + "x" + h.height + ( h.channels > 1 ? "x" + h.channels : "" ) );
         n.setText( 2, h.scale > 0 ? h.scale.toFixed( 3 ) : "-" );
         n.setText( 3, h.cfa ? h.bayerPat : "-" );
         if ( h.cfa ) this.anyCFA = true;
      }
      for ( let c = 0; c < 4; ++c )
         this.fileTree.adjustColumnWidthToContents( c );
      this.countLabel.text = this.params.files.length + " frame" + ( this.params.files.length == 1 ? "" : "s" );
      this.updateHint();
      this.followMeasureType();
   }

   // CFA measurement active for the current settings and file list (Auto: when a CFA frame is listed).
   measureTypeIsCfa()
   {
      let h = this.params.cfaHandling;
      return h == "Debayer" || ( h == "Auto" && this.anyCFA );
   }

   // "Copy originals unchanged" follows the measurement type: on for CFA measurement, off for
   // normal measurement, set ONLY when CFA on/off flips (CFA handling or file list change), so a
   // manual choice survives every other change. Never on dialog open: cfaActive stays null (unknown)
   // while the list is empty; the first non-empty list only records the state, it does not flip it.
   followMeasureType()
   {
      if ( this.params.files.length == 0 )
      {
         this.cfaActive = null;
         return;
      }
      if ( this.cfaActive === null || this.cfaActive === undefined )
      {
         this.cfaActive = this.measureTypeIsCfa();
         return;
      }
      let cfa = this.measureTypeIsCfa();
      if ( cfa != this.cfaActive )
      {
         this.params.copyUnchanged = cfa;
         this.copyUnchangedCheck.checked = cfa;
      }
      this.cfaActive = cfa;
   }

   updateHint()
   {
      let off = this.params.cfaHandling == "Off";
      this.hintLabel.visible = this.anyCFA && off;
      for ( let c of [ this.channel, this.method ] )
         c.label.enabled = c.combo.enabled = !off;
   }

   updateMode()
   {
      let auto = this.params.mode == "auto";
      this.ruleTable.enabled = !auto;      // greyed out in Auto mode, the Auto rule is described below
      this.ruleHint.enabled = !auto;
      this.autoLabel.visible = auto;      // the Auto rule applies in Auto mode only
   }

   setBusy( busy )
   {
      for ( let c of [ this.inputGroup, this.optGroup, this.frameGroup, this.measureGroup, this.modeGroup,
                       this.runButton, this.closeButton ] )
         c.enabled = !busy;
   }

   runNow()
   {
      let p = this.params;
      p.clamp();
      let err = PSWEngine.validate( p );
      if ( err )
      {
         ( new MessageBox( err, PSW_TITLE, StdIcon.Error, StdButton.Ok ) ).execute();
         return;
      }
      p.save();
      let self = this;
      p.reviewCallback = function( rows, ctx )
      {
         let d = new PSWReviewDialog( rows, p, ctx && ctx.available, self );
         return d.execute() ? d.overrides : null;
      };
      // Only the inputs are disabled during the run: disabling the dialog itself would also
      // disable the review dialog, which is its child.
      this.setBusy( true );
      let res = null;
      try
      {
         console.show();
         res = PSWEngine.run( null, p );
      }
      catch ( e )
      {
         this.setBusy( false );
         console.criticalln( "*** " + ( e.message || e ) );
         ( new MessageBox( String( e.message || e ), PSW_TITLE, StdIcon.Error, StdButton.Ok ) ).execute();
         return;
      }
      finally
      {
         this.setBusy( false );
         p.reviewCallback = undefined;
      }
      this.ruleTable.setTable( p.ruleTable );
      p.save();
      let msg = "Frames: " + res.nInput + "\nMeasured: " + res.nMeasured + "\nFailed: " + res.nFailed +
                "\nApproved: " + res.nApproved + "\nRejected: " + res.nRejected + "\nExported: " + res.nExported +
                ( res.nExportFailed > 0 ? "\nExport failed: " + res.nExportFailed : "" ) +
                "\nTime: " + res.seconds.toFixed( 1 ) + " s" +
                ( PSWEngine.lastReportPath ? "\n\nReport: " + PSWEngine.lastReportPath : "" );
      console.noteln( "<end><cbr>" + msg.replace( /\n+/g, " | " ) );
      ( new MessageBox( msg, PSW_TITLE, res.nMeasured > 0 ? StdIcon.Information : StdIcon.Error, StdButton.Ok ) ).execute();
   }
};
