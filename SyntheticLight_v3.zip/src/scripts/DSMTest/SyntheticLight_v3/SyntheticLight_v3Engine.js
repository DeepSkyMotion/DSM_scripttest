// SyntheticLight_v3Engine.js - processing logic, no GUI objects allowed here.
//
// Contract used by the GUI and by the headless test harness:
//   new PSWParameters()         -> object with defaults, .load(), .save()
//   PSWEngine.run(view, params) -> creates a new mono window "SyntheticLight[_n]"
//                                  and returns an object with numbers worth logging
//   PSWEngine.validate(params, view) -> resolves the source views or throws Error

var PSW_PRESETS = [
   [ 0.25, 0.50, 0.25 ],       // 0: Colour CFA / OSC camera (Bayer RGGB 1:2:1)
   [ 0.2126, 0.7152, 0.0722 ]  // 1: Monochrome camera with RGB filters (Rec.709)
];

var PSWParameters = class
{
   constructor()
   {
      this.inputMode = 0;          // 0 = one colour view, 1 = three mono views
      this.viewIdColor = "";
      this.viewIdR = "";
      this.viewIdG = "";
      this.viewIdB = "";
      this.cameraType = 0;         // 0 = CFA/OSC, 1 = Mono + RGB filters, 2 = Custom
      this.weightR = 0.25;
      this.weightG = 0.50;
      this.weightB = 0.25;
      this.normalization = 0;      // 0 = None, 1 = Match backgrounds, 2 = Match backgrounds and scale
   }

   load()
   {
      let self = this;
      function rd( key, type, prop, lo, hi )
      {
         let v = Settings.read( PSW_SETTINGS + "/" + key, type );
         if ( Settings.lastReadOK && isFinite( v ) && v >= lo && v <= hi )
            self[prop] = v;
      }
      rd( "inputMode", DataType.Int32, "inputMode", 0, 1 );
      rd( "cameraType", DataType.Int32, "cameraType", 0, 2 );
      rd( "weightR", DataType.Double, "weightR", 0, 1 );
      rd( "weightG", DataType.Double, "weightG", 0, 1 );
      rd( "weightB", DataType.Double, "weightB", 0, 1 );
      rd( "normalization", DataType.Int32, "normalization", 0, 2 );
   }

   save()
   {
      Settings.write( PSW_SETTINGS + "/inputMode", DataType.Int32, this.inputMode );
      Settings.write( PSW_SETTINGS + "/cameraType", DataType.Int32, this.cameraType );
      Settings.write( PSW_SETTINGS + "/weightR", DataType.Double, this.weightR );
      Settings.write( PSW_SETTINGS + "/weightG", DataType.Double, this.weightG );
      Settings.write( PSW_SETTINGS + "/weightB", DataType.Double, this.weightB );
      Settings.write( PSW_SETTINGS + "/normalization", DataType.Int32, this.normalization );
   }
};

var PSWEngine = {

   // Raw (unnormalized) weights for the selected camera type.
   rawWeights: function( params )
   {
      let t = params.cameraType;
      if ( t == 0 || t == 1 )
         return PSW_PRESETS[t].slice();
      return [ params.weightR, params.weightG, params.weightB ];
   },

   // Normalized weights; throws on invalid values.
   weights: function( params )
   {
      let raw = this.rawWeights( params );
      let sum = 0;
      for ( let i = 0; i < 3; ++i )
      {
         if ( typeof raw[i] != "number" || !isFinite( raw[i] ) || raw[i] < 0 )
            throw new Error( "Weights must be finite and not negative." );
         sum += raw[i];
      }
      if ( !(sum > 0) )
         throw new Error( "All weights are zero." );
      return [ raw[0]/sum, raw[1]/sum, raw[2]/sum ];
   },

   resolveView: function( id )
   {
      if ( id == null || id == "" )
         return null;
      let w = ImageWindow.windowById( id );
      return (w == null || w.isNull) ? null : w.mainView;
   },

   // Returns { colorMode, views:[R,G,B] (mono mode) or [V,V,V] (colour mode), source }
   validate: function( params, view )
   {
      if ( ImageWindow.windows.length == 0 )
         throw new Error( "Open an image first." );
      this.weights( params );

      if ( params.inputMode == 0 )
      {
         let v = (view != null && !view.isNull) ? view : this.resolveView( params.viewIdColor );
         if ( v == null || v.isNull )
            throw new Error( "Select an RGB image." );
         if ( v.isPreview )
            throw new Error( "Previews are not supported. Select a main view." );
         if ( v.image.numberOfChannels != 3 )
            throw new Error( "Colour mode needs an RGB image (3 channels)." );
         return { colorMode: true, views: [ v, v, v ], source: v };
      }

      let names = [ "R", "G", "B" ];
      let v = [
         this.resolveView( params.viewIdR ),
         (params.viewIdG != "" && params.viewIdG != null) ? this.resolveView( params.viewIdG )
                                                         : ((view != null && !view.isNull) ? view : null),
         this.resolveView( params.viewIdB ) ];
      for ( let i = 0; i < 3; ++i )
      {
         if ( v[i] == null || v[i].isNull )
            throw new Error( "Select an image for the " + names[i] + " channel." );
         if ( v[i].isPreview )
            throw new Error( "Previews are not supported (" + names[i] + " channel). Select a main view." );
         if ( v[i].image.numberOfChannels != 1 )
            throw new Error( "The " + names[i] + " image must be a mono image (1 channel)." );
      }
      if ( v[0].fullId == v[1].fullId || v[0].fullId == v[2].fullId || v[1].fullId == v[2].fullId )
         throw new Error( "The R, G and B images must be three different images." );
      let w0 = v[0].image.width, h0 = v[0].image.height;
      for ( let i = 1; i < 3; ++i )
         if ( v[i].image.width != w0 || v[i].image.height != h0 )
            throw new Error( format( "Image size mismatch: R is %dx%d but %s is %dx%d. Register (align) the R, G and B images to each other first.",
                                     w0, h0, names[i], v[i].image.width, v[i].image.height ) );
      return { colorMode: false, views: v, source: v[1] };
   },

   // Literal with 10 significant digits (valid PixelMath number).
   lit: function( x )
   {
      return Number( x ).toPrecision( 10 );
   },

   uniqueId: function( base )
   {
      let id = base, n = 0;
      while ( !ImageWindow.windowById( id ).isNull )
         id = base + "_" + (++n);
      return id;
   },

   // Number of full-resolution statistics actually computed (median or MAD).
   // The preview tests use it to prove that weight changes reuse cached stats.
   statsCalls: 0,

   // Median (and MAD if needMad) of one channel of a view, full resolution.
   // cache: optional object, keyed by view id and channel; null = no caching.
   channelStats: function( view, ch, needMad, cache )
   {
      let key = view.fullId + "/" + ch;
      let e = cache ? cache[key] : null;
      if ( !e )
      {
         e = { med: undefined, mad: undefined };
         if ( cache )
            cache[key] = e;
      }
      let img = view.image;
      let r = img.bounds;
      if ( e.med === undefined )
      {
         e.med = img.median( r, ch, ch );
         ++this.statsCalls;
      }
      if ( needMad && e.mad === undefined )
      {
         e.mad = img.MAD( e.med, r, ch, ch );
         ++this.statsCalls;
      }
      return e;
   },

   // Coefficients of out = k[0]*R + k[1]*G + k[2]*B + C (then clip to [0,1]).
   // Shared by run() and the dialog preview, so both use exactly the same math.
   // previewOnly: skip statistics that only feed the "data look stretched" warning.
   coefficients: function( src, params, cache, previewOnly )
   {
      let w = this.weights( params );
      let norm = params.normalization;
      let names = [ "R", "G", "B" ];
      let m = [ 0, 0, 0 ], d = [ 0, 0, 0 ], s = [ 1, 1, 1 ];
      let warnings = [];
      let stretched = false;
      if ( !(previewOnly && norm == 0) )
         for ( let c = 0; c < 3; ++c )
         {
            let needed = w[c] > 0 || (norm == 2 && c == 1); // G is the scale reference
            if ( !needed )
               continue;
            let st = this.channelStats( src.views[c], src.colorMode ? c : 0, norm == 2, cache );
            if ( st.med > 0.1 && w[c] > 0 )
               stretched = true;
            if ( norm != 0 )
               m[c] = st.med;
            if ( norm == 2 )
               d[c] = st.mad;
         }
      if ( stretched )
         warnings.push( "Warning: data look stretched (a source median is above 0.1). Linear data is expected." );
      if ( norm == 2 )
         for ( let c = 0; c < 3; ++c )
         {
            if ( c == 1 || w[c] == 0 )
               continue;
            if ( d[c] <= 1e-9 || d[1] <= 1e-9 )
            {
               s[c] = 1;
               warnings.push( "Warning: channel " + names[c] + " (or G) has (nearly) zero MAD; scale set to 1." );
            }
            else
               s[c] = d[1]/d[c];
         }

      let M = 0;
      if ( norm != 0 )
         for ( let c = 0; c < 3; ++c )
            M += w[c]*m[c];
      let C = M;
      let k = [ 0, 0, 0 ];
      for ( let c = 0; c < 3; ++c )
      {
         if ( w[c] == 0 )
            continue;
         k[c] = w[c]*(norm == 2 ? s[c] : 1);
         if ( norm != 0 )
            C -= k[c]*m[c];
      }
      return { w: w, m: m, d: d, s: s, k: k, C: C, M: M, norm: norm, warnings: warnings };
   },

   // ---- Preview helpers (display only: no windows, sources are only read)

   // Average-binned copy of one channel: integer factors fx, fy, result w x h.
   binChannel: function( img, ch, fx, fy, w, h )
   {
      let W = img.width;
      let out = new Float32Array( w*h );
      if ( fx == 1 && fy == 1 )
      {
         img.getSamples( out, new Rect( 0, 0, w, h ), ch );
         return out;
      }
      let strip = new Float32Array( W*fy );
      let acc = new Float64Array( w );
      let inv = 1/(fx*fy);
      for ( let y = 0; y < h; ++y )
      {
         img.getSamples( strip, new Rect( 0, y*fy, W, y*fy + fy ), ch );
         acc.fill( 0 );
         for ( let r = 0; r < fy; ++r )
         {
            let rb = r*W;
            for ( let x = 0, b = rb; x < w; ++x, b += fx )
            {
               let sum = 0;
               for ( let j = 0; j < fx; ++j )
                  sum += strip[b + j];
               acc[x] += sum;
            }
         }
         let ob = y*w;
         for ( let x = 0; x < w; ++x )
            out[ob + x] = acc[x]*inv;
      }
      return out;
   },

   // Downsampled R, G, B planes of the validated sources, long side <= maxSide.
   downsample: function( src, maxSide )
   {
      let img0 = src.views[0].image;
      let W = img0.width, H = img0.height;
      let f = Math.max( 1, Math.ceil( Math.max( W, H )/maxSide ) );
      let fx = Math.min( f, W ), fy = Math.min( f, H );
      let w = Math.floor( W/fx ), h = Math.floor( H/fy );
      let data = [];
      for ( let c = 0; c < 3; ++c )
         data.push( this.binChannel( src.views[c].image, src.colorMode ? c : 0, fx, fy, w, h ) );
      return { width: w, height: h, factor: f, data: data };
   },

   // out = k0*R + k1*G + k2*B + C, clipped to [0,1], on the downsampled planes.
   combinePlanes: function( small, cf )
   {
      let n = small.width*small.height;
      let out = new Float32Array( n );
      let a0 = small.data[0], a1 = small.data[1], a2 = small.data[2];
      let k0 = cf.k[0], k1 = cf.k[1], k2 = cf.k[2], C = cf.C;
      for ( let i = 0; i < n; ++i )
      {
         let v = C;
         if ( k0 != 0 ) v += k0*a0[i];
         if ( k1 != 0 ) v += k1*a1[i];
         if ( k2 != 0 ) v += k2*a2[i];
         out[i] = v < 0 ? 0 : (v > 1 ? 1 : v);
      }
      return out;
   },

   // Display-only auto stretch (standard AutoSTF: shadows clip = median - 2.8*1.4826*MAD,
   // target background 0.25). Returns a new array; returns null if the data are flat.
   autoStretchPlane: function( data, width, height )
   {
      let tmp = new Image( data, width, height );
      let med, mad;
      try
      {
         med = tmp.median();
         mad = 1.4826*tmp.MAD( med );
      }
      finally
      {
         tmp.free();
      }
      let c0 = Math.min( 1, Math.max( 0, med - 2.8*mad ) );
      let mtf = function( m, x ) { return (x <= 0) ? 0 : ((x >= 1) ? 1 : (m - 1)*x/((2*m - 1)*x - m)); };
      let m = mtf( 0.25, med - c0 );
      if ( !(mad > 0) || !(c0 < 1) || !(m > 0 && m < 1) )
         return null;
      let n = data.length;
      let out = new Float32Array( n );
      let r = 1/(1 - c0);
      let a = m - 1, b = 2*m - 1;
      for ( let i = 0; i < n; ++i )
      {
         let x = (data[i] - c0)*r;
         out[i] = (x <= 0) ? 0 : ((x >= 1) ? 1 : a*x/(b*x - m));
      }
      return out;
   },

   run: function( view, params )
   {
      let src = this.validate( params, view );
      let w = this.weights( params );
      let norm = params.normalization;

      console.writeln( "<end><cbr>Mode: " + (src.colorMode ? "one colour image" : "three mono images") );
      console.writeln( "Camera preset: " + [ "Colour CFA / OSC", "Mono + RGB filters", "Custom" ][Math.min( 2, Math.max( 0, params.cameraType ) )] );
      console.writeln( format( "Normalized weights: %.4f / %.4f / %.4f", w[0], w[1], w[2] ) );
      console.writeln( "Normalization: " + [ "None", "Match backgrounds", "Match backgrounds and scale" ][norm] );
      if ( norm == 1 )
         console.noteln( "Note: Match backgrounds is identical to None for linear weights." );

      // ---- statistics (computed once, only what is needed) and coefficients
      let cf = this.coefficients( src, params, null, false );
      for ( let i = 0; i < cf.warnings.length; ++i )
         console.warningln( cf.warnings[i] );
      let m = cf.m, d = cf.d, s = cf.s, M = cf.M, C = cf.C;

      // ---- one PixelMath expression: sum k_c*X_c + C
      let ids = src.colorMode ? [ "$T[0]", "$T[1]", "$T[2]" ] : [ src.views[0].id, src.views[1].id, src.views[2].id ];
      let terms = [];
      for ( let c = 0; c < 3; ++c )
         if ( w[c] != 0 )
            terms.push( this.lit( cf.k[c] ) + "*" + ids[c] );
      let expr = terms.join( " + " );
      if ( norm != 0 && Math.abs( C ) >= 1e-12 )
         expr += (C < 0 ? " - " : " + ") + this.lit( Math.abs( C ) );

      let outId = this.uniqueId( "SyntheticLight" );
      let P = new PixelMath;
      P.expression = expr;
      P.useSingleExpression = true;
      P.createNewImage = true;
      P.showNewImage = false;
      P.newImageId = outId;
      P.newImageColorSpace = PixelMath.Gray;
      P.newImageSampleFormat = PixelMath.f32;
      P.rescale = false;
      P.truncate = true;
      P.truncateLower = 0;
      P.truncateUpper = 1;
      // In mono mode the target is the G view; it is not modified (createNewImage).
      let target = src.colorMode ? src.source : src.views[1];
      if ( !P.executeOn( target, false ) )
         throw new Error( "PixelMath failed." );

      let win = ImageWindow.windowById( outId );
      if ( win.isNull )
         throw new Error( "The output image was not created." );
      try
      {
         let srcWin = src.source.window;
         try { win.keywords = srcWin.keywords; } catch ( e ) {}
         try { win.copyAstrometricSolution( srcWin ); } catch ( e ) {}
         let oi = win.mainView.image;
         let outMedian = oi.median(), outMin = oi.minimum(), outMax = oi.maximum();
         win.show();
         win.bringToFront();
         console.writeln( format( "Medians: R=%.6f G=%.6f B=%.6f   MAD: R=%.6f G=%.6f B=%.6f", m[0], m[1], m[2], d[0], d[1], d[2] ) );
         console.writeln( format( "Scale: R=%.4f G=%.4f B=%.4f   M=%.6f", s[0], s[1], s[2], M ) );
         console.writeln( format( "Output %s: median=%.6f min=%.6f max=%.6f", outId, outMedian, outMin, outMax ) );
         return { wR: w[0], wG: w[1], wB: w[2], mR: m[0], mG: m[1], mB: m[2],
                  dR: d[0], dG: d[1], dB: d[2], sR: s[0], sG: s[1], sB: s[2],
                  kR: cf.k[0], kG: cf.k[1], kB: cf.k[2], C: C,
                  M: M, outMedian: outMedian, outMin: outMin, outMax: outMax, outId: outId };
      }
      catch ( e )
      {
         win.forceClose();
         throw e;
      }
   }
};

// Live preview state for the dialog: caches full-resolution statistics and the
// downsampled source planes per source selection. Never creates windows.
var PSWPreview = class
{
   constructor( maxSide )
   {
      this.maxSide = maxSide || 1024;
      this.key = "";
      this.cache = {};
      this.small = null;
      this.data = null;     // last combined (linear, clipped) Float32Array
      this.width = 0;
      this.height = 0;
      this.factor = 1;
      this.coefficients = null;
   }

   // Cheap content signature: size, channels and a 4x4 grid of sampled pixels per channel.
   signature( view )
   {
      let img = view.image;
      let w = img.width, h = img.height, nc = img.numberOfChannels;
      let s = w + "x" + h + "x" + nc;
      for ( let c = 0; c < nc; ++c )
         for ( let j = 0; j < 4; ++j )
            for ( let i = 0; i < 4; ++i )
               s += "," + img.sample( Math.min( w - 1, Math.floor( (i + 0.5)*w/4 ) ), Math.min( h - 1, Math.floor( (j + 0.5)*h/4 ) ), c );
      return s;
   }

   sourceKey( src )
   {
      return src.colorMode ? "C|" + src.source.fullId + "|" + this.signature( src.source )
                           : "M|" + src.views[0].fullId + "|" + this.signature( src.views[0] ) +
                             "|" + src.views[1].fullId + "|" + this.signature( src.views[1] ) +
                             "|" + src.views[2].fullId + "|" + this.signature( src.views[2] );
   }

   // Drops the cached statistics and downsampled planes (selection changed / dialog closed).
   invalidate()
   {
      this.key = "";
      this.cache = {};
      this.small = null;
   }

   free()
   {
      this.invalidate();
      this.data = null;
      this.coefficients = null;
      this.width = this.height = 0;
   }

   // Recomputes the preview. Returns { ok, error, ms }.
   update( params )
   {
      let t0 = Date.now();
      let src;
      try
      {
         src = PSWEngine.validate( params, null );
      }
      catch ( e )
      {
         this.invalidate();
         this.data = null;
         this.coefficients = null;
         return { ok: false, error: e.message, ms: Date.now() - t0 };
      }
      let key = this.sourceKey( src );
      if ( key != this.key || this.small == null )
      {
         this.invalidate();
         this.small = PSWEngine.downsample( src, this.maxSide );
         this.key = key;
      }
      let cf = PSWEngine.coefficients( src, params, this.cache, true );
      this.coefficients = cf;
      this.width = this.small.width;
      this.height = this.small.height;
      this.factor = this.small.factor;
      this.data = PSWEngine.combinePlanes( this.small, cf );
      return { ok: true, error: "", ms: Date.now() - t0 };
   }

   // Display plane: stretched copy if autoStretch, else the linear data.
   displayData( autoStretch )
   {
      if ( this.data == null )
         return null;
      this.flat = false;
      if ( autoStretch )
      {
         let st = PSWEngine.autoStretchPlane( this.data, this.width, this.height );
         if ( st != null )
            return st;
         this.flat = true;
      }
      return this.data;
   }
};
