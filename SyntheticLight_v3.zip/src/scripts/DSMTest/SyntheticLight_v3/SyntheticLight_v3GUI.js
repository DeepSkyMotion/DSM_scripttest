// SyntheticLight_v3GUI.js - dialog only. Reads/writes PSWParameters, never processes pixels.

var PSWDialog = class extends Dialog
{
   constructor( params, parent )
   {
      super( parent );

      this.params = params;
      let self = this;
      this.preview = new PSWPreview( 1024 );
      this.previewBitmap = null;
      this.previewTimer = new Timer;
      this.previewTimer.interval = 0.2;   // seconds; debounces slider drags
      this.previewTimer.singleShot = true;
      this.previewTimer.onTimeout = function() { self.refreshPreview(); };
      let labelWidth = this.font.width( "Normalized:" ) + this.font.width( 'M' );

      // Default views. Colour list: the active window if RGB, else the first RGB view.
      // Mono lists: views named like R / G / B (R, Red, M31_R, ...), else distinct mono views in order.
      // Nothing suitable -> the parameter stays empty (no meaningless default).
      {
         let active = ImageWindow.activeWindow;
         let wins = ImageWindow.windows;
         let colourIds = [], monoIds = [];
         for ( let i = 0; i < wins.length; ++i )
         {
            let nch = wins[i].mainView.image.numberOfChannels;
            if ( nch == 3 )
               colourIds.push( wins[i].mainView.id );
            else if ( nch == 1 )
               monoIds.push( wins[i].mainView.id );
         }
         if ( params.viewIdColor == "" )
         {
            if ( !active.isNull && active.mainView.image.numberOfChannels == 3 )
               params.viewIdColor = active.mainView.id;
            else if ( colourIds.length > 0 )
               params.viewIdColor = colourIds[0];
         }
         let monoProps = [ "viewIdR", "viewIdG", "viewIdB" ];
         let monoPat = [ "(r|red)", "(g|green)", "(b|blue)" ];
         let used = [];
         for ( let i = 0; i < 3; ++i )
            if ( params[monoProps[i]] != "" )
               used.push( params[monoProps[i]] );
         for ( let i = 0; i < 3; ++i )
         {
            if ( params[monoProps[i]] != "" )
               continue;
            let re = new RegExp( "^" + monoPat[i] + "$|[_\\-. ]" + monoPat[i] + "$|^" + monoPat[i] + "[_\\-. ]", "i" );
            for ( let j = 0; j < monoIds.length; ++j )
               if ( used.indexOf( monoIds[j] ) < 0 && re.test( monoIds[j] ) )
               {
                  params[monoProps[i]] = monoIds[j];
                  used.push( monoIds[j] );
                  break;
               }
         }
         for ( let i = 0; i < 3; ++i )
         {
            if ( params[monoProps[i]] != "" )
               continue;
            for ( let j = 0; j < monoIds.length; ++j )
               if ( used.indexOf( monoIds[j] ) < 0 )
               {
                  params[monoProps[i]] = monoIds[j];
                  used.push( monoIds[j] );
                  break;
               }
         }
      }

      this.helpLabel = new Label( this );
      this.helpLabel.frameStyle = FrameStyle.Box;
      this.helpLabel.margin = 6;
      this.helpLabel.wordWrapping = true;
      this.helpLabel.useRichText = true;
      this.helpLabel.text = "<p><b>" + PSW_TITLE + "</b> &mdash; Creates a synthetic monochrome luminance " +
         "image from R, G and B. Expects linear data. Sources are not modified.</p>";

      // ---- Input
      this.colorRadio = new RadioButton( this );
      this.colorRadio.text = "One RGB colour image";
      this.colorRadio.toolTip = "<p>Use one RGB image, or three separate mono images.</p>";
      this.colorRadio.checked = params.inputMode == 0;
      this.colorRadio.onCheck = function( checked ) { if ( checked ) { self.params.inputMode = 0; self.updateEnabled(); self.schedulePreview(); } };

      this.monoRadio = new RadioButton( this );
      this.monoRadio.text = "Three mono images (R, G, B)";
      this.monoRadio.toolTip = "<p>Use one RGB image, or three separate mono images.</p><p>Separate R, G and B images must be registered (aligned) to each other, e.g. with StarAlignment, and have the same size.</p>";
      this.monoRadio.checked = params.inputMode == 1;
      this.monoRadio.onCheck = function( checked ) { if ( checked ) { self.params.inputMode = 1; self.updateEnabled(); self.schedulePreview(); } };

      function makeViewList( label, tip, prop )
      {
         let lbl = new Label( self );
         lbl.text = label;
         lbl.minWidth = labelWidth;
         lbl.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;
         let vl = new ViewList( self );
         vl.getMainViews();
         vl.toolTip = tip;
         if ( params[prop] != "" )
         {
            let w = ImageWindow.windowById( params[prop] );
            if ( !w.isNull )
               vl.currentView = w.mainView;
         }
         // ViewList replaces its tooltip with the selected view's info, so set ours again.
         vl.onViewSelected = function( view ) { self.params[prop] = view.isNull ? "" : view.id; vl.toolTip = tip; self.schedulePreview(); };
         // Nothing chosen -> show an empty selection instead of the first view.
         if ( params[prop] == "" )
            vl.currentView = View.null;
         vl.toolTip = tip;
         lbl.toolTip = tip;
         let s = new HorizontalSizer;
         s.spacing = 6;
         s.add( lbl );
         s.add( vl, 100 );
         return { sizer: s, label: lbl, list: vl };
      }
      this.cRow = makeViewList( "Colour:", "<p>RGB image to take the channels from.</p>", "viewIdColor" );
      this.rRow = makeViewList( "R:", "<p>Mono image for the red channel.</p><p>Separate R, G and B images must be registered (aligned) to each other, e.g. with StarAlignment, and have the same size.</p>", "viewIdR" );
      this.gRow = makeViewList( "G:", "<p>Mono image for the green channel.</p><p>Separate R, G and B images must be registered (aligned) to each other, e.g. with StarAlignment, and have the same size.</p>", "viewIdG" );
      this.bRow = makeViewList( "B:", "<p>Mono image for the blue channel.</p><p>Separate R, G and B images must be registered (aligned) to each other, e.g. with StarAlignment, and have the same size.</p>", "viewIdB" );

      this.registrationNote = new Label( this );
      this.registrationNote.wordWrapping = true;
      this.registrationNote.useRichText = true;
      this.registrationNote.text = "<i>Separate R, G and B images must be registered (aligned) to each other, e.g. with StarAlignment, and have the same size.</i>";

      this.inputGroup = new GroupBox( this );
      this.inputGroup.title = "Input";
      this.inputGroup.sizer = new VerticalSizer;
      this.inputGroup.sizer.margin = 8;
      this.inputGroup.sizer.spacing = 6;
      this.inputGroup.sizer.add( this.colorRadio );
      this.inputGroup.sizer.add( this.cRow.sizer );
      this.inputGroup.sizer.add( this.monoRadio );
      this.inputGroup.sizer.add( this.rRow.sizer );
      this.inputGroup.sizer.add( this.gRow.sizer );
      this.inputGroup.sizer.add( this.bRow.sizer );
      this.inputGroup.sizer.add( this.registrationNote );

      // ---- Weights
      this.cameraLabel = new Label( this );
      this.cameraLabel.text = "Camera / source type:";
      this.cameraLabel.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;

      this.cameraCombo = new ComboBox( this );
      this.cameraCombo.addItem( "Colour CFA / OSC camera (1:2:1)" );
      this.cameraCombo.addItem( "Monochrome camera with RGB filters (Rec.709)" );
      this.cameraCombo.addItem( "Custom" );
      this.cameraCombo.toolTip =
         "<p><b>Camera / source type</b>: sets the R:G:B weights.</p>" +
         "<p><b>Colour CFA / OSC camera</b> (0.25 / 0.50 / 0.25): one-shot-colour data. A Bayer RGGB matrix has twice as many green pixels, so G carries about half of the real signal and has the best SNR. Use it for any debayered OSC stack, or for R, G, B channels extracted from one.</p>" +
         "<p><b>Monochrome camera with RGB filters</b> (Rec.709: 0.2126 / 0.7152 / 0.0722): separate R, G, B masters from a mono camera. The weights follow the eye's luminance response, so the result looks like natural brightness. Best when the three masters have similar exposure and SNR.</p>" +
         "<p><b>Custom</b>: your own weights. For example, favour the cleanest channel, set a noisy or gradient-heavy channel to 0, or use equal 1:1:1 weights. Editing any weight switches to Custom. Weights are normalized to sum 1.</p>";
      this.cameraLabel.toolTip = this.cameraCombo.toolTip;
      this.cameraCombo.currentItem = params.cameraType >= 0 && params.cameraType <= 2 ? params.cameraType : 2;
      this.cameraCombo.onItemSelected = function( index )
      {
         self.params.cameraType = index;
         if ( index < 2 )
         {
            self.params.weightR = PSW_PRESETS[index][0];
            self.params.weightG = PSW_PRESETS[index][1];
            self.params.weightB = PSW_PRESETS[index][2];
            self.syncWeights();
         }
         self.updateNormalized();
         self.schedulePreview();
      };

      let cameraSizer = new HorizontalSizer;
      cameraSizer.spacing = 6;
      cameraSizer.add( this.cameraLabel );
      cameraSizer.add( this.cameraCombo, 100 );

      function makeWeight( label, prop )
      {
         let nc = new NumericControl( self );
         nc.label.text = label;
         nc.label.minWidth = labelWidth;
         nc.setRange( 0, 1 );
         nc.slider.setRange( 0, 1000 );
         nc.setPrecision( 4 );
         nc.setValue( params[prop] );
         nc.toolTip = "<p>Relative weight of the channel. Weights are normalized to sum 1.</p>";
         nc.onValueUpdated = function( value )
         {
            self.params[prop] = value;
            self.params.cameraType = 2;
            self.cameraCombo.currentItem = 2;
            self.updateNormalized();
            self.schedulePreview();
         };
         return nc;
      }
      this.wR = makeWeight( "Red:", "weightR" );
      this.wG = makeWeight( "Green:", "weightG" );
      this.wB = makeWeight( "Blue:", "weightB" );

      this.normLabel = new Label( this );
      this.normLabel.useRichText = true;

      this.weightsGroup = new GroupBox( this );
      this.weightsGroup.title = "Weights";
      this.weightsGroup.sizer = new VerticalSizer;
      this.weightsGroup.sizer.margin = 8;
      this.weightsGroup.sizer.spacing = 6;
      this.weightsGroup.sizer.add( cameraSizer );
      this.weightsGroup.sizer.add( this.wR );
      this.weightsGroup.sizer.add( this.wG );
      this.weightsGroup.sizer.add( this.wB );
      this.weightsGroup.sizer.add( this.normLabel );

      // ---- Normalization
      this.normCombo = new ComboBox( this );
      this.normCombo.addItem( "None" );
      this.normCombo.addItem( "Match backgrounds" );
      this.normCombo.addItem( "Match backgrounds and scale" );
      this.normCombo.currentItem = params.normalization;
      this.normCombo.toolTip =
         "<p><b>Normalization</b>: how the channels are matched before they are combined. Everything stays linear; nothing is stretched.</p>" +
         "<p><b>None</b> (recommended default): plain weighted average of the original channels. Use it for calibrated, colour-balanced linear data, e.g. after background extraction and colour calibration.</p>" +
         "<p><b>Match backgrounds</b>: subtracts each channel's median and adds back their weighted mean. With weights that sum to 1 the result is identical to None. Kept for comparison.</p>" +
         "<p><b>Match backgrounds and scale</b>: also scales each channel so its dispersion (MAD) matches the G channel before weighting. Use it when the channels differ strongly in brightness or noise, e.g. mono R/G/B masters with different exposure times, or an OSC stack before colour calibration. Avoid it when a channel is dominated by bright nebulosity or strong gradients, because then MAD measures signal rather than noise.</p>";
      this.normCombo.onItemSelected = function( index ) { self.params.normalization = index; self.schedulePreview(); };

      this.normGroup = new GroupBox( this );
      this.normGroup.title = "Normalization";
      this.normGroup.toolTip = this.normCombo.toolTip;
      this.normGroup.sizer = new VerticalSizer;
      this.normGroup.sizer.margin = 8;
      this.normGroup.sizer.spacing = 6;
      this.normGroup.sizer.add( this.normCombo );

      // ---- Buttons
      this.okButton = new PushButton( this );
      this.okButton.text = "Create";
      this.okButton.icon = this.scaledResource( ":/icons/ok.png" );
      this.okButton.onClick = function()
      {
         try
         {
            PSWEngine.validate( self.params, null );
         }
         catch ( e )
         {
            (new MessageBox( e.message, PSW_TITLE, StdIcon.Error, StdButton.Ok )).execute();
            return;
         }
         self.ok();
      };

      this.cancelButton = new PushButton( this );
      this.cancelButton.text = "Cancel";
      this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
      this.cancelButton.onClick = function() { self.cancel(); };

      this.resetButton = new PushButton( this );
      this.resetButton.text = "Reset";
      this.resetButton.icon = this.scaledResource( ":/icons/reload.png" );
      this.resetButton.onClick = function()
      {
         let d = new PSWParameters;
         self.params.cameraType = d.cameraType;
         self.params.weightR = d.weightR;
         self.params.weightG = d.weightG;
         self.params.weightB = d.weightB;
         self.params.normalization = d.normalization;
         self.cameraCombo.currentItem = d.cameraType;
         self.normCombo.currentItem = d.normalization;
         self.syncWeights();
         self.updateNormalized();
         self.schedulePreview();
      };

      // ---- Preview (display only)
      this.previewControl = new Control( this );
      this.previewControl.setScaledMinSize( 400, 300 );
      this.previewControl.toolTip = "<p>Live preview of the result, downsampled. Display only: the final image is computed at full resolution when you press Create.</p>";
      this.previewControl.onPaint = function( x0, y0, x1, y1 )
      {
         let pc = self.previewControl;
         let g = new Graphics( pc );
         try
         {
            self.paintPreview( g, pc.width, pc.height );
         }
         finally
         {
            g.end();
         }
      };

      this.autoStretchCheck = new CheckBox( this );
      this.autoStretchCheck.text = "Auto-stretch";
      this.autoStretchCheck.checked = true;
      this.autoStretchCheck.toolTip = "<p>Show the preview with an automatic screen stretch (like STF AutoStretch). Display only; the result stays linear.</p>";
      this.autoStretchCheck.onCheck = function( checked ) { self.renderPreview(); };

      this.previewStatus = new Label( this );
      this.previewStatus.wordWrapping = true;
      this.previewStatus.setScaledFixedHeight( 34 );
      this.previewStatus.text = "Preview: waiting...";

      this.previewGroup = new GroupBox( this );
      this.previewGroup.title = "Preview";
      this.previewGroup.sizer = new VerticalSizer;
      this.previewGroup.sizer.margin = 8;
      this.previewGroup.sizer.spacing = 6;
      this.previewGroup.sizer.add( this.previewControl, 100 );
      this.previewGroup.sizer.add( this.autoStretchCheck );
      this.previewGroup.sizer.add( this.previewStatus );

      this.onHide = function() { self.releasePreview(); };

      this.buttonsSizer = new HorizontalSizer;
      this.buttonsSizer.spacing = 6;
      this.buttonsSizer.add( this.resetButton );
      this.buttonsSizer.addStretch();
      this.buttonsSizer.add( this.okButton );
      this.buttonsSizer.add( this.cancelButton );

      this.leftSizer = new VerticalSizer;
      this.leftSizer.spacing = 8;
      this.leftSizer.add( this.helpLabel );
      this.leftSizer.add( this.inputGroup );
      this.leftSizer.add( this.weightsGroup );
      this.leftSizer.add( this.normGroup );
      this.leftSizer.addStretch();

      this.columnsSizer = new HorizontalSizer;
      this.columnsSizer.spacing = 8;
      this.columnsSizer.add( this.leftSizer );
      this.columnsSizer.add( this.previewGroup, 100 );

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 8;
      this.sizer.add( this.columnsSizer, 100 );
      this.sizer.add( this.buttonsSizer );

      this.windowTitle = PSW_TITLE;
      this.setScaledMinWidth( 900 );
      this.updateEnabled();
      this.updateNormalized();
      this.adjustToContents();
      this.schedulePreview();
   }

   // Restarts the debounce timer; the preview is recomputed when it fires.
   schedulePreview()
   {
      if ( this.previewTimer == null )
         return;
      this.previewTimer.stop();
      this.previewTimer.start();
   }

   // Recomputes the preview now (statistics and downsampled planes are cached).
   refreshPreview()
   {
      if ( this.previewTimer != null )
         this.previewTimer.stop();
      let r;
      try
      {
         r = this.preview.update( this.params );
      }
      catch ( e )
      {
         this.preview.invalidate();
         this.preview.data = null;
         this.preview.coefficients = null;
         this.previewStatus.text = e.message;
         if ( this.previewBitmap != null )
         {
            this.previewBitmap.clear();
            this.previewBitmap = null;
         }
         this.renderPreview();
         return { ok: false, error: e.message, ms: 0 };
      }
      this.lastPreviewMs = r.ms;
      if ( !r.ok )
         this.previewStatus.text = r.error;
      else if ( this.preview.factor > 1 )
         this.previewStatus.text = format( "Preview 1/%d scale, %dx%d", this.preview.factor, this.preview.width, this.preview.height );
      else
         this.previewStatus.text = format( "Preview full scale, %dx%d", this.preview.width, this.preview.height );
      this.renderPreview();
      return r;
   }

   // Converts the current preview data to a Bitmap (auto-stretched if enabled).
   renderPreview()
   {
      if ( this.previewBitmap != null )
      {
         this.previewBitmap.clear();
         this.previewBitmap = null;
      }
      let d = this.preview.displayData( this.autoStretchCheck.checked );
      let note = " (flat image: shown linear)";
      let st = this.previewStatus.text;
      if ( st.endsWith( note ) )
         st = st.substring( 0, st.length - note.length );
      this.previewStatus.text = (d != null && this.preview.flat) ? st + note : st;
      if ( d != null )
      {
         let img = new Image( d, this.preview.width, this.preview.height );
         try
         {
            this.previewBitmap = img.render();
         }
         finally
         {
            img.free();
         }
      }
      this.previewControl.update();
   }

   // Draws the preview bitmap scaled to fit (aspect kept, centred) on a dark background.
   paintPreview( g, cw, ch )
   {
      g.fillRect( 0, 0, cw, ch, new Brush( 0xff202020 ) );
      let bmp = this.previewBitmap;
      if ( bmp == null || bmp.width < 1 || bmp.height < 1 || cw < 1 || ch < 1 )
         return;
      let sc = Math.min( cw/bmp.width, ch/bmp.height );
      let dw = Math.max( 1, Math.round( bmp.width*sc ) ), dh = Math.max( 1, Math.round( bmp.height*sc ) );
      let x0 = Math.floor( (cw - dw)/2 ), y0 = Math.floor( (ch - dh)/2 );
      g.smoothInterpolation = true;
      g.drawScaledBitmap( new Rect( x0, y0, x0 + dw, y0 + dh ), bmp );
   }

   // Frees all preview memory and stops the timer (dialog closed).
   releasePreview()
   {
      if ( this.previewTimer != null )
         this.previewTimer.stop();
      if ( this.previewBitmap != null )
      {
         this.previewBitmap.clear();
         this.previewBitmap = null;
      }
      this.preview.free();
   }

   syncWeights()
   {
      this.wR.setValue( this.params.weightR );
      this.wG.setValue( this.params.weightG );
      this.wB.setValue( this.params.weightB );
   }

   updateEnabled()
   {
      let color = this.params.inputMode == 0;
      this.colorRadio.checked = color;
      this.monoRadio.checked = !color;
      this.cRow.list.enabled = color;
      this.cRow.label.enabled = color;
      for ( let r of [ this.rRow, this.gRow, this.bRow ] )
      {
         r.list.enabled = !color;
         r.label.enabled = !color;
      }
      this.registrationNote.enabled = !color;
   }

   updateNormalized()
   {
      let txt;
      try
      {
         let w = PSWEngine.weights( this.params );
         txt = format( "Normalized: %.3f / %.3f / %.3f", w[0], w[1], w[2] );
      }
      catch ( e )
      {
         txt = "Normalized: " + e.message;
      }
      this.normLabel.text = txt;
   }
};
