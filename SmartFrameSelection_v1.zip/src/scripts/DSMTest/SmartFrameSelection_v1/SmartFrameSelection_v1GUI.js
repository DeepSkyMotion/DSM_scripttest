// SmartFrameSelection_v1GUI.js - dialog only. Reads/writes PSWParameters, never processes pixels.
// V8 engine style: ES6 class extends Dialog, enums as Namespace.Value (FrameStyle.Box ...).

// Branded header strip (reference/branding.md). Pure display, never throws:
// a missing asset is simply skipped. SVGs are rendered once at physical size;
// onPaint only blits. Keep it unless the user asks to remove branding.
var PSWHeader = class extends Control
{
   constructor( parent )
   {
      super( parent );
      let self = this;
      this.iconBitmap = null;
      this.logoBitmap = null;
      this.titleFont = null;
      this.subFont = null;
      let s = 1;
      try { s = this.logicalPixelsToPhysical( 1 ); } catch ( e ) {}
      this.s = s;
      this.setScaledFixedHeight( 64 );
      let dir = File.extractDrive( #__FILE__ ) + File.extractDirectory( #__FILE__ ) + "/";
      try
      {
         if ( File.exists( dir + PSW_ICON ) )
            this.iconBitmap = Bitmap.fromSVGFile( dir + PSW_ICON, Math.round( 44*s ), Math.round( 44*s ) );
      }
      catch ( e ) { this.iconBitmap = null; }
      try
      {
         // brand_logo.svg: white logotype on transparent background; keep its aspect ratio.
         let f = dir + "brand_logo.svg";
         if ( File.exists( f ) )
         {
            let h = Math.round( 22*s );
            let w = 4*h;
            let vb = /viewBox="\s*[-\d.]+[\s,]+[-\d.]+[\s,]+([\d.]+)[\s,]+([\d.]+)/.exec( File.readTextFile( f ) );
            if ( vb != null && parseFloat( vb[2] ) > 0 )
               w = Math.round( h*parseFloat( vb[1] )/parseFloat( vb[2] ) );
            this.logoBitmap = Bitmap.fromSVGFile( f, w, h );
         }
      }
      catch ( e ) { this.logoBitmap = null; }
      try
      {
         let base = this.font;
         this.subFont = new Font( base.family, base.pointSize );
         this.titleFont = new Font( base.family, base.pointSize*1.35 );
         this.titleFont.bold = true;
      }
      catch ( e ) { this.titleFont = this.subFont = null; }

      this.onPaint = function( x0, y0, x1, y1 )
      {
         let g = new Graphics( self );
         try { self.paintHeader( g, self.width, self.height ); }
         catch ( e ) {}
         finally { g.end(); }
      };
   }

   paintHeader( g, w, h )
   {
      let s = this.s;
      g.fillRect( 0, 0, w, h, new Brush( 0xff0B1121 ) );
      let textX = Math.round( 12*s );
      if ( this.iconBitmap != null && this.iconBitmap.width > 0 )
      {
         g.drawBitmap( Math.round( 12*s ), Math.round( (h - this.iconBitmap.height)/2 ), this.iconBitmap );
         textX += this.iconBitmap.width + Math.round( 12*s );
      }
      if ( this.titleFont != null && this.subFont != null )
      {
         g.antialiasing = true;
         g.textAntialiasing = true;
         let th = this.titleFont.height, sh = this.subFont.height;
         let top = Math.round( (h - th - sh)/2 );
         g.font = this.titleFont;
         g.pen = new Pen( 0xffF8F9F9 );
         g.drawText( textX, top + this.titleFont.ascent, PSW_TITLE );
         g.font = this.subFont;
         g.pen = new Pen( 0xff9AA3B5 );
         g.drawText( textX, top + th + this.subFont.ascent, PSW_TAGLINE + "  ·  v" + PSW_VERSION );
      }
      if ( this.logoBitmap != null && this.logoBitmap.width > 0 )
      {
         g.smoothInterpolation = true;
         g.drawBitmap( w - Math.round( 14*s ) - this.logoBitmap.width, Math.round( (h - this.logoBitmap.height)/2 ), this.logoBitmap );
      }
   }
};

// ----------------------------------------------------------------------------
// Shared texts
// ----------------------------------------------------------------------------
var PSW_AUTO_RULE_TEXT =
   "<p><b>Auto rule</b> (robust statistics of this session plus absolute caps). A frame is rejected when:</p>" +
   "<ul>" +
   "<li>FWHM &gt; median + 2.5&sigma; (bad seeing, focus drift; high side only)</li>" +
   "<li>Eccentricity &gt; max(median + 3&sigma;, 0.70); never below 0.55</li>" +
   "<li>PSF Signal Weight &lt; median &minus; 2.5&sigma;</li>" +
   "<li>Stars &lt; 50% of the median (clouds, dew)</li>" +
   "<li>Median (background) &gt; median + 3&sigma; (moon, dawn, light pollution)</li>" +
   "</ul>" +
   "<p>&sigma; = 1.4826&middot;MAD with a small floor, so a very uniform session is not cut for noise. " +
   "Two passes (the second on the survivors). Fewer than 5 frames: only the absolute caps. " +
   "If more than 40% would be rejected, the best 60% by PSF Signal Weight are kept.</p>";

var PSW_DIR_ITEMS = [ [ "above", "reject if above" ], [ "below", "reject if below" ] ];
var PSW_KIND_ITEMS = [ [ "abs", "absolute value" ], [ "sigma", "median ± k·sigma" ], [ "pct", "median ± percent" ] ];
var PSW_MAX_RULES = 8;

function pswMetricKeys( available )
{
   return PSW_METRICS.map( m => m.key ).filter( k => !available || available.indexOf( k ) >= 0 );
}

// ----------------------------------------------------------------------------
// Rule editor: rule rows (fixed pool, shown/hidden) + expression. Reused by the
// main dialog and the review dialog. onChange( rules, expression, valid ).
// ----------------------------------------------------------------------------
var PSWRuleEditor = class extends Control
{
   constructor( parent, rules, expression, available, onChange )
   {
      super( parent );
      let self = this;
      this.metricKeys = pswMetricKeys( available );
      this.rules = ( rules || [] ).slice( 0, PSW_MAX_RULES ).map( r => PSWEngine.normalizeRule( r ) );
      this.expression = expression || "";
      this.onChange = onChange || null;
      this.syncing = false;
      this.rows = [];

      this.rowsSizer = new VerticalSizer;
      this.rowsSizer.spacing = 4;
      for ( let i = 0; i < PSW_MAX_RULES; ++i )
      {
         let k = i;
         let row = new Control( this );
         row.enableCheck = new CheckBox( row );
         row.enableCheck.toolTip = "<p>Enable or disable this rule. Disabled rules are ignored.</p>";
         row.enableCheck.onCheck = function( c ) { if ( !self.syncing ) { self.rules[ k ].enabled = c; self.changed(); } };
         row.metricCombo = new ComboBox( row );
         for ( let m of self.metricKeys ) row.metricCombo.addItem( m );
         row.metricCombo.toolTip = "<p>Metric tested by this rule. FWHM is in arcseconds (the image scale is used).</p>";
         row.metricCombo.onItemSelected = function( ix ) { if ( !self.syncing ) { self.rules[ k ].metric = self.metricKeys[ ix ]; self.changed(); } };
         row.dirCombo = new ComboBox( row );
         for ( let d of PSW_DIR_ITEMS ) row.dirCombo.addItem( d[ 1 ] );
         row.dirCombo.toolTip = "<p><b>reject if above</b>: frames with a value greater than the limit are rejected.<br/>" +
                                "<b>reject if below</b>: frames with a value smaller than the limit are rejected.</p>";
         row.dirCombo.onItemSelected = function( ix ) { if ( !self.syncing ) { self.rules[ k ].dir = PSW_DIR_ITEMS[ ix ][ 0 ]; self.changed(); } };
         row.kindCombo = new ComboBox( row );
         for ( let d of PSW_KIND_ITEMS ) row.kindCombo.addItem( d[ 1 ] );
         row.kindCombo.toolTip = "<p>How the value is read:<br/><b>absolute</b>: the limit is the value itself.<br/>" +
                                 "<b>sigma</b>: limit = median &plusmn; value &times; robust sigma (1.4826&middot;MAD) of all measured frames.<br/>" +
                                 "<b>percent</b>: limit = median &times; (1 &plusmn; value/100).</p>";
         row.kindCombo.onItemSelected = function( ix ) { if ( !self.syncing ) { self.rules[ k ].kind = PSW_KIND_ITEMS[ ix ][ 0 ]; self.changed(); } };
         row.valueEdit = new Edit( row );
         row.valueEdit.setFixedWidth( row.font.width( "0000.000000" ) );
         row.valueEdit.toolTip = "<p>Rule value: the limit (absolute), k (sigma) or the percentage (percent).</p>";
         row.valueEdit.onTextUpdated = function( t )
         {
            if ( self.syncing ) return;
            let v = parseFloat( t );
            if ( isFinite( v ) && /^\s*[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?\s*$/.test( t ) )
            {
               self.rules[ k ].value = v;
               self.changed();
            }
         };
         row.valueEdit.onEditCompleted = function() { self.syncRows(); };
         row.deleteButton = new ToolButton( row );
         row.deleteButton.icon = row.scaledResource( ":/icons/delete.png" );
         row.deleteButton.setScaledFixedSize( 22, 22 );
         row.deleteButton.toolTip = "<p>Delete this rule.</p>";
         row.deleteButton.onClick = function() { self.rules.splice( k, 1 ); self.syncRows(); self.changed(); };
         row.sizer = new HorizontalSizer;
         row.sizer.spacing = 4;
         row.sizer.add( row.enableCheck );
         row.sizer.add( row.metricCombo );
         row.sizer.add( row.dirCombo );
         row.sizer.add( row.kindCombo );
         row.sizer.add( row.valueEdit );
         row.sizer.add( row.deleteButton );
         row.sizer.addStretch();
         this.rows.push( row );
         this.rowsSizer.add( row );
      }

      this.noRulesLabel = new Label( this );
      this.noRulesLabel.text = "No rules: every measured frame passes (unless the expression rejects it).";
      this.noRulesLabel.toolTip = "<p>Add rules with the button below.</p>";

      this.addButton = new PushButton( this );
      this.addButton.text = "Add rule";
      this.addButton.icon = this.scaledResource( ":/icons/add.png" );
      this.addButton.toolTip = "<p>Add a rule (up to " + PSW_MAX_RULES + "). A frame is approved only if it passes every enabled rule.</p>";
      this.addButton.onClick = function()
      {
         if ( self.rules.length >= PSW_MAX_RULES ) return;
         self.rules.push( { enabled: true, metric: self.metricKeys.indexOf( "FWHM" ) >= 0 ? "FWHM" : self.metricKeys[ 0 ],
                            dir: "above", kind: "sigma", value: 2.5 } );
         self.syncRows();
         self.changed();
      };

      this.exprLabel = new Label( this );
      this.exprLabel.text = "Expression:";
      this.exprLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.exprLabel.toolTip = "<p>Optional logical expression; frames must also satisfy it.</p>";
      this.exprEdit = new Edit( this );
      this.exprEdit.text = this.expression;
      this.exprEdit.toolTip =
         "<p>Optional logical expression; frames must also satisfy it (approve if true). Empty = ignored.</p>" +
         "<p>Variables: FWHM, Eccentricity, PSFSignalWeight, PSFSNR, SNR, Stars, Median, Noise, MStar, PSFFlux, and " +
         "&lt;Metric&gt;Median, &lt;Metric&gt;Sigma, &lt;Metric&gt;Min, &lt;Metric&gt;Max (e.g. FWHMMedian).</p>" +
         "<p>Operators: &lt; &gt; &lt;= &gt;= == != &amp;&amp; || ! ( ) + - * /. No functions, no strings. Max 500 characters.</p>" +
         "<p>Example: <tt>FWHM &lt; FWHMMedian + 2*FWHMSigma &amp;&amp; Eccentricity &lt; 0.6</tt></p>";
      this.exprEdit.onTextUpdated = function( t ) { self.expression = t; self.checkExpression(); self.changed(); };
      this.exprError = new Label( this );
      this.exprError.useRichText = true;
      this.exprError.text = "";
      this.exprError.toolTip = "<p>Syntax check of the expression.</p>";

      this.exprSizer = new HorizontalSizer;
      this.exprSizer.spacing = 4;
      this.exprSizer.add( this.exprLabel );
      this.exprSizer.add( this.exprEdit, 100 );

      this.bottomSizer = new HorizontalSizer;
      this.bottomSizer.spacing = 6;
      this.bottomSizer.add( this.addButton );
      this.bottomSizer.addStretch();

      this.sizer = new VerticalSizer;
      this.sizer.spacing = 4;
      this.sizer.add( this.noRulesLabel );
      this.sizer.add( this.rowsSizer );
      this.sizer.add( this.bottomSizer );
      this.sizer.add( this.exprSizer );
      this.sizer.add( this.exprError );
      this.syncRows();
      this.checkExpression();
   }

   checkExpression()
   {
      try
      {
         PSWEngine.parseExpression( this.expression );
         this.exprError.text = "";
         this.exprValid = true;
      }
      catch ( e )
      {
         this.exprError.text = "<font color=\"#D04040\">" + String( e.message ).replace( /&/g, "&amp;" ).replace( /</g, "&lt;" ) + "</font>";
         this.exprValid = false;
      }
      return this.exprValid;
   }

   syncRows()
   {
      this.syncing = true;
      for ( let i = 0; i < PSW_MAX_RULES; ++i )
      {
         let row = this.rows[ i ];
         if ( i < this.rules.length )
         {
            let r = this.rules[ i ];
            row.enableCheck.checked = r.enabled;
            let mi = this.metricKeys.indexOf( r.metric );
            if ( mi < 0 ) { mi = 0; r.metric = this.metricKeys[ 0 ]; }
            row.metricCombo.currentItem = mi;
            row.dirCombo.currentItem = r.dir == "below" ? 1 : 0;
            row.kindCombo.currentItem = r.kind == "sigma" ? 1 : r.kind == "pct" ? 2 : 0;
            row.valueEdit.text = String( r.value );
            row.visible = true;
         }
         else
            row.visible = false;
      }
      this.noRulesLabel.visible = this.rules.length == 0;
      this.addButton.enabled = this.rules.length < PSW_MAX_RULES;
      this.syncing = false;
   }

   setContent( rules, expression )
   {
      this.rules = ( rules || [] ).slice( 0, PSW_MAX_RULES ).map( r => PSWEngine.normalizeRule( r ) );
      this.expression = expression || "";
      this.syncing = true;
      this.exprEdit.text = this.expression;
      this.syncing = false;
      this.syncRows();
      this.checkExpression();
   }

   changed()
   {
      if ( this.syncing ) return;
      if ( typeof this.onChange == "function" )
         this.onChange( this.rules.map( r => PSWEngine.normalizeRule( r ) ), this.expression, this.exprValid !== false );
   }
};

// ----------------------------------------------------------------------------
// Review dialog: table + graph + live rules + manual overrides.
// ----------------------------------------------------------------------------
var PSWReviewDialog = class extends Dialog
{
   constructor( rows, params, available, parent )
   {
      super( parent );
      let self = this;
      this.rows = rows;
      this.params = params;
      this.available = available || pswMetricKeys( null );
      this.metricKeys = pswMetricKeys( this.available );
      this.overrides = {};
      this.rules = ( params.rules || [] ).map( r => PSWEngine.normalizeRule( r ) );
      this.expression = params.expression || "";
      this.ast = null;
      this.exprIgnored = false;
      this.sel = null;
      this.updating = false;
      this.graphMetric = this.metricKeys.indexOf( "FWHM" ) >= 0 ? "FWHM" : this.metricKeys[ 0 ];
      try { this.ast = PSWEngine.parseExpression( this.expression ); } catch ( e ) { this.ast = null; this.exprIgnored = true; }

      // Decimals per metric column, so that space-padded text sorts numerically.
      this.decimals = {};
      for ( let k of this.metricKeys )
      {
         let mx = 0;
         for ( let r of rows ) { let v = r.m ? r.m[ k ] : NaN; if ( isFinite( v ) ) mx = Math.max( mx, Math.abs( v ) ); }
         this.decimals[ k ] = k == "Stars" ? 0 : Math.max( 0, Math.min( 8, 4 - Math.floor( Math.log10( mx > 0 ? mx : 1 ) ) ) );
      }

      // Table
      this.tree = new TreeBox( this );
      this.tree.alternateRowColor = true;
      this.tree.rootDecoration = false;
      this.tree.multipleSelection = false;
      this.tree.headerVisible = true;
      this.tree.headerSorting = true;
      this.colMetric0 = 3;
      this.tree.numberOfColumns = 3 + this.metricKeys.length + 1;
      this.tree.setHeaderText( 0, "#" );
      this.tree.setHeaderText( 1, "File" );
      this.tree.setHeaderText( 2, "Status" );
      for ( let j = 0; j < this.metricKeys.length; ++j )
      {
         this.tree.setHeaderText( this.colMetric0 + j, this.metricKeys[ j ] );
         this.tree.setHeaderAlignment( this.colMetric0 + j, TextAlignment.Right | TextAlignment.VertCenter );
      }
      this.colReason = this.colMetric0 + this.metricKeys.length;
      this.tree.setHeaderText( this.colReason, "Reason" );
      this.tree.setScaledMinSize( 760, 220 );
      this.tree.toolTip = "<p>Measured frames. The check box approves or rejects a frame manually (manual overrides win over the rules). " +
                          "Click a column header to sort (metric columns sort by number). Rejected frames are shown in red.</p>";
      this.nodes = [];
      for ( let i = 0; i < rows.length; ++i )
      {
         let r = rows[ i ];
         let n = new TreeBoxNode( this.tree );
         n.checkable = !r.failed;
         n.setText( 0, this.pad( String( i + 1 ), 5 ) );
         n.setText( 1, r.name );
         n.setToolTip( 1, r.path );
         for ( let j = 0; j < this.metricKeys.length; ++j )
         {
            let v = r.m ? r.m[ this.metricKeys[ j ] ] : NaN;
            n.setText( this.colMetric0 + j, this.pad( isFinite( v ) ? v.toFixed( this.decimals[ this.metricKeys[ j ] ] ) : "-", 14 ) );
            n.setAlignment( this.colMetric0 + j, TextAlignment.Right | TextAlignment.VertCenter );
         }
         this.nodes.push( n );
      }
      this.tree.onNodeUpdated = function( node, col )
      {
         if ( self.updating ) return;
         let i = parseInt( node.text( 0 ) ) - 1;
         if ( !( i >= 0 && i < self.rows.length ) || self.rows[ i ].failed ) return;
         if ( self.sel && node.checked != self.sel.approved[ i ] )
         {
            self.overrides[ i ] = node.checked;
            self.refresh();
         }
      };
      this.tree.onCurrentNodeUpdated = function() { self.graph.repaint(); };

      // Graph
      this.metricLabel = new Label( this );
      this.metricLabel.text = "Graph:";
      this.metricLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.metricLabel.toolTip = "<p>Metric shown in the graph.</p>";
      this.metricCombo = new ComboBox( this );
      for ( let k of this.metricKeys ) this.metricCombo.addItem( k );
      this.metricCombo.currentItem = Math.max( 0, this.metricKeys.indexOf( this.graphMetric ) );
      this.metricCombo.toolTip = "<p>Metric shown in the graph versus the frame index. The horizontal lines are the " +
                                 "limits of the active rules (or of the Auto rule).</p>";
      this.metricCombo.onItemSelected = function( ix ) { self.graphMetric = self.metricKeys[ ix ]; self.graph.repaint(); };

      this.graph = new Control( this );
      this.graph.setScaledMinSize( 760, 240 );
      this.graph.toolTip = "<p>Selected metric per frame. Filled dot = approved, hollow red = rejected, square = manual override. " +
                           "Click a point to toggle its approval (manual override) and select its table row.</p>";
      this.graph.onPaint = function() { self.paintGraph(); };
      this.graph.onMousePress = function( x, y, button ) { self.graphClick( x, y ); };
      this.points = [];

      // Rule editor (live, debounced)
      this.ruleEditor = new PSWRuleEditor( this, this.rules, this.expression, this.available,
         function( rules, expr, valid )
         {
            self.rules = rules;
            self.expression = expr;
            // An invalid expression is ignored (never the previous, stale one).
            self.ast = null;
            self.exprIgnored = !valid;
            if ( valid )
               try { self.ast = PSWEngine.parseExpression( expr ); } catch ( e ) { self.ast = null; self.exprIgnored = true; }
            self.timer.stop();
            self.timer.start();
         } );
      this.ruleEditor.toolTip = "<p>Rules applied live to the cached measurements (nothing is measured again). " +
                                "With no rules and no expression, the Auto rule is used.</p>";
      this.timer = new Timer;
      this.timer.interval = 0.15;
      this.timer.periodic = false;
      this.timer.onTimeout = function() { self.refresh(); };

      this.rulesGroup = new GroupBox( this );
      this.rulesGroup.title = "Rules (live)";
      this.rulesGroup.sizer = new VerticalSizer;
      this.rulesGroup.sizer.margin = 6;
      this.rulesGroup.sizer.add( this.ruleEditor );
      this.rulesGroup.toolTip = this.ruleEditor.toolTip;

      this.countLabel = new Label( this );
      this.countLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
      this.countLabel.toolTip = "<p>Approved frames / measured frames. Failed frames are never approved.</p>";
      this.ruleInfo = new Label( this );
      this.ruleInfo.toolTip = "<p>Which selection is active: the Auto rule (no rules and no expression) or your rules.</p>";

      this.resetButton = new PushButton( this );
      this.resetButton.text = "Reset overrides";
      this.resetButton.icon = this.scaledResource( ":/icons/reload.png" );
      this.resetButton.toolTip = "<p>Remove every manual approval/rejection; the rules decide again.</p>";
      this.resetButton.onClick = function() { self.overrides = {}; self.refresh(); };

      this.exportButton = new PushButton( this );
      this.exportButton.text = "Export";
      this.exportButton.icon = this.scaledResource( ":/icons/ok.png" );
      this.exportButton.toolTip = "<p>Accept this selection: copy the approved frames to the output folder and write the report.</p>";
      this.exportButton.onClick = function()
      {
         if ( !self.ruleEditor.checkExpression() )
         {
            ( new MessageBox( "The expression is invalid:\n" + self.ruleEditor.exprError.text.replace( /<[^>]+>/g, "" ),
                              PSW_TITLE, StdIcon.Error, StdButton.Ok ) ).execute();
            return;
         }
         self.params.rules = self.rules.map( r => PSWEngine.normalizeRule( r ) );
         self.params.expression = self.expression;
         self.ok();
      };
      this.cancelButton = new PushButton( this );
      this.cancelButton.text = "Cancel";
      this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
      this.cancelButton.toolTip = "<p>Close without exporting anything. Input files are never touched.</p>";
      this.cancelButton.onClick = function() { self.cancel(); };

      this.graphTopSizer = new HorizontalSizer;
      this.graphTopSizer.spacing = 6;
      this.graphTopSizer.add( this.metricLabel );
      this.graphTopSizer.add( this.metricCombo );
      this.graphTopSizer.addSpacing( 12 );
      this.graphTopSizer.add( this.ruleInfo, 100 );

      this.buttonsSizer = new HorizontalSizer;
      this.buttonsSizer.spacing = 6;
      this.buttonsSizer.add( this.countLabel );
      this.buttonsSizer.addStretch();
      this.buttonsSizer.add( this.resetButton );
      this.buttonsSizer.add( this.exportButton );
      this.buttonsSizer.add( this.cancelButton );

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 6;
      this.sizer.add( this.tree, 100 );
      this.sizer.add( this.graphTopSizer );
      this.sizer.add( this.graph, 100 );
      this.sizer.add( this.rulesGroup );
      this.sizer.add( this.buttonsSizer );

      this.windowTitle = PSW_TITLE + " - Review";
      this.onHide = function() { self.timer.stop(); };
      this.refresh();
      this.adjustToContents();
   }

   pad( s, n )
   {
      s = String( s );
      while ( s.length < n ) s = " " + s;
      return s;
   }

   refresh()
   {
      this.sel = PSWEngine.select( this.rows, "review", this.rules, this.ast, this.overrides, this.available );
      this.updating = true;
      let nA = 0, nV = 0;
      for ( let i = 0; i < this.rows.length; ++i )
      {
         let r = this.rows[ i ], n = this.nodes[ i ];
         let a = this.sel.approved[ i ];
         if ( !r.failed ) { ++nV; if ( a ) ++nA; }
         if ( !r.failed ) n.checked = a;
         let status = r.failed ? "failed" : ( a ? "approved" : "rejected" ) + ( this.sel.manual[ i ] ? " (manual)" : "" );
         n.setText( 2, status );
         let reason = r.failed ? r.failReason : this.sel.reasons[ i ] || "";
         n.setText( this.colReason, reason );
         n.setToolTip( this.colReason, reason );
         let color = r.failed ? 0xff808080 : a ? 0xff000000 : 0xffd02020;
         for ( let c = 0; c <= this.colReason; ++c )
            n.setTextColor( c, color );
      }
      this.updating = false;
      this.countLabel.text = "Approved " + nA + " / " + nV + ( nV < this.rows.length ? " (" + ( this.rows.length - nV ) + " failed)" : "" );
      this.ruleInfo.text = this.sel.usedAuto ? "Selection: Auto rule" + ( this.sel.warnings.length ? " (" + this.sel.warnings.join( "; " ) + ")" : "" )
                                             : "Selection: your rules" + ( this.ast ? " + expression" : "" );
      if ( this.exprIgnored )
         this.ruleInfo.text += " (invalid expression ignored)";
      this.graph.repaint();
   }

   paintGraph()
   {
      let G = this.graph;
      let g = new Graphics( G );
      try
      {
         let W = G.width, H = G.height;
         g.fillRect( 0, 0, W, H, new Brush( 0xff1b1f2a ) );
         g.antialiasing = true;
         let k = this.graphMetric;
         let xs = [], ys = [];
         for ( let i = 0; i < this.rows.length; ++i )
         {
            let v = this.rows[ i ].m ? this.rows[ i ].m[ k ] : NaN;
            if ( !this.rows[ i ].failed && isFinite( v ) ) { xs.push( i ); ys.push( v ); }
         }
         let ths = this.sel ? this.sel.thresholds.filter( t => t.metric == k ) : [];
         let lo = Infinity, hi = -Infinity;
         for ( let v of ys ) { lo = Math.min( lo, v ); hi = Math.max( hi, v ); }
         for ( let t of ths ) if ( isFinite( t.value ) ) { lo = Math.min( lo, t.value ); hi = Math.max( hi, t.value ); }
         g.font = this.font;
         g.pen = new Pen( 0xffc8ccd4 );
         let fh = this.font.height;
         let ml = this.font.width( "0.000000e-00" ) + 8, mr = 12, mt = fh + 6, mb = fh + 10;
         g.drawText( 6, fh, k + " vs frame index" );
         if ( ys.length == 0 )
         {
            g.drawText( ml, H/2, "No valid values for " + k + "." );
            this.points = [];
            return;
         }
         if ( hi == lo ) { hi += Math.abs( hi )*0.05 + 1e-6; lo -= Math.abs( lo )*0.05 + 1e-6; }
         let pad = ( hi - lo )*0.08; hi += pad; lo -= pad;
         let n = this.rows.length;
         let px = i => ml + ( n <= 1 ? ( W - ml - mr )/2 : i*( W - ml - mr )/( n - 1 ) );
         let py = v => mt + ( hi - v )*( H - mt - mb )/( hi - lo );
         // axes
         g.pen = new Pen( 0xff5a6070 );
         g.drawLine( ml, mt, ml, H - mb );
         g.drawLine( ml, H - mb, W - mr, H - mb );
         g.pen = new Pen( 0xffc8ccd4 );
         g.drawText( 4, mt + fh/2, PSWEngine.fmt( hi ) );
         g.drawText( 4, H - mb, PSWEngine.fmt( lo ) );
         g.drawText( ml, H - 2, "1" );
         g.drawText( W - mr - this.font.width( String( n ) ), H - 2, String( n ) );
         // thresholds
         for ( let t of ths )
         {
            let y = py( t.value );
            g.pen = new Pen( 0xffe0a030, 1 );
            g.drawLine( ml, y, W - mr, y );
            g.drawText( ml + 4, y - 3, t.label );
         }
         // points
         let cur = this.tree.currentNode;
         let curIdx = cur ? parseInt( cur.text( 0 ) ) - 1 : -1;
         this.points = [];
         let r0 = 4;
         for ( let j = 0; j < xs.length; ++j )
         {
            let i = xs[ j ], x = px( i ), y = py( ys[ j ] );
            this.points.push( { i: i, x: x, y: y } );
            let a = this.sel && this.sel.approved[ i ];
            let manual = this.sel && this.sel.manual[ i ];
            if ( a )
            {
               g.pen = new Pen( 0xff60c0ff, 1 );
               g.brush = new Brush( 0xff60c0ff );
            }
            else
            {
               g.pen = new Pen( 0xffff4040, 1.5 );
               g.brush = new Brush( 0x00000000 );
            }
            if ( manual )
               g.drawRect( x - r0, y - r0, x + r0, y + r0 );
            else
               g.drawCircle( x, y, r0 );
            if ( i == curIdx )
            {
               g.pen = new Pen( 0xffffffff, 1 );
               g.brush = new Brush( 0x00000000 );
               g.drawCircle( x, y, r0 + 3 );
            }
         }
      }
      catch ( e ) {}
      finally
      {
         g.end();
      }
   }

   graphClick( x, y )
   {
      let best = -1, bd = 1e9;
      for ( let p of this.points )
      {
         let d = ( p.x - x )*( p.x - x ) + ( p.y - y )*( p.y - y );
         if ( d < bd ) { bd = d; best = p.i; }
      }
      if ( best < 0 || bd > 100 )
         return;
      let cur = this.sel ? this.sel.approved[ best ] : true;
      this.overrides[ best ] = !cur;
      this.refresh();
      let n = this.nodes[ best ];
      this.tree.currentNode = n;
      this.tree.setNodeIntoView( n );
   }
};

// ----------------------------------------------------------------------------
// Main dialog
// ----------------------------------------------------------------------------
var PSWDialog = class extends Dialog
{
   constructor( params, parent )
   {
      super( parent );

      this.params = params;
      let self = this;
      this.available = PSWEngine.availableMetrics();
      this.anyCFA = false;
      let labelWidth = this.font.width( "Read noise (e-):" ) + this.font.width( 'M' );

      this.helpLabel = new Label( this );
      this.helpLabel.frameStyle = FrameStyle.Box;
      this.helpLabel.margin = 6;
      this.helpLabel.wordWrapping = true;
      this.helpLabel.useRichText = true;
      // The branded header already shows the title, so the help text does not repeat it.
      let help = "Measures linear frames with SubframeSelector in small batches, on the central part of the frame " +
                 "(or on one colour channel of CFA frames), selects them automatically, with your rules or in a review " +
                 "window, and copies the approved frames to the output folder with a CSV report. Input files are never modified.";
      this.helpLabel.text = PSW_BRANDED ? "<p>" + help + "</p>" : "<p><b>" + PSW_TITLE + "</b> &mdash; " + help + "</p>";
      this.helpLabel.toolTip = "<p>What this script does. Hover over any control for details.</p>";

      // ---------------- Input files
      this.fileTree = new TreeBox( this );
      this.fileTree.alternateRowColor = true;
      this.fileTree.rootDecoration = false;
      this.fileTree.multipleSelection = true;
      this.fileTree.headerVisible = true;
      this.fileTree.numberOfColumns = 4;
      this.fileTree.setHeaderText( 0, "File" );
      this.fileTree.setHeaderText( 1, "Size" );
      this.fileTree.setHeaderText( 2, "Scale" );
      this.fileTree.setHeaderText( 3, "CFA" );
      this.fileTree.setScaledMinSize( 560, 150 );
      this.fileTree.toolTip = "<p>Frames to analyse. Originals are never modified.</p>" +
                              "<p>XISF or FITS (.xisf .fit .fits .fts), linear, mono, RGB or CFA. Size = width x height x channels; " +
                              "Scale = arcsec/px from the header; CFA = Bayer pattern from the header.</p>";

      this.addFilesButton = new PushButton( this );
      this.addFilesButton.text = "Add files";
      this.addFilesButton.icon = this.scaledResource( ":/icons/add.png" );
      this.addFilesButton.toolTip = "<p>Add frames (XISF or FITS). The header of the first new file fills the frame parameters.</p>";
      this.addFilesButton.onClick = function()
      {
         let d = new OpenFileDialog;
         d.caption = "Select frames";
         d.multipleSelections = true;
         d.filters = [ [ "Image files", "*.xisf", "*.fit", "*.fits", "*.fts", "*.XISF", "*.FIT", "*.FITS", "*.FTS" ], [ "All files", "*" ] ];
         if ( self.params.lastDir && File.directoryExists( self.params.lastDir ) )
            d.initialPath = self.params.lastDir;
         if ( !d.execute() )
            return;
         if ( d.fileNames.length > 0 )
            self.params.lastDir = PSWEngine.dirOf( d.fileNames[ 0 ] );
         self.addFiles( d.fileNames );
      };

      this.addFolderButton = new PushButton( this );
      this.addFolderButton.text = "Add folder";
      this.addFolderButton.icon = this.scaledResource( ":/icons/folder.png" );
      this.addFolderButton.toolTip = "<p>Add every XISF/FITS file of a folder (.xisf, .fit, .fits, .fts, any letter case; " +
                                     "subfolders are not searched).</p>";
      this.addFolderButton.onClick = function()
      {
         let d = new GetDirectoryDialog;
         d.caption = "Select a folder of frames";
         if ( self.params.lastDir && File.directoryExists( self.params.lastDir ) )
            d.initialPath = self.params.lastDir;
         if ( !d.execute() )
            return;
         let dir = d.directory.replace( /[\/\\]+$/, "" );
         self.params.lastDir = dir;
         self.addFiles( PSWEngine.searchFolder( dir ) );
      };

      this.removeButton = new PushButton( this );
      this.removeButton.text = "Remove";
      this.removeButton.icon = this.scaledResource( ":/icons/remove.png" );
      this.removeButton.toolTip = "<p>Remove the selected files from the list (the files are not deleted).</p>";
      this.removeButton.onClick = function()
      {
         let sel = {};
         for ( let n of self.fileTree.selectedNodes ) sel[ n.toolTip( 0 ) ] = true;
         self.params.files = self.params.files.filter( p => !sel[ p ] );
         self.rebuildFileTree();
      };

      this.clearButton = new PushButton( this );
      this.clearButton.text = "Clear";
      this.clearButton.icon = this.scaledResource( ":/icons/clear.png" );
      this.clearButton.toolTip = "<p>Remove all files from the list (the files are not deleted).</p>";
      this.clearButton.onClick = function() { self.params.files = []; self.fileInfo = {}; self.rebuildFileTree(); };

      this.countLabel = new Label( this );
      this.countLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.countLabel.toolTip = "<p>Number of frames in the list.</p>";

      this.fileButtonsSizer = new HorizontalSizer;
      this.fileButtonsSizer.spacing = 6;
      this.fileButtonsSizer.add( this.addFilesButton );
      this.fileButtonsSizer.add( this.addFolderButton );
      this.fileButtonsSizer.add( this.removeButton );
      this.fileButtonsSizer.add( this.clearButton );
      this.fileButtonsSizer.addStretch();
      this.fileButtonsSizer.add( this.countLabel );

      this.inputGroup = new GroupBox( this );
      this.inputGroup.title = "Input frames";
      this.inputGroup.toolTip = this.fileTree.toolTip;
      this.inputGroup.sizer = new VerticalSizer;
      this.inputGroup.sizer.margin = 6;
      this.inputGroup.sizer.spacing = 6;
      this.inputGroup.sizer.add( this.fileTree, 100 );
      this.inputGroup.sizer.add( this.fileButtonsSizer );

      // ---------------- Output folder
      this.outLabel = new Label( this );
      this.outLabel.text = "Output folder:";
      this.outLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.outLabel.minWidth = labelWidth;
      this.outLabel.toolTip = "<p>Folder where approved frames and the report are written.</p>";
      this.outEdit = new Edit( this );
      this.outEdit.text = params.outputDir;
      this.outEdit.toolTip = "<p>Folder where approved frames and the report are written. It is created if needed. " +
                             "It must not be the folder of an input file. Existing files are never overwritten (a _1, _2 suffix is added).</p>";
      this.outEdit.onTextUpdated = function( t ) { self.params.outputDir = t.trim(); };
      this.outButton = new ToolButton( this );
      this.outButton.icon = this.scaledResource( ":/icons/select-file.png" );
      this.outButton.setScaledFixedSize( 22, 22 );
      this.outButton.toolTip = "<p>Select the output folder.</p>";
      this.outButton.onClick = function()
      {
         let d = new GetDirectoryDialog;
         d.caption = "Select the output folder";
         if ( self.params.outputDir && File.directoryExists( self.params.outputDir ) )
            d.initialPath = self.params.outputDir;
         else if ( self.params.lastDir && File.directoryExists( self.params.lastDir ) )
            d.initialPath = self.params.lastDir;
         if ( d.execute() )
         {
            self.params.outputDir = d.directory.replace( /[\/\\]+$/, "" );
            self.outEdit.text = self.params.outputDir;
         }
      };
      this.outSizer = new HorizontalSizer;
      this.outSizer.spacing = 4;
      this.outSizer.add( this.outLabel );
      this.outSizer.add( this.outEdit, 100 );
      this.outSizer.add( this.outButton );

      // ---------------- Frame parameters
      this.status = { scale: "", gain: "", rn: "", bits: "" };
      let mkNum = ( label, tip, lo, hi, prec, value, key, statusKey ) =>
      {
         let ne = new NumericEdit( this );
         ne.label.text = label;
         ne.label.minWidth = labelWidth;
         ne.setReal( true );
         ne.setRange( lo, hi );
         ne.setPrecision( prec );
         ne.setValue( value );
         ne.edit.setFixedWidth( this.font.width( "000000.0000" ) );
         ne.toolTip = tip;
         ne.onValueUpdated = function( v ) { self.params[ key ] = v; self.setStatus( statusKey, "manual" ); };
         return ne;
      };
      this.scaleEdit = mkNum( "Scale (\"/px):",
         "<p>Image scale in arcsec per pixel. Filled from the header (SCALE/PIXSCALE or XPIXSZ/FOCALLEN) when available. " +
         "XPIXSZ is used as written by the capture software (N.I.N.A., SGP and ASIAIR already include binning): " +
         "check if you use binning. In CFA channel mode the script doubles it for the superpixel image.</p>",
         0.01, 100, 4, params.subframeScale, "subframeScale", "scale" );
      this.gainEdit = mkNum( "Gain (e-/ADU):",
         "<p>Camera gain in e-/ADU (EGAIN). 0 = unknown: values are in data numbers. The GAIN keyword is a camera " +
         "setting, not e-/ADU, and is not used.</p>", 0, 100, 4, params.cameraGain, "cameraGain", "gain" );
      this.rnEdit = mkNum( "Read noise (e-):",
         "<p>Read noise in electrons (RDNOISE). SubframeSelector has no read-noise parameter: the value is stored " +
         "in the report and in the exported metadata (SFS_RDNOISE) only.</p>", 0, 100, 3, params.readNoise, "readNoise", "rn" );

      this.bitsLabel = new Label( this );
      this.bitsLabel.text = "Bit depth:";
      this.bitsLabel.minWidth = labelWidth;
      this.bitsLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.bitsLabel.toolTip = "<p>Sample bit depth of the frames (BITPIX). Sets the SFS camera resolution.</p>";
      this.bitsCombo = new ComboBox( this );
      for ( let b of PSW_BIT_DEPTHS ) this.bitsCombo.addItem( b == 32 ? "32 / float" : String( b ) );
      this.bitsCombo.currentItem = Math.max( 0, PSW_BIT_DEPTHS.indexOf( params.bitDepth ) );
      this.bitsCombo.toolTip = "<p>Sample bit depth of the frames (BITPIX). Sets the SFS camera resolution " +
                               "(32-bit and float data use the largest SFS setting, 16 bits).</p>";
      this.bitsCombo.onItemSelected = function( ix ) { self.params.bitDepth = PSW_BIT_DEPTHS[ ix ]; self.setStatus( "bits", "manual" ); };

      let mkStatus = () => { let l = new Label( this ); l.useRichText = true; l.toolTip = "<p>Where the value comes from: (from header), (manual) or (not found). " +
                             "A scale missing from the header keeps the previous value (shown in orange): check it.</p>"; l.minWidth = this.font.width( "(from header: XPIXSZ/FOCALLEN)" ); return l; };
      this.scaleStatus = mkStatus(); this.gainStatus = mkStatus(); this.rnStatus = mkStatus(); this.bitsStatus = mkStatus();

      this.readHeaderButton = new PushButton( this );
      this.readHeaderButton.text = "Read from header";
      this.readHeaderButton.icon = this.scaledResource( ":/icons/document-edit.png" );
      this.readHeaderButton.toolTip = "<p>Fill scale, gain, read noise and bit depth from the header of the first file in the list.</p>";
      this.readHeaderButton.onClick = function()
      {
         if ( self.params.files.length == 0 )
         {
            ( new MessageBox( "Add frames first.", PSW_TITLE, StdIcon.Information, StdButton.Ok ) ).execute();
            return;
         }
         self.fillFromHeader( self.params.files[ 0 ] );
      };

      let row = ( a, b ) => { let s = new HorizontalSizer; s.spacing = 6; s.add( a ); s.add( b ); s.addStretch(); return s; };
      this.bitsRow = new HorizontalSizer;
      this.bitsRow.spacing = 4;
      this.bitsRow.add( this.bitsLabel );
      this.bitsRow.add( this.bitsCombo );
      this.frameGroup = new GroupBox( this );
      this.frameGroup.title = "Frame parameters";
      this.frameGroup.toolTip = "<p>Camera and optics values for SubframeSelector. They are read from the header when available.</p>";
      this.frameGroup.sizer = new VerticalSizer;
      this.frameGroup.sizer.margin = 6;
      this.frameGroup.sizer.spacing = 4;
      this.frameGroup.sizer.add( row( this.scaleEdit, this.scaleStatus ) );
      this.frameGroup.sizer.add( row( this.gainEdit, this.gainStatus ) );
      this.frameGroup.sizer.add( row( this.rnEdit, this.rnStatus ) );
      this.frameGroup.sizer.add( row( this.bitsRow, this.bitsStatus ) );
      let hb = new HorizontalSizer; hb.addStretch(); hb.add( this.readHeaderButton );
      this.frameGroup.sizer.add( hb );

      // ---------------- Measurement
      this.roiControl = new NumericControl( this );
      this.roiControl.label.text = "ROI (%):";
      this.roiControl.label.minWidth = labelWidth;
      this.roiControl.setReal( false );
      this.roiControl.setRange( 25, 100 );
      this.roiControl.slider.setRange( 25, 100 );
      this.roiControl.setValue( params.roiFraction );
      this.roiControl.toolTip = "<p>Measured part of width and height, centred. 50 = the central quarter of the area. " +
                                "Faster, and edge aberrations are ignored. 100 = the whole frame. The minimum ROI is 256x256 pixels.</p>";
      this.roiControl.onValueUpdated = function( v ) { self.params.roiFraction = Math.round( v ); };

      let mkCombo = ( label, items, cur, tip, onSel ) =>
      {
         let l = new Label( this );
         l.text = label;
         l.minWidth = labelWidth;
         l.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
         l.toolTip = tip;
         let c = new ComboBox( this );
         for ( let it of items ) c.addItem( it );
         c.currentItem = Math.max( 0, cur );
         c.toolTip = tip;
         c.onItemSelected = onSel;
         let s = new HorizontalSizer;
         s.spacing = 4;
         s.add( l );
         s.add( c );
         s.addStretch();
         return { label: l, combo: c, sizer: s };
      };
      this.cfa = mkCombo( "CFA mode:", [ "Auto (G for CFA frames)", "Off", "R", "G", "B" ], PSW_CFA_MODES.indexOf( params.cfaMode ),
         "<p>Off = measure as is. R/G/B = measure one colour channel of CFA frames, extracted without debayering " +
         "(superpixel of the ROI, 1/16 of the pixels). Exported files are the original CFA files.</p>" +
         "<p>Auto = G for frames with a Bayer pattern, Off for the others. Every channel uses one pixel per 2x2 cell; " +
         "G is the green pixel on the same row as red (the two greens are not averaged, which would elongate the stars " +
         "and inflate the eccentricity).</p>",
         function( ix ) { self.params.cfaMode = PSW_CFA_MODES[ ix ]; self.updateHint(); } );
      this.bayer = mkCombo( "Bayer pattern:", PSW_BAYER, PSW_BAYER.indexOf( params.bayerOverride ),
         "<p>Pattern of the sensor. Auto reads BAYERPAT and XBAYROFF/YBAYROFF. A manual pattern replaces BAYERPAT; " +
         "the offsets still apply. For FITS frames with ROWORDER='BOTTOM-UP' (rows flipped on reading) the pattern " +
         "is flipped vertically to match.</p>",
         function( ix ) { self.params.bayerOverride = PSW_BAYER[ ix ]; } );
      this.psf = mkCombo( "PSF model:", PSW_PSF_MODELS, PSW_PSF_MODELS.indexOf( params.psfFit ),
         "<p>PSF model used by SFS for the star fits (FWHM, eccentricity, PSF signal weight).</p>",
         function( ix ) { self.params.psfFit = PSW_PSF_MODELS[ ix ]; } );

      this.batchLabel = new Label( this );
      this.batchLabel.text = "Batch size:";
      this.batchLabel.minWidth = labelWidth;
      this.batchLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.batchLabel.toolTip = "<p>Frames per SFS call. Lower values use less memory.</p>";
      this.batchSpin = new SpinBox( this );
      this.batchSpin.setRange( 1, 32 );
      this.batchSpin.value = params.batchSize;
      this.batchSpin.toolTip = "<p>Frames per SFS call (1-32). Lower values use less memory; 6 suits 8 GB of RAM with 26 MP frames.</p>";
      this.batchSpin.onValueUpdated = function( v ) { self.params.batchSize = v; };
      this.batchSizer = new HorizontalSizer;
      this.batchSizer.spacing = 4;
      this.batchSizer.add( this.batchLabel );
      this.batchSizer.add( this.batchSpin );
      this.batchSizer.addStretch();

      this.hintLabel = new Label( this );
      this.hintLabel.useRichText = true;
      this.hintLabel.text = "<font color=\"#E08000\">CFA frames detected: select a channel for more reliable measurements</font>";
      this.hintLabel.toolTip = "<p>SFS measures a raw CFA mosaic as if it were a mono image; the colour pattern disturbs the star fits. " +
                               "Measuring one channel (G recommended) gives more reliable values.</p>";
      this.hintLabel.visible = false;

      this.measureGroup = new GroupBox( this );
      this.measureGroup.title = "Measurement";
      this.measureGroup.toolTip = "<p>How the frames are measured.</p>";
      this.measureGroup.sizer = new VerticalSizer;
      this.measureGroup.sizer.margin = 6;
      this.measureGroup.sizer.spacing = 4;
      this.measureGroup.sizer.add( this.roiControl );
      this.measureGroup.sizer.add( this.cfa.sizer );
      this.measureGroup.sizer.add( this.bayer.sizer );
      this.measureGroup.sizer.add( this.psf.sizer );
      this.measureGroup.sizer.add( this.batchSizer );
      this.measureGroup.sizer.add( this.hintLabel );

      // ---------------- Mode
      let mkRadio = ( text, mode, tip ) =>
      {
         let r = new RadioButton( this );
         r.text = text;
         r.checked = params.mode == mode;
         r.toolTip = tip;
         r.onCheck = function( c ) { if ( c ) { self.params.mode = mode; self.updateMode(); } };
         return r;
      };
      this.autoRadio = mkRadio( "Auto", "auto", "<p>Auto: automatic robust rule (see the description below). No tuning needed.</p>" );
      this.rulesRadio = mkRadio( "Rule set", "rules", "<p>Rule set: your rules (and optional expression), defined before measuring.</p>" );
      this.reviewRadio = mkRadio( "Review", "review", "<p>Review: measure, then check and edit the selection in a window " +
                                  "(table, graph, live rules, manual overrides) before exporting.</p>" );
      this.radioSizer = new HorizontalSizer;
      this.radioSizer.spacing = 12;
      this.radioSizer.add( this.autoRadio );
      this.radioSizer.add( this.rulesRadio );
      this.radioSizer.add( this.reviewRadio );
      this.radioSizer.addStretch();

      this.ruleEditor = new PSWRuleEditor( this, params.rules, params.expression, this.available,
         function( rules, expr ) { self.params.rules = rules; self.params.expression = expr; } );
      this.ruleEditor.toolTip = "<p>Your rules: a frame is approved if it passes every enabled rule and the expression. " +
                                "In Review mode they are the initial selection (the Auto rule when empty).</p>";

      this.autoLabel = new Label( this );
      this.autoLabel.useRichText = true;
      this.autoLabel.wordWrapping = true;
      this.autoLabel.frameStyle = FrameStyle.Box;
      this.autoLabel.margin = 4;
      this.autoLabel.text = PSW_AUTO_RULE_TEXT;
      this.autoLabel.toolTip = "<p>The Auto rule used in Auto mode (and in Review mode when no rules are given).</p>";

      this.modeGroup = new GroupBox( this );
      this.modeGroup.title = "Selection";
      this.modeGroup.toolTip = "<p>How frames are approved or rejected.</p>";
      this.modeGroup.sizer = new VerticalSizer;
      this.modeGroup.sizer.margin = 6;
      this.modeGroup.sizer.spacing = 6;
      this.modeGroup.sizer.add( this.radioSizer );
      this.modeGroup.sizer.add( this.ruleEditor );
      this.modeGroup.sizer.add( this.autoLabel );

      // ---------------- Output options
      this.copyUnchangedCheck = new CheckBox( this );
      this.copyUnchangedCheck.text = "Copy originals unchanged";
      this.copyUnchangedCheck.checked = params.copyUnchanged;
      this.copyUnchangedCheck.toolTip = "<p>Copy the original files byte for byte (fastest, no added metadata). " +
                                        "Always used in CFA single-channel mode. When off, approved frames are written as XISF " +
                                        "with the measurements as FITS keywords (SFS_FWHM, SFS_ECC ...) and XISF properties. The original keywords, " +
                                        "image properties, colour filter array and ICC profile are kept.</p>";
      this.copyUnchangedCheck.onCheck = function( c ) { self.params.copyUnchanged = c; };
      this.copyRejectedCheck = new CheckBox( this );
      this.copyRejectedCheck.text = "Also copy rejected frames";
      this.copyRejectedCheck.checked = params.copyRejected;
      this.copyRejectedCheck.toolTip = "<p>Also copy rejected frames to the \"rejected\" subfolder (byte copy). " +
                                       "Otherwise they are only listed in the CSV report.</p>";
      this.copyRejectedCheck.onCheck = function( c ) { self.params.copyRejected = c; };
      this.optSizer = new HorizontalSizer;
      this.optSizer.spacing = 12;
      this.optSizer.add( this.copyUnchangedCheck );
      this.optSizer.add( this.copyRejectedCheck );
      this.optSizer.addStretch();
      this.optGroup = new GroupBox( this );
      this.optGroup.title = "Output";
      this.optGroup.toolTip = "<p>What is written to the output folder. SFS_report.csv is always written.</p>";
      this.optGroup.sizer = new VerticalSizer;
      this.optGroup.sizer.margin = 6;
      this.optGroup.sizer.spacing = 4;
      this.optGroup.sizer.add( this.outSizer );
      this.optGroup.sizer.add( this.optSizer );

      // ---------------- Buttons
      this.runButton = new PushButton( this );
      this.runButton.text = "Run";
      this.runButton.icon = this.scaledResource( ":/icons/power.png" );
      this.runButton.toolTip = "<p>Measure, select and export. Press Abort in the Process Console to stop between batches " +
                               "(nothing is exported then).</p>";
      this.runButton.onClick = function() { self.runNow(); };

      this.closeButton = new PushButton( this );
      this.closeButton.text = "Close";
      this.closeButton.icon = this.scaledResource( ":/icons/close.png" );
      this.closeButton.toolTip = "<p>Close the dialog. Settings are saved; nothing is exported.</p>";
      this.closeButton.onClick = function() { self.ok(); };

      this.buttonsSizer = new HorizontalSizer;
      this.buttonsSizer.spacing = 6;
      this.buttonsSizer.addStretch();
      this.buttonsSizer.add( this.runButton );
      this.buttonsSizer.add( this.closeButton );

      // ---------------- Layout
      this.leftSizer = new VerticalSizer;
      this.leftSizer.spacing = 8;
      this.leftSizer.add( this.inputGroup, 100 );
      this.leftSizer.add( this.optGroup );

      this.rightSizer = new VerticalSizer;
      this.rightSizer.spacing = 8;
      this.rightSizer.add( this.frameGroup );
      this.rightSizer.add( this.measureGroup );
      this.rightSizer.addStretch();

      this.topSizer = new HorizontalSizer;
      this.topSizer.spacing = 8;
      this.topSizer.add( this.leftSizer, 100 );
      this.topSizer.add( this.rightSizer );

      this.bodySizer = new VerticalSizer;
      this.bodySizer.margin = 8;
      this.bodySizer.spacing = 8;
      this.bodySizer.add( this.helpLabel );
      this.bodySizer.add( this.topSizer, 100 );
      this.bodySizer.add( this.modeGroup );
      this.bodySizer.add( this.buttonsSizer );

      this.header = PSW_BRANDED ? new PSWHeader( this ) : null;
      this.sizer = new VerticalSizer;
      this.sizer.margin = 0;
      this.sizer.spacing = 0;
      if ( this.header != null )
         this.sizer.add( this.header );
      this.sizer.add( this.bodySizer, 100 );

      this.windowTitle = PSW_TITLE;
      this.fileInfo = {};
      this.params.files = ( this.params.files || [] ).slice();
      this.rebuildFileTree();
      this.updateMode();
      this.setStatus( "scale", "" ); this.setStatus( "gain", "" ); this.setStatus( "rn", "" ); this.setStatus( "bits", "" );
      this.setScaledMinWidth( 900 );
      this.adjustToContents();
   }

   setStatus( key, what )
   {
      let map = { scale: this.scaleStatus, gain: this.gainStatus, rn: this.rnStatus, bits: this.bitsStatus };
      let l = map[ key ];
      if ( !l ) return;
      l.text = what == "" ? "" : what == "manual" ? "(manual)" : what == "missing" ? "(not found)" :
               what == "unknown" ? "(not in header: 0 = unknown)" :
               what == "keep" ? "<font color=\"#E08000\">Not in header: previous value kept, check it!</font>" :
               "(from header: " + what + ")";
   }

   probe( path )
   {
      if ( !( path in this.fileInfo ) )
      {
         try { this.fileInfo[ path ] = PSWEngine.probeFile( path ); }
         catch ( e ) { this.fileInfo[ path ] = { error: String( e.message || e ) }; }
      }
      return this.fileInfo[ path ];
   }

   addFiles( list )
   {
      let have = {};
      for ( let p of this.params.files ) have[ p ] = true;
      let added = [];
      for ( let p of list )
         if ( !have[ p ] ) { have[ p ] = true; this.params.files.push( p ); added.push( p ); }
      if ( added.length > 0 )
         this.fillFromHeader( added[ 0 ] );
      this.rebuildFileTree();
   }

   fillFromHeader( path )
   {
      let h = this.probe( path );
      if ( h.error )
      {
         console.warningln( "** " + path + ": " + h.error );
         return;
      }
      // Scale: kept when missing (it cannot be 0) but flagged; gain and read noise: reset to 0 = unknown,
      // so values of a previous camera never remain silently.
      if ( h.scale > 0 )
      {
         this.params.subframeScale = h.scale;
         this.scaleEdit.setValue( h.scale );
         this.setStatus( "scale", h.scaleSrc + ( h.binningAmbiguous ? ", check binning" : "" ) );
      }
      else this.setStatus( "scale", "keep" );
      let g = h.gain > 0 ? h.gain : 0;
      this.params.cameraGain = g;
      this.gainEdit.setValue( g );
      this.setStatus( "gain", g > 0 ? h.gainSrc : "unknown" );
      let rn = h.readNoise >= 0 ? h.readNoise : 0;
      this.params.readNoise = rn;
      this.rnEdit.setValue( rn );
      this.setStatus( "rn", h.readNoise >= 0 ? h.rnSrc : "unknown" );
      let bits = h.isFloat ? 32 : h.bitpix;
      let bi = PSW_BIT_DEPTHS.indexOf( bits );
      if ( bi >= 0 )
      {
         this.params.bitDepth = bits;
         this.bitsCombo.currentItem = bi;
         this.setStatus( "bits", h.isFloat ? "float" : "BITPIX" );
      }
      else this.setStatus( "bits", "missing" );
   }

   rebuildFileTree()
   {
      this.fileTree.clear();
      this.anyCFA = false;
      for ( let p of this.params.files )
      {
         let n = new TreeBoxNode( this.fileTree );
         n.setText( 0, File.extractNameAndExtension( p ) );
         n.setToolTip( 0, p );
         let h = this.probe( p );
         if ( h.error )
         {
            n.setText( 1, "error" );
            n.setToolTip( 1, h.error );
            n.setTextColor( 1, 0xffd02020 );
            continue;
         }
         n.setText( 1, h.width + "x" + h.height + ( h.channels > 1 ? "x" + h.channels : "" ) );
         n.setText( 2, h.scale > 0 ? h.scale.toFixed( 3 ) : "-" );
         n.setText( 3, h.cfa ? h.bayerPat : "-" );
         if ( h.cfa ) this.anyCFA = true;
      }
      for ( let c = 0; c < 4; ++c )
         this.fileTree.adjustColumnWidthToContents( c );
      this.countLabel.text = this.params.files.length + " frame" + ( this.params.files.length == 1 ? "" : "s" );
      this.updateHint();
   }

   updateHint()
   {
      this.hintLabel.visible = this.anyCFA && this.params.cfaMode == "Off";
   }

   updateMode()
   {
      let auto = this.params.mode == "auto";
      this.ruleEditor.enabled = !auto;
      this.ruleEditor.visible = !auto;
      this.autoLabel.visible = auto || this.params.mode == "review";
   }

   setBusy( busy )
   {
      for ( let c of [ this.inputGroup, this.optGroup, this.frameGroup, this.measureGroup, this.modeGroup,
                       this.runButton, this.closeButton ] )
         c.enabled = !busy;
   }

   runNow()
   {
      let p = this.params;
      p.clamp();
      let err = PSWEngine.validate( p );
      if ( err )
      {
         ( new MessageBox( err, PSW_TITLE, StdIcon.Error, StdButton.Ok ) ).execute();
         return;
      }
      p.save();
      let self = this;
      p.reviewCallback = function( rows, ctx )
      {
         let d = new PSWReviewDialog( rows, p, ctx && ctx.available, self );
         return d.execute() ? d.overrides : null;
      };
      // Only the inputs are disabled during the run: disabling the dialog itself would also
      // disable the review dialog, which is its child.
      this.setBusy( true );
      let res = null;
      try
      {
         console.show();
         res = PSWEngine.run( null, p );
      }
      catch ( e )
      {
         this.setBusy( false );
         console.criticalln( "*** " + ( e.message || e ) );
         ( new MessageBox( String( e.message || e ), PSW_TITLE, StdIcon.Error, StdButton.Ok ) ).execute();
         return;
      }
      finally
      {
         this.setBusy( false );
         p.reviewCallback = undefined;
      }
      this.ruleEditor.setContent( p.rules, p.expression );
      p.save();
      let msg = "Frames: " + res.nInput + "\nMeasured: " + res.nMeasured + "\nFailed: " + res.nFailed +
                "\nApproved: " + res.nApproved + "\nRejected: " + res.nRejected + "\nExported: " + res.nExported +
                "\nTime: " + res.seconds.toFixed( 1 ) + " s" +
                ( PSWEngine.lastReportPath ? "\n\nReport: " + PSWEngine.lastReportPath : "" );
      console.noteln( "<end><cbr>" + msg.replace( /\n+/g, " | " ) );
      ( new MessageBox( msg, PSW_TITLE, res.nMeasured > 0 ? StdIcon.Information : StdIcon.Error, StdButton.Ok ) ).execute();
   }
};
