// SyntheticLight_v1Engine.js - processing logic, no GUI objects allowed here.
//
// Contract used by the GUI and by the headless test harness:
//   new PSWParameters()         -> object with defaults, .load(), .save()
//   PSWEngine.run(view, params) -> creates a new mono window "SyntheticLight[_n]"
//                                  and returns an object with numbers worth logging
//   PSWEngine.validate(params, view) -> resolves the source views or throws Error

var PSW_PRESETS = [
   [ 0.25, 0.50, 0.25 ],       // 0: Colour CFA / OSC camera (Bayer RGGB 1:2:1)
   [ 0.2126, 0.7152, 0.0722 ]  // 1: Monochrome camera with RGB filters (Rec.709)
];

var PSWParameters = class
{
   constructor()
   {
      this.inputMode = 0;          // 0 = one colour view, 1 = three mono views
      this.viewIdColor = "";
      this.viewIdR = "";
      this.viewIdG = "";
      this.viewIdB = "";
      this.cameraType = 0;         // 0 = CFA/OSC, 1 = Mono + RGB filters, 2 = Custom
      this.weightR = 0.25;
      this.weightG = 0.50;
      this.weightB = 0.25;
      this.normalization = 0;      // 0 = None, 1 = Match backgrounds, 2 = Match backgrounds and scale
   }

   load()
   {
      let self = this;
      function rd( key, type, prop, lo, hi )
      {
         let v = Settings.read( PSW_SETTINGS + "/" + key, type );
         if ( Settings.lastReadOK && isFinite( v ) && v >= lo && v <= hi )
            self[prop] = v;
      }
      rd( "inputMode", DataType.Int32, "inputMode", 0, 1 );
      rd( "cameraType", DataType.Int32, "cameraType", 0, 2 );
      rd( "weightR", DataType.Double, "weightR", 0, 1 );
      rd( "weightG", DataType.Double, "weightG", 0, 1 );
      rd( "weightB", DataType.Double, "weightB", 0, 1 );
      rd( "normalization", DataType.Int32, "normalization", 0, 2 );
   }

   save()
   {
      Settings.write( PSW_SETTINGS + "/inputMode", DataType.Int32, this.inputMode );
      Settings.write( PSW_SETTINGS + "/cameraType", DataType.Int32, this.cameraType );
      Settings.write( PSW_SETTINGS + "/weightR", DataType.Double, this.weightR );
      Settings.write( PSW_SETTINGS + "/weightG", DataType.Double, this.weightG );
      Settings.write( PSW_SETTINGS + "/weightB", DataType.Double, this.weightB );
      Settings.write( PSW_SETTINGS + "/normalization", DataType.Int32, this.normalization );
   }
};

var PSWEngine = {

   // Raw (unnormalized) weights for the selected camera type.
   rawWeights: function( params )
   {
      let t = params.cameraType;
      if ( t == 0 || t == 1 )
         return PSW_PRESETS[t].slice();
      return [ params.weightR, params.weightG, params.weightB ];
   },

   // Normalized weights; throws on invalid values.
   weights: function( params )
   {
      let raw = this.rawWeights( params );
      let sum = 0;
      for ( let i = 0; i < 3; ++i )
      {
         if ( typeof raw[i] != "number" || !isFinite( raw[i] ) || raw[i] < 0 )
            throw new Error( "Weights must be finite and not negative." );
         sum += raw[i];
      }
      if ( !(sum > 0) )
         throw new Error( "All weights are zero." );
      return [ raw[0]/sum, raw[1]/sum, raw[2]/sum ];
   },

   resolveView: function( id )
   {
      if ( id == null || id == "" )
         return null;
      let w = ImageWindow.windowById( id );
      return (w == null || w.isNull) ? null : w.mainView;
   },

   // Returns { colorMode, views:[R,G,B] (mono mode) or [V,V,V] (colour mode), source }
   validate: function( params, view )
   {
      if ( ImageWindow.windows.length == 0 )
         throw new Error( "Open an image first." );
      this.weights( params );

      if ( params.inputMode == 0 )
      {
         let v = (view != null && !view.isNull) ? view : this.resolveView( params.viewIdColor );
         if ( v == null || v.isNull )
            throw new Error( "Select an RGB image." );
         if ( v.isPreview )
            throw new Error( "Previews are not supported. Select a main view." );
         if ( v.image.numberOfChannels != 3 )
            throw new Error( "Colour mode needs an RGB image (3 channels)." );
         return { colorMode: true, views: [ v, v, v ], source: v };
      }

      let names = [ "R", "G", "B" ];
      let v = [
         this.resolveView( params.viewIdR ),
         (params.viewIdG != "" && params.viewIdG != null) ? this.resolveView( params.viewIdG )
                                                         : ((view != null && !view.isNull) ? view : null),
         this.resolveView( params.viewIdB ) ];
      for ( let i = 0; i < 3; ++i )
      {
         if ( v[i] == null || v[i].isNull )
            throw new Error( "Select an image for the " + names[i] + " channel." );
         if ( v[i].isPreview )
            throw new Error( "Previews are not supported (" + names[i] + " channel). Select a main view." );
         if ( v[i].image.numberOfChannels != 1 )
            throw new Error( "The " + names[i] + " image must be a mono image (1 channel)." );
      }
      if ( v[0].fullId == v[1].fullId || v[0].fullId == v[2].fullId || v[1].fullId == v[2].fullId )
         throw new Error( "The R, G and B images must be three different images." );
      let w0 = v[0].image.width, h0 = v[0].image.height;
      for ( let i = 1; i < 3; ++i )
         if ( v[i].image.width != w0 || v[i].image.height != h0 )
            throw new Error( format( "Image size mismatch: R is %dx%d but %s is %dx%d.",
                                     w0, h0, names[i], v[i].image.width, v[i].image.height ) );
      return { colorMode: false, views: v, source: v[1] };
   },

   // Literal with 10 significant digits (valid PixelMath number).
   lit: function( x )
   {
      return Number( x ).toPrecision( 10 );
   },

   uniqueId: function( base )
   {
      let id = base, n = 0;
      while ( !ImageWindow.windowById( id ).isNull )
         id = base + "_" + (++n);
      return id;
   },

   run: function( view, params )
   {
      let src = this.validate( params, view );
      let w = this.weights( params );
      let norm = params.normalization;
      let names = [ "R", "G", "B" ];

      console.writeln( "<end><cbr>Mode: " + (src.colorMode ? "one colour image" : "three mono images") );
      console.writeln( "Camera preset: " + [ "Colour CFA / OSC", "Mono + RGB filters", "Custom" ][Math.min( 2, Math.max( 0, params.cameraType ) )] );
      console.writeln( format( "Normalized weights: %.4f / %.4f / %.4f", w[0], w[1], w[2] ) );
      console.writeln( "Normalization: " + [ "None", "Match backgrounds", "Match backgrounds and scale" ][norm] );
      if ( norm == 1 )
         console.noteln( "Note: Match backgrounds is identical to None for linear weights." );

      // ---- statistics, computed once, only what is needed
      let m = [ 0, 0, 0 ], d = [ 0, 0, 0 ], s = [ 1, 1, 1 ];
      let stretched = false;
      for ( let c = 0; c < 3; ++c )
      {
         let needed = w[c] > 0 || (norm == 2 && c == 1); // G is the scale reference
         if ( !needed )
            continue;
         let img = src.views[c].image;
         let ch = src.colorMode ? c : 0;
         let r = img.bounds;
         let med = img.median( r, ch, ch );
         if ( med > 0.1 && w[c] > 0 )
            stretched = true;
         if ( norm != 0 )
            m[c] = med;
         if ( norm == 2 )
            d[c] = img.MAD( med, r, ch, ch );
      }
      if ( stretched )
         console.warningln( "Warning: data look stretched (a source median is above 0.1). Linear data is expected." );
      if ( norm == 2 )
         for ( let c = 0; c < 3; ++c )
         {
            if ( c == 1 || w[c] == 0 )
               continue;
            if ( d[c] <= 1e-9 || d[1] <= 1e-9 )
            {
               s[c] = 1;
               console.warningln( "Warning: channel " + names[c] + " (or G) has (nearly) zero MAD; scale set to 1." );
            }
            else
               s[c] = d[1]/d[c];
         }

      // ---- one PixelMath expression: sum k_c*X_c + C
      let ids = src.colorMode ? [ "$T[0]", "$T[1]", "$T[2]" ] : [ src.views[0].id, src.views[1].id, src.views[2].id ];
      let M = 0, C = 0;
      if ( norm != 0 )
         for ( let c = 0; c < 3; ++c )
            M += w[c]*m[c];
      let terms = [];
      C = M;
      for ( let c = 0; c < 3; ++c )
      {
         if ( w[c] == 0 )
            continue;
         let k = w[c]*(norm == 2 ? s[c] : 1);
         terms.push( this.lit( k ) + "*" + ids[c] );
         if ( norm != 0 )
            C -= k*m[c];
      }
      let expr = terms.join( " + " );
      if ( norm != 0 && Math.abs( C ) >= 1e-12 )
         expr += (C < 0 ? " - " : " + ") + this.lit( Math.abs( C ) );

      let outId = this.uniqueId( "SyntheticLight" );
      let P = new PixelMath;
      P.expression = expr;
      P.useSingleExpression = true;
      P.createNewImage = true;
      P.showNewImage = false;
      P.newImageId = outId;
      P.newImageColorSpace = PixelMath.Gray;
      P.newImageSampleFormat = PixelMath.f32;
      P.rescale = false;
      P.truncate = true;
      P.truncateLower = 0;
      P.truncateUpper = 1;
      // In mono mode the target is the G view; it is not modified (createNewImage).
      let target = src.colorMode ? src.source : src.views[1];
      if ( !P.executeOn( target, false ) )
         throw new Error( "PixelMath failed." );

      let win = ImageWindow.windowById( outId );
      if ( win.isNull )
         throw new Error( "The output image was not created." );
      try
      {
         let srcWin = src.source.window;
         try { win.keywords = srcWin.keywords; } catch ( e ) {}
         try { win.copyAstrometricSolution( srcWin ); } catch ( e ) {}
         let oi = win.mainView.image;
         let outMedian = oi.median(), outMin = oi.minimum(), outMax = oi.maximum();
         win.show();
         win.bringToFront();
         console.writeln( format( "Medians: R=%.6f G=%.6f B=%.6f   MAD: R=%.6f G=%.6f B=%.6f", m[0], m[1], m[2], d[0], d[1], d[2] ) );
         console.writeln( format( "Scale: R=%.4f G=%.4f B=%.4f   M=%.6f", s[0], s[1], s[2], M ) );
         console.writeln( format( "Output %s: median=%.6f min=%.6f max=%.6f", outId, outMedian, outMin, outMax ) );
         return { wR: w[0], wG: w[1], wB: w[2], mR: m[0], mG: m[1], mB: m[2],
                  dR: d[0], dG: d[1], dB: d[2], sR: s[0], sG: s[1], sB: s[2],
                  M: M, outMedian: outMedian, outMin: outMin, outMax: outMax, outId: outId };
      }
      catch ( e )
      {
         win.forceClose();
         throw e;
      }
   }
};
