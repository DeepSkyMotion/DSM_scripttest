// SyntheticLight_v2GUI.js - dialog only. Reads/writes PSWParameters, never processes pixels.

var PSWDialog = class extends Dialog
{
   constructor( params, parent )
   {
      super( parent );

      this.params = params;
      let self = this;
      let labelWidth = this.font.width( "Normalized:" ) + this.font.width( 'M' );

      // Default views. Colour list: the active window if RGB, else the first RGB view.
      // Mono lists: views named like R / G / B (R, Red, M31_R, ...), else distinct mono views in order.
      // Nothing suitable -> the parameter stays empty (no meaningless default).
      {
         let active = ImageWindow.activeWindow;
         let wins = ImageWindow.windows;
         let colourIds = [], monoIds = [];
         for ( let i = 0; i < wins.length; ++i )
         {
            let nch = wins[i].mainView.image.numberOfChannels;
            if ( nch == 3 )
               colourIds.push( wins[i].mainView.id );
            else if ( nch == 1 )
               monoIds.push( wins[i].mainView.id );
         }
         if ( params.viewIdColor == "" )
         {
            if ( !active.isNull && active.mainView.image.numberOfChannels == 3 )
               params.viewIdColor = active.mainView.id;
            else if ( colourIds.length > 0 )
               params.viewIdColor = colourIds[0];
         }
         let monoProps = [ "viewIdR", "viewIdG", "viewIdB" ];
         let monoPat = [ "(r|red)", "(g|green)", "(b|blue)" ];
         let used = [];
         for ( let i = 0; i < 3; ++i )
            if ( params[monoProps[i]] != "" )
               used.push( params[monoProps[i]] );
         for ( let i = 0; i < 3; ++i )
         {
            if ( params[monoProps[i]] != "" )
               continue;
            let re = new RegExp( "^" + monoPat[i] + "$|[_\\-. ]" + monoPat[i] + "$|^" + monoPat[i] + "[_\\-. ]", "i" );
            for ( let j = 0; j < monoIds.length; ++j )
               if ( used.indexOf( monoIds[j] ) < 0 && re.test( monoIds[j] ) )
               {
                  params[monoProps[i]] = monoIds[j];
                  used.push( monoIds[j] );
                  break;
               }
         }
         for ( let i = 0; i < 3; ++i )
         {
            if ( params[monoProps[i]] != "" )
               continue;
            for ( let j = 0; j < monoIds.length; ++j )
               if ( used.indexOf( monoIds[j] ) < 0 )
               {
                  params[monoProps[i]] = monoIds[j];
                  used.push( monoIds[j] );
                  break;
               }
         }
      }

      this.helpLabel = new Label( this );
      this.helpLabel.frameStyle = FrameStyle.Box;
      this.helpLabel.margin = 6;
      this.helpLabel.wordWrapping = true;
      this.helpLabel.useRichText = true;
      this.helpLabel.text = "<p><b>" + PSW_TITLE + "</b> &mdash; Creates a synthetic monochrome luminance " +
         "image from R, G and B. Expects linear data. Sources are not modified.</p>";

      // ---- Input
      this.colorRadio = new RadioButton( this );
      this.colorRadio.text = "One RGB colour image";
      this.colorRadio.toolTip = "<p>Use one RGB image, or three separate mono images.</p>";
      this.colorRadio.checked = params.inputMode == 0;
      this.colorRadio.onCheck = function( checked ) { if ( checked ) { self.params.inputMode = 0; self.updateEnabled(); } };

      this.monoRadio = new RadioButton( this );
      this.monoRadio.text = "Three mono images (R, G, B)";
      this.monoRadio.toolTip = this.colorRadio.toolTip;
      this.monoRadio.checked = params.inputMode == 1;
      this.monoRadio.onCheck = function( checked ) { if ( checked ) { self.params.inputMode = 1; self.updateEnabled(); } };

      function makeViewList( label, tip, prop )
      {
         let lbl = new Label( self );
         lbl.text = label;
         lbl.minWidth = labelWidth;
         lbl.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;
         let vl = new ViewList( self );
         vl.getMainViews();
         vl.toolTip = tip;
         if ( params[prop] != "" )
         {
            let w = ImageWindow.windowById( params[prop] );
            if ( !w.isNull )
               vl.currentView = w.mainView;
         }
         vl.onViewSelected = function( view ) { self.params[prop] = view.isNull ? "" : view.id; };
         // Nothing chosen -> show an empty selection instead of the first view.
         if ( params[prop] == "" )
            vl.currentView = View.null;
         let s = new HorizontalSizer;
         s.spacing = 6;
         s.add( lbl );
         s.add( vl, 100 );
         return { sizer: s, label: lbl, list: vl };
      }
      this.cRow = makeViewList( "Colour:", "<p>RGB image to take the channels from.</p>", "viewIdColor" );
      this.rRow = makeViewList( "R:", "<p>Mono image for the red channel.</p>", "viewIdR" );
      this.gRow = makeViewList( "G:", "<p>Mono image for the green channel.</p>", "viewIdG" );
      this.bRow = makeViewList( "B:", "<p>Mono image for the blue channel.</p>", "viewIdB" );

      this.inputGroup = new GroupBox( this );
      this.inputGroup.title = "Input";
      this.inputGroup.sizer = new VerticalSizer;
      this.inputGroup.sizer.margin = 8;
      this.inputGroup.sizer.spacing = 6;
      this.inputGroup.sizer.add( this.colorRadio );
      this.inputGroup.sizer.add( this.cRow.sizer );
      this.inputGroup.sizer.add( this.monoRadio );
      this.inputGroup.sizer.add( this.rRow.sizer );
      this.inputGroup.sizer.add( this.gRow.sizer );
      this.inputGroup.sizer.add( this.bRow.sizer );

      // ---- Weights
      this.cameraLabel = new Label( this );
      this.cameraLabel.text = "Camera / source type:";
      this.cameraLabel.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;

      this.cameraCombo = new ComboBox( this );
      this.cameraCombo.addItem( "Colour CFA / OSC camera (1:2:1)" );
      this.cameraCombo.addItem( "Monochrome camera with RGB filters (Rec.709)" );
      this.cameraCombo.addItem( "Custom" );
      this.cameraCombo.toolTip =
         "<p><b>Camera / source type</b>: sets the R:G:B weights.</p>" +
         "<p><b>Colour CFA / OSC camera</b> (0.25 / 0.50 / 0.25): one-shot-colour data. A Bayer RGGB matrix has twice as many green pixels, so G carries about half of the real signal and has the best SNR. Use it for any debayered OSC stack, or for R, G, B channels extracted from one.</p>" +
         "<p><b>Monochrome camera with RGB filters</b> (Rec.709: 0.2126 / 0.7152 / 0.0722): separate R, G, B masters from a mono camera. The weights follow the eye's luminance response, so the result looks like natural brightness. Best when the three masters have similar exposure and SNR.</p>" +
         "<p><b>Custom</b>: your own weights. For example, favour the cleanest channel, set a noisy or gradient-heavy channel to 0, or use equal 1:1:1 weights. Editing any weight switches to Custom. Weights are normalized to sum 1.</p>";
      this.cameraLabel.toolTip = this.cameraCombo.toolTip;
      this.cameraCombo.currentItem = params.cameraType >= 0 && params.cameraType <= 2 ? params.cameraType : 2;
      this.cameraCombo.onItemSelected = function( index )
      {
         self.params.cameraType = index;
         if ( index < 2 )
         {
            self.params.weightR = PSW_PRESETS[index][0];
            self.params.weightG = PSW_PRESETS[index][1];
            self.params.weightB = PSW_PRESETS[index][2];
            self.syncWeights();
         }
         self.updateNormalized();
      };

      let cameraSizer = new HorizontalSizer;
      cameraSizer.spacing = 6;
      cameraSizer.add( this.cameraLabel );
      cameraSizer.add( this.cameraCombo, 100 );

      function makeWeight( label, prop )
      {
         let nc = new NumericControl( self );
         nc.label.text = label;
         nc.label.minWidth = labelWidth;
         nc.setRange( 0, 1 );
         nc.slider.setRange( 0, 1000 );
         nc.setPrecision( 4 );
         nc.setValue( params[prop] );
         nc.toolTip = "<p>Relative weight of the channel. Weights are normalized to sum 1.</p>";
         nc.onValueUpdated = function( value )
         {
            self.params[prop] = value;
            self.params.cameraType = 2;
            self.cameraCombo.currentItem = 2;
            self.updateNormalized();
         };
         return nc;
      }
      this.wR = makeWeight( "Red:", "weightR" );
      this.wG = makeWeight( "Green:", "weightG" );
      this.wB = makeWeight( "Blue:", "weightB" );

      this.normLabel = new Label( this );
      this.normLabel.useRichText = true;

      this.weightsGroup = new GroupBox( this );
      this.weightsGroup.title = "Weights";
      this.weightsGroup.sizer = new VerticalSizer;
      this.weightsGroup.sizer.margin = 8;
      this.weightsGroup.sizer.spacing = 6;
      this.weightsGroup.sizer.add( cameraSizer );
      this.weightsGroup.sizer.add( this.wR );
      this.weightsGroup.sizer.add( this.wG );
      this.weightsGroup.sizer.add( this.wB );
      this.weightsGroup.sizer.add( this.normLabel );

      // ---- Normalization
      this.normCombo = new ComboBox( this );
      this.normCombo.addItem( "None" );
      this.normCombo.addItem( "Match backgrounds" );
      this.normCombo.addItem( "Match backgrounds and scale" );
      this.normCombo.currentItem = params.normalization;
      this.normCombo.toolTip =
         "<p><b>Normalization</b>: how the channels are matched before they are combined. Everything stays linear; nothing is stretched.</p>" +
         "<p><b>None</b> (recommended default): plain weighted average of the original channels. Use it for calibrated, colour-balanced linear data, e.g. after background extraction and colour calibration.</p>" +
         "<p><b>Match backgrounds</b>: subtracts each channel's median and adds back their weighted mean. With weights that sum to 1 the result is identical to None. Kept for comparison.</p>" +
         "<p><b>Match backgrounds and scale</b>: also scales each channel so its dispersion (MAD) matches the G channel before weighting. Use it when the channels differ strongly in brightness or noise, e.g. mono R/G/B masters with different exposure times, or an OSC stack before colour calibration. Avoid it when a channel is dominated by bright nebulosity or strong gradients, because then MAD measures signal rather than noise.</p>";
      this.normCombo.onItemSelected = function( index ) { self.params.normalization = index; };

      this.normGroup = new GroupBox( this );
      this.normGroup.title = "Normalization";
      this.normGroup.toolTip = this.normCombo.toolTip;
      this.normGroup.sizer = new VerticalSizer;
      this.normGroup.sizer.margin = 8;
      this.normGroup.sizer.spacing = 6;
      this.normGroup.sizer.add( this.normCombo );

      // ---- Buttons
      this.okButton = new PushButton( this );
      this.okButton.text = "Create";
      this.okButton.icon = this.scaledResource( ":/icons/ok.png" );
      this.okButton.onClick = function()
      {
         try
         {
            PSWEngine.validate( self.params, null );
         }
         catch ( e )
         {
            (new MessageBox( e.message, PSW_TITLE, StdIcon.Error, StdButton.Ok )).execute();
            return;
         }
         self.ok();
      };

      this.cancelButton = new PushButton( this );
      this.cancelButton.text = "Cancel";
      this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
      this.cancelButton.onClick = function() { self.cancel(); };

      this.resetButton = new PushButton( this );
      this.resetButton.text = "Reset";
      this.resetButton.icon = this.scaledResource( ":/icons/reload.png" );
      this.resetButton.onClick = function()
      {
         let d = new PSWParameters;
         self.params.cameraType = d.cameraType;
         self.params.weightR = d.weightR;
         self.params.weightG = d.weightG;
         self.params.weightB = d.weightB;
         self.params.normalization = d.normalization;
         self.cameraCombo.currentItem = d.cameraType;
         self.normCombo.currentItem = d.normalization;
         self.syncWeights();
         self.updateNormalized();
      };

      this.buttonsSizer = new HorizontalSizer;
      this.buttonsSizer.spacing = 6;
      this.buttonsSizer.add( this.resetButton );
      this.buttonsSizer.addStretch();
      this.buttonsSizer.add( this.okButton );
      this.buttonsSizer.add( this.cancelButton );

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 8;
      this.sizer.add( this.helpLabel );
      this.sizer.add( this.inputGroup );
      this.sizer.add( this.weightsGroup );
      this.sizer.add( this.normGroup );
      this.sizer.add( this.buttonsSizer );

      this.windowTitle = PSW_TITLE;
      this.setScaledMinWidth( 460 );
      this.updateEnabled();
      this.updateNormalized();
      this.adjustToContents();
   }

   syncWeights()
   {
      this.wR.setValue( this.params.weightR );
      this.wG.setValue( this.params.weightG );
      this.wB.setValue( this.params.weightB );
   }

   updateEnabled()
   {
      let color = this.params.inputMode == 0;
      this.colorRadio.checked = color;
      this.monoRadio.checked = !color;
      this.cRow.list.enabled = color;
      this.cRow.label.enabled = color;
      for ( let r of [ this.rRow, this.gRow, this.bRow ] )
      {
         r.list.enabled = !color;
         r.label.enabled = !color;
      }
   }

   updateNormalized()
   {
      let txt;
      try
      {
         let w = PSWEngine.weights( this.params );
         txt = format( "Normalized: %.3f / %.3f / %.3f", w[0], w[1], w[2] );
      }
      catch ( e )
      {
         txt = "Normalized: " + e.message;
      }
      this.normLabel.text = txt;
   }
};
