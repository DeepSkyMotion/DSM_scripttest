// SmartFrameSelection_v2Engine.js - processing logic, no GUI objects allowed here.
//
// Contract used by the GUI and by the headless test harness:
//   new PSWParameters()         -> object with defaults, .load(), .save()
//   PSWEngine.run(view, params) -> batch run on params.files (view is ignored, may be null),
//                                  returns { nInput, nMeasured, nFailed, nApproved,
//                                            nRejected, nExported, seconds } (numbers only)
//
// ----------------------------------------------------------------------------
// Discovery notes (spec 4.0), verified by headless probes on PixInsight 1.9.4:
//  1. SubframeSelector parameters used here (names checked against toSource()):
//     routine, nonInteractive, subframes [enabled, path, lnPath, drizzlePath],
//     fileCache, subframeScale, cameraGain, cameraResolution, siteLocalMidnight,
//     scaleUnit, dataUnit, trimmingFactor, structureLayers, noiseLayers,
//     sensitivity, peakResponse, maxDistortion, upperLimit, psfFit,
//     psfFitCircular, roiX0/Y0/X1/Y1, onError, approvalExpression,
//     weightingExpression, outputDirectory, useFileThreads.
//     "backgroundExpansion" and "xyStretch" (WeightsOptimizer) do NOT exist in
//     1.9.4 and are not set.
//  2. Enums: MeasureSubframes=0; Bits8=0 Bits10=1 Bits12=2 Bits14=3 Bits16=4
//     (no 32-bit value: 32-bit integer and float data map to Bits16);
//     ArcSeconds=0 Pixel=1; Electron=0 DataNumber=1 Normalized=2;
//     Gaussian=0 Moffat10=1 Moffat8=2 Moffat6=3 Moffat4=4 Moffat25=5 Moffat15=6
//     Lorentzian=7; Continue=0 Abort=1 AskUser=2.
//  3. P.measurements columns come from SubframeSelector.measurements_* constants:
//     index 0, enabled 1, filePath 3, weight 4, FWHM 5, eccentricity 6,
//     PSFSignalWeight 7, SNRWeight 9, median 10, noise 12, stars 14, PSFFlux 21,
//     MStar 26, PSFSNR 28. There is no "measurementPath" column: rows are mapped
//     back through filePath (it equals the path given in subframes). The COL
//     table is built from the constants at run time; a missing constant hides
//     the metric.
//  4. SFS has NO read-noise parameter. Read noise is stored in the CSV report and
//     in exported metadata (SFS_RDNOISE) only.
//  5. cameraResolution mapping: BITPIX 8 -> Bits8, 10/12/14 -> Bits10/12/14,
//     16 -> Bits16, 32 / float -> Bits16 (largest available).
//  6. FileFormatInstance.read( startRow, rowCount, channel ) reads row strips
//     (Matrix, normalised [0,1] with the "normalize" hint) when
//     canReadIncrementally is true (true for FITS and plain XISF). The CFA
//     extraction therefore reads only the ROI rows; otherwise it falls back to a
//     full readImage (one frame at a time).
//  7. The FWHM column of P.measurements is ALWAYS in pixels of the measured file:
//     subframeScale and scaleUnit only affect the SFS GUI/expressions (probe: the
//     same FWHM for scale 1, 2, 0.767 and ArcSeconds/Pixel). The script converts
//     FWHM to arcsec itself: FWHM["] = FWHM[px] * scale (scale doubled for the
//     CFA SuperPixel files only; debayered VNG/Bilinear files keep the full ROI
//     resolution), so normal and CFA values are comparable.
//  Extra findings: a missing/unreadable file in the subframe list makes the whole
//  SFS call fail (executeGlobal() == false, no rows) even with onError=Continue,
//  so every file is probed first, and a failed batch is retried file by file.
//  The SFS ROI works on the originals (star count drops with a smaller ROI).
//
// Debayer discovery (v2, headless probes on PixInsight 1.9.4):
//  - Parameters: cfaPattern (Debayer.Auto/RGGB/BGGR/GBRG/GRBG/...), debayerMethod
//    (Debayer.SuperPixel/Bilinear/VNG), evaluateNoise, evaluateSignal, showImages,
//    noGUIMessages, outputRGBImages, outputSeparateChannels (+ file-mode parameters
//    that are not used here). Read-only after executeOn: outputImage (RGB window id)
//    and outputChannelImageR/G/B (separate channel window ids).
//  - executeOn( view, false ) on a 1-channel CFA view leaves the source untouched and
//    creates NEW image windows: "<id>_RGB_<method>" (outputRGBImages) and/or
//    "<id>_R_<method>", "<id>_G_<method>", "<id>_B_<method>" (outputSeparateChannels).
//    showImages = true shows them; showImages = false keeps them hidden.
//  - Cheapest path used here: outputRGBImages = false, outputSeparateChannels = true,
//    showImages = false, evaluateNoise = evaluateSignal = false, noGUIMessages = true.
//    The chosen channel window (outputChannelImageX) is written to the temp XISF as is
//    (no getSamples copy); every window created by the call is closed with forceClose()
//    in a finally block (ImageWindow.windows is compared before/after).
//  - Probe: flat RGGB cells R 0.1 / G 0.4 / B 0.8 give exactly 0.1 / 0.4 / 0.8 per
//    channel with VNG and Bilinear.
// ----------------------------------------------------------------------------

var PSW_HINTS_IN = "fits-keywords normalize only-first-image raw cfa use-roworder-keywords signed-is-physical";
var PSW_CFA_PATTERNS = [ "RGGB", "BGGR", "GRBG", "GBRG" ];
var PSW_FILE_EXTS = [ ".xisf", ".fit", ".fits", ".fts" ];

// Metric table: key (rule name), SFS constant, display label, rule-table label (with units),
// FITS keyword.
var PSW_METRICS = [
   { key: "FWHM",            sfs: "measurements_FWHM",            label: "FWHM",     title: "FWHM (arcsec)",       kw: "SFS_FWHM"  },
   { key: "Eccentricity",    sfs: "measurements_eccentricity",    label: "Ecc.",     title: "Eccentricity",        kw: "SFS_ECC"   },
   { key: "PSFSignalWeight", sfs: "measurements_PSFSignalWeight", label: "PSF SW",   title: "PSF Signal Weight",   kw: "SFS_PSFSW" },
   { key: "PSFSNR",          sfs: "measurements_PSFSNR",          label: "PSF SNR",  title: "PSF SNR",             kw: "SFS_PSNR"  },
   { key: "SNR",             sfs: "measurements_SNRWeight",       label: "SNR",      title: "SNR",                 kw: "SFS_SNR"   },
   { key: "Stars",           sfs: "measurements_stars",           label: "Stars",    title: "Stars (count)",       kw: "SFS_STARS" },
   { key: "Median",          sfs: "measurements_median",          label: "Median",   title: "Median (DN or e-)",   kw: "SFS_MED"   },
   { key: "Noise",           sfs: "measurements_noise",           label: "Noise",    title: "Noise (DN or e-)",    kw: "SFS_NOISE" },
   { key: "MStar",           sfs: "measurements_MStar",           label: "M*",       title: "M* (DN or e-)",       kw: "SFS_MSTAR" },
   { key: "PSFFlux",         sfs: "measurements_PSFFlux",         label: "PSF flux", title: "PSF flux",            kw: "SFS_PFLUX" }
];

// Rule table prefill (all rows start unchecked): [kind, reject below, reject above].
var PSW_RULE_PREFILL = {
   FWHM: [ "sigma", null, 3 ], Eccentricity: [ "abs", null, 0.6 ], PSFSignalWeight: [ "sigma", 3, null ],
   PSFSNR: [ "sigma", 3, null ], SNR: [ "sigma", 3, null ], Stars: [ "pct", 50, null ],
   Median: [ "sigma", null, 3 ], Noise: [ "sigma", null, 3 ], MStar: [ "sigma", null, null ], PSFFlux: [ "sigma", null, null ]
};
var PSW_RULE_KINDS = [ "abs", "sigma", "pct" ];

var PSW_PSF_MODELS = [ "Gaussian", "Moffat4", "Moffat6", "Moffat8", "Moffat10", "Moffat15", "Moffat25", "Lorentzian" ];
var PSW_CFA_HANDLING = [ "Auto", "Off", "Debayer" ];
var PSW_CFA_CHANNELS = [ "R", "G", "B" ];
var PSW_DEBAYER_METHODS = [ "VNG", "Bilinear", "SuperPixel" ];
var PSW_BAYER = [ "Auto", "RGGB", "BGGR", "GRBG", "GBRG" ];
var PSW_BIT_DEPTHS = [ 8, 10, 12, 14, 16, 32 ];
#ifoneof __PI_PLATFORM__ MSWINDOWS MACOSX
var PSW_CASE_INSENSITIVE_FS = true;
#else
var PSW_CASE_INSENSITIVE_FS = false;
#endif

var PSWParameters = class
{
   constructor()
   {
      this.files = [];
      this.outputDir = "";
      this.subframeScale = 1.0;
      this.cameraGain = 1.0;
      this.readNoise = 0;
      this.bitDepth = 16;
      this.roiFraction = 50;
      this.cfaHandling = "Auto";     // "Auto" (Debayer for CFA frames) | "Off" | "Debayer"
      this.cfaChannel = "G";         // "R" | "G" | "B"
      this.debayerMethod = "VNG";    // "VNG" | "Bilinear" | "SuperPixel"
      this.bayerOverride = "Auto";
      this.psfFit = "Moffat4";
      this.batchSize = 6;
      this.mode = "auto";            // "auto" | "rules" | "review"
      this.ruleTable = PSWEngine.defaultRuleTable();
      this.copyUnchanged = false;
      this.copyRejected = false;
      this.lastDir = "";
      this.settingsKey = PSW_SETTINGS;   // the harness may redirect it for a round-trip test
      this.reviewCallback = undefined;   // set by the GUI (never persisted)
   }

   load()
   {
      let K = this.settingsKey + "/";
      let s = ( k, t ) => { let v = Settings.read( K + k, t ); return Settings.lastReadOK ? v : undefined; };
      let v;
      if ( ( v = s( "outputDir", DataType.String ) ) !== undefined ) this.outputDir = v;
      if ( ( v = s( "subframeScale", DataType.Double ) ) !== undefined ) this.subframeScale = v;
      if ( ( v = s( "cameraGain", DataType.Double ) ) !== undefined ) this.cameraGain = v;
      if ( ( v = s( "readNoise", DataType.Double ) ) !== undefined ) this.readNoise = v;
      if ( ( v = s( "bitDepth", DataType.Int32 ) ) !== undefined ) this.bitDepth = v;
      if ( ( v = s( "roiFraction", DataType.Int32 ) ) !== undefined ) this.roiFraction = v;
      if ( ( v = s( "cfaHandling", DataType.String ) ) !== undefined && PSW_CFA_HANDLING.indexOf( v ) >= 0 ) this.cfaHandling = v;
      if ( ( v = s( "cfaChannel", DataType.String ) ) !== undefined && PSW_CFA_CHANNELS.indexOf( v ) >= 0 ) this.cfaChannel = v;
      if ( ( v = s( "debayerMethod", DataType.String ) ) !== undefined && PSW_DEBAYER_METHODS.indexOf( v ) >= 0 ) this.debayerMethod = v;
      if ( ( v = s( "bayerOverride", DataType.String ) ) !== undefined && PSW_BAYER.indexOf( v ) >= 0 ) this.bayerOverride = v;
      if ( ( v = s( "psfFit", DataType.String ) ) !== undefined && PSW_PSF_MODELS.indexOf( v ) >= 0 ) this.psfFit = v;
      if ( ( v = s( "batchSize", DataType.Int32 ) ) !== undefined ) this.batchSize = v;
      if ( ( v = s( "mode", DataType.String ) ) !== undefined && [ "auto", "rules", "review" ].indexOf( v ) >= 0 ) this.mode = v;
      if ( ( v = s( "copyUnchanged", DataType.Boolean ) ) !== undefined ) this.copyUnchanged = v;
      if ( ( v = s( "copyRejected", DataType.Boolean ) ) !== undefined ) this.copyRejected = v;
      if ( ( v = s( "lastDir", DataType.String ) ) !== undefined ) this.lastDir = v;
      if ( ( v = s( "ruleTable", DataType.String ) ) !== undefined )
      {
         try { this.ruleTable = PSWEngine.normalizeRuleTable( JSON.parse( v ) ); }
         catch ( e ) {}
      }
      this.clamp();
   }

   clamp()
   {
      this.roiFraction = Math.max( 25, Math.min( 100, Math.round( this.roiFraction ) ) );
      this.batchSize = Math.max( 1, Math.min( 32, Math.round( this.batchSize ) ) );
      if ( PSW_BIT_DEPTHS.indexOf( this.bitDepth ) < 0 )
         this.bitDepth = 16;
   }

   save()
   {
      let K = this.settingsKey + "/";
      Settings.write( K + "outputDir", DataType.String, this.outputDir );
      Settings.write( K + "subframeScale", DataType.Double, this.subframeScale );
      Settings.write( K + "cameraGain", DataType.Double, this.cameraGain );
      Settings.write( K + "readNoise", DataType.Double, this.readNoise );
      Settings.write( K + "bitDepth", DataType.Int32, this.bitDepth );
      Settings.write( K + "roiFraction", DataType.Int32, this.roiFraction );
      Settings.write( K + "cfaHandling", DataType.String, this.cfaHandling );
      Settings.write( K + "cfaChannel", DataType.String, this.cfaChannel );
      Settings.write( K + "debayerMethod", DataType.String, this.debayerMethod );
      Settings.write( K + "bayerOverride", DataType.String, this.bayerOverride );
      Settings.write( K + "psfFit", DataType.String, this.psfFit );
      Settings.write( K + "batchSize", DataType.Int32, this.batchSize );
      Settings.write( K + "mode", DataType.String, this.mode );
      Settings.write( K + "copyUnchanged", DataType.Boolean, this.copyUnchanged );
      Settings.write( K + "copyRejected", DataType.Boolean, this.copyRejected );
      Settings.write( K + "lastDir", DataType.String, this.lastDir );
      // Invalid (non-numeric) cells are stored as empty.
      Settings.write( K + "ruleTable", DataType.String, JSON.stringify( PSWEngine.normalizeRuleTable( this.ruleTable ).map( r =>
         ( { metric: r.metric, enabled: r.enabled, kind: r.kind, lo: isFinite( r.lo ) && r.lo !== null ? r.lo : null,
             hi: isFinite( r.hi ) && r.hi !== null ? r.hi : null } ) ) ) );
   }
};

var PSWEngine = {

   // ======================================================================
   // Pure functions (no GUI, no pixel I/O)
   // ======================================================================

   // keywords: [{name, value}], props: { id: value } (XISF properties / CFA array).
   parseHeader: function( keywords, props )
   {
      let kw = Object.create( null );
      for ( let i = 0; i < ( keywords || [] ).length; ++i )
      {
         let k = keywords[ i ];
         if ( !k || k.name === undefined )
            continue;
         let n = String( k.name ).trim().toUpperCase();
         if ( n.length == 0 || n in kw )
            continue;
         let v = String( k.value === undefined || k.value === null ? "" : k.value ).trim();
         if ( v.length >= 2 && v[ 0 ] == "'" && v[ v.length - 1 ] == "'" )
            v = v.substring( 1, v.length - 1 ).trim();
         kw[ n ] = v;
      }
      let num = n => { if ( !( n in kw ) ) return NaN; let x = parseFloat( kw[ n ] ); return isFinite( x ) ? x : NaN; };
      let h = { width: 0, height: 0, bitpix: 0, bayerPat: "", xBayOff: 0, yBayOff: 0,
                scale: NaN, scaleSrc: "", gain: NaN, gainSrc: "", readNoise: NaN, rnSrc: "",
                cfa: false, cfaSrc: "", instrument: "", exptime: NaN, binning: 1, binningAmbiguous: false,
                bottomUp: false };
      let w = num( "NAXIS1" ), hh = num( "NAXIS2" ), bp = num( "BITPIX" );
      if ( w > 0 ) h.width = Math.round( w );
      if ( hh > 0 ) h.height = Math.round( hh );
      if ( isFinite( bp ) && bp != 0 ) h.bitpix = Math.abs( Math.round( bp ) );

      // Scale: SCALE / PIXSCALE, then 206.265*XPIXSZ/FOCALLEN (XPIXSZ taken as written).
      for ( let n of [ "SCALE", "PIXSCALE" ] )
      {
         let s = num( n );
         if ( s > 0 ) { h.scale = s; h.scaleSrc = n; break; }
      }
      let px = num( "XPIXSZ" ), fl = num( "FOCALLEN" ), bin = num( "XBINNING" );
      if ( bin > 1 ) h.binning = Math.round( bin );
      if ( isNaN( h.scale ) && px > 0 && fl > 0 )
      {
         h.scale = 206.265*px/fl;
         h.scaleSrc = "XPIXSZ/FOCALLEN";
         if ( h.binning > 1 && px <= 9*1.05 )
            h.binningAmbiguous = true;     // never multiplied; the GUI asks the user to check
      }
      // Gain: EGAIN only (GAIN is a camera setting, not e-/ADU).
      let g = num( "EGAIN" );
      if ( g > 0 ) { h.gain = g; h.gainSrc = "EGAIN"; }
      for ( let n of [ "RDNOISE", "READNOIS", "RDNOISE1" ] )
      {
         let r = num( n );
         if ( r >= 0 ) { h.readNoise = r; h.rnSrc = n; break; }
      }
      for ( let n of [ "BAYERPAT", "CFAPAT", "CFA-PAT" ] )
         if ( n in kw )
         {
            let p = kw[ n ].toUpperCase();
            if ( PSW_CFA_PATTERNS.indexOf( p ) >= 0 ) { h.bayerPat = p; h.cfaSrc = n; break; }
         }
      if ( !h.bayerPat && props )
         for ( let n of [ "PCL:CFASourcePattern", "ColorFilterArray" ] )
            if ( props[ n ] )
            {
               let p = String( props[ n ] ).trim().toUpperCase();
               if ( PSW_CFA_PATTERNS.indexOf( p ) >= 0 ) { h.bayerPat = p; h.cfaSrc = n; break; }
            }
      h.cfa = h.bayerPat.length > 0;
      let xo = num( "XBAYROFF" ), yo = num( "YBAYROFF" );
      if ( isFinite( xo ) ) h.xBayOff = Math.round( xo );
      if ( isFinite( yo ) ) h.yBayOff = Math.round( yo );
      if ( "ROWORDER" in kw ) h.bottomUp = kw.ROWORDER.toUpperCase() == "BOTTOM-UP";
      if ( "INSTRUME" in kw ) h.instrument = kw.INSTRUME;
      let e = num( "EXPTIME" );
      if ( isNaN( e ) ) e = num( "EXPOSURE" );
      h.exptime = e;
      return h;
   },

   // flipHeight: image height when the reader flipped the rows (ROWORDER='BOTTOM-UP' read with
   // use-roworder-keywords), else 0. Row y as read is stored row H-1-y, so the pattern row
   // parity shifts by H-1: the pattern flips vertically for even H and is unchanged for odd H.
   effectivePattern: function( pat, xOff, yOff, roiX0, roiY0, flipHeight )
   {
      pat = String( pat || "" ).toUpperCase();
      if ( PSW_CFA_PATTERNS.indexOf( pat ) < 0 )
         return "";
      let m2 = v => ( ( Math.round( v || 0 ) % 2 ) + 2 ) % 2;
      let dx = m2( ( xOff || 0 ) + ( roiX0 || 0 ) ), dy = m2( ( yOff || 0 ) + ( roiY0 || 0 ) + ( flipHeight > 0 ? flipHeight - 1 : 0 ) );
      let s = "";
      for ( let r = 0; r < 2; ++r )
         for ( let c = 0; c < 2; ++c )
            s += pat[ ( ( r + dy ) % 2 )*2 + ( c + dx ) % 2 ];
      return s;
   },

   // Centred ROI. Without align2, a ROI covering the whole frame is 0,0,0,0 (SFS: full image).
   // With align2 the rect is always explicit and even-aligned (odd last row/column ignored).
   computeRoi: function( w, h, fraction, align2 )
   {
      let f = Math.max( 0, Math.min( 1, fraction ) );
      let rw = Math.min( w, Math.max( Math.round( w*f ), Math.min( 256, w ) ) );
      let rh = Math.min( h, Math.max( Math.round( h*f ), Math.min( 256, h ) ) );
      let x0 = Math.floor( ( w - rw )/2 ), y0 = Math.floor( ( h - rh )/2 );
      if ( align2 )
      {
         rw -= rw % 2; rh -= rh % 2;
         x0 -= x0 % 2; y0 -= y0 % 2;
         return { x0: x0, y0: y0, x1: x0 + rw, y1: y0 + rh };
      }
      if ( rw == w && rh == h )
         return { x0: 0, y0: 0, x1: 0, y1: 0 };
      return { x0: x0, y0: y0, x1: x0 + rw, y1: y0 + rh };
   },

   // src: Float32Array block of h rows; the block's ROI starts at column x0 with row
   // stride 'stride' (defaults: stride = w, x0 = 0). w, h even. Writes (w/2)*(h/2)
   // values to out starting at outOffset. Pattern indices 0..3 = TL, TR, BL, BR.
   // Every channel takes ONE pixel per 2x2 cell, so the superpixel grid is a pure
   // subsampling (no smoothing): G is the green pixel on the same row as R ("Gr";
   // RGGB/GRBG: the first G of the pattern, BGGR/GBRG: the second). Averaging the two
   // diagonal greens would smear stars along the diagonal (false eccentricity).
   extractSuperpixel: function( src, w, h, pattern, channel, out, outOffset, stride, x0 )
   {
      stride = stride || w;
      x0 = x0 || 0;
      outOffset = outOffset || 0;
      let ow = w >> 1, oh = h >> 1;
      if ( !out || out.length < outOffset + ow*oh )
         out = new Float32Array( outOffset + ow*oh );
      let p = String( pattern ).toUpperCase();
      let ch = String( channel ).toUpperCase();
      let kR = p.indexOf( "R" );
      let k1 = ch == "G" ? ( kR < 0 ? -1 : ( kR & 2 ) | ( 1 - ( kR & 1 ) ) ) : p.indexOf( ch );
      if ( k1 < 0 || p[ k1 ] != ch )
         throw new Error( "Channel " + ch + " not in pattern " + p );
      let dy1 = k1 >> 1, dx1 = k1 & 1;
      for ( let j = 0; j < oh; ++j )
      {
         let r1 = ( 2*j + dy1 )*stride + x0 + dx1, o = outOffset + j*ow;
         for ( let i = 0; i < ow; ++i )
            out[ o + i ] = src[ r1 + 2*i ];
      }
      return out;
   },

   robustStats: function( values )
   {
      let a = [];
      for ( let i = 0; i < values.length; ++i )
      {
         let v = values[ i ];
         if ( typeof v == "number" && isFinite( v ) )
            a.push( v );
      }
      let n = a.length;
      if ( n == 0 )
         return { n: 0, median: NaN, mad: NaN, sigma: NaN, min: NaN, max: NaN };
      a.sort( ( x, y ) => x - y );          // the only sort copy
      let med = s => { let m = s.length >> 1; return ( s.length & 1 ) ? s[ m ] : 0.5*( s[ m - 1 ] + s[ m ] ); };
      let median = med( a );
      let d = new Float64Array( n );
      for ( let i = 0; i < n; ++i )
         d[ i ] = Math.abs( a[ i ] - median );
      d.sort();
      let mad = med( d );
      return { n: n, median: median, mad: mad, sigma: 1.4826*mad, min: a[ 0 ], max: a[ n - 1 ] };
   },

   // Stats per metric over measured, non-failed rows (or the given row indices).
   computeStats: function( rows, onlyIdx )
   {
      let st = {};
      for ( let m of PSW_METRICS )
      {
         let v = [];
         if ( onlyIdx )
            for ( let i of onlyIdx ) v.push( rows[ i ].m[ m.key ] );
         else
            for ( let r of rows )
               if ( !r.failed && r.m ) v.push( r.m[ m.key ] );
         st[ m.key ] = this.robustStats( v );
      }
      return st;
   },

   // --- Rule table (v2): one row per metric -------------------------------
   // Row: { metric, enabled, kind: "abs"|"sigma"|"pct", lo: number|null, hi: number|null }.
   // lo = "reject below", hi = "reject above"; null = no limit on that side. A cell that is
   // not a number is NaN here (validation reports it; evaluation fails it closed).

   // Cell text -> { ok, value }: "" = no limit (null), else a plain decimal number.
   parseCell: function( text )
   {
      let t = String( text === undefined || text === null ? "" : text ).trim();
      if ( t.length == 0 )
         return { ok: true, value: null };
      if ( /^[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?$/.test( t ) )
      {
         let v = parseFloat( t );
         if ( isFinite( v ) )
            return { ok: true, value: v };
      }
      return { ok: false, value: NaN };
   },

   cellValue: function( v )
   {
      if ( v === null || v === undefined )
         return null;
      if ( typeof v == "number" )
         return isFinite( v ) ? v : NaN;
      return this.parseCell( v ).value;
   },

   defaultRuleTable: function()
   {
      return PSW_METRICS.map( m =>
      {
         let p = PSW_RULE_PREFILL[ m.key ] || [ "sigma", null, null ];
         return { metric: m.key, enabled: false, kind: p[ 0 ], lo: p[ 1 ], hi: p[ 2 ] };
      } );
   },

   normalizeRuleRow: function( r, metric )
   {
      return {
         metric: metric || String( r && r.metric || "" ),
         enabled: !!( r && r.enabled === true ),
         kind: r && PSW_RULE_KINDS.indexOf( r.kind ) >= 0 ? r.kind : "abs",
         lo: this.cellValue( r ? r.lo : null ),
         hi: this.cellValue( r ? r.hi : null )
      };
   },

   // Full table in PSW_METRICS order; rows missing from t get the (unchecked) prefill.
   normalizeRuleTable: function( t )
   {
      let by = Object.create( null );
      for ( let r of Array.isArray( t ) ? t : [] )
         if ( r && typeof r.metric == "string" )
            by[ r.metric ] = r;
      let def = this.defaultRuleTable();
      return def.map( d => this.normalizeRuleRow( d.metric in by ? by[ d.metric ] : d, d.metric ) );
   },

   metricTitle: function( key )
   {
      for ( let m of PSW_METRICS )
         if ( m.key == key )
            return m.title;
      return key;
   },

   // "" when the row is usable, else an English error. Checks numbers on every row,
   // and "checked but empty" only for checked rows.
   ruleRowError: function( r )
   {
      let name = this.metricTitle( r.metric );
      for ( let side of [ [ "lo", "Reject below" ], [ "hi", "Reject above" ] ] )
      {
         let v = r[ side[ 0 ] ];
         if ( v === null )
            continue;
         if ( typeof v != "number" || !isFinite( v ) )
            return name + ": \"" + side[ 1 ] + "\" is not a number.";
         if ( r.kind != "abs" && v < 0 )
            return name + ": \"" + side[ 1 ] + "\" must be zero or positive for " +
                   ( r.kind == "sigma" ? "sigma" : "percent" ) + " limits.";
      }
      if ( r.kind == "abs" && r.lo !== null && r.hi !== null && r.lo > r.hi )
         return name + ": \"Reject below\" is greater than \"Reject above\" (every frame would be rejected).";
      if ( r.enabled && r.lo === null && r.hi === null )
         return name + ": the row is checked but both limits are empty.";
      return "";
   },

   // needActive: Rule set mode needs at least one active row.
   validateRuleTable: function( table, needActive )
   {
      let t = this.normalizeRuleTable( table );
      for ( let r of t )
      {
         let e = this.ruleRowError( r );
         if ( e )
            return e;
      }
      if ( needActive && !t.some( r => r.enabled ) )
         return "Rule set mode needs at least one checked row in the rule table.";
      return "";
   },

   // Checked, valid rows with at least one limit (invalid rows are ignored here; validation
   // blocks Run/Export while any row is invalid).
   activeRules: function( table, available )
   {
      return this.normalizeRuleTable( table ).filter( r => r.enabled && ( r.lo !== null || r.hi !== null ) &&
         this.ruleRowError( r ) == "" && ( !available || available.indexOf( r.metric ) >= 0 ) );
   },

   // Limits of one row: { lo, hi } (null = none, NaN = not computable) and their tags.
   ruleLimits: function( r, stats )
   {
      let out = { lo: null, hi: null, loTag: "", hiTag: "" };
      let s = stats ? stats[ r.metric ] : null;
      let ok = s && s.n > 0;
      if ( r.lo !== null )
      {
         if ( r.kind == "abs" ) out.lo = r.lo;
         else if ( r.kind == "sigma" ) { out.lo = ok ? s.median - r.lo*s.sigma : NaN; out.loTag = "med-" + r.lo + "s"; }
         else { out.lo = ok ? s.median*( 1 - r.lo/100 ) : NaN; out.loTag = "med-" + r.lo + "%"; }
      }
      if ( r.hi !== null )
      {
         if ( r.kind == "abs" ) out.hi = r.hi;
         else if ( r.kind == "sigma" ) { out.hi = ok ? s.median + r.hi*s.sigma : NaN; out.hiTag = "med+" + r.hi + "s"; }
         else { out.hi = ok ? s.median*( 1 + r.hi/100 ) : NaN; out.hiTag = "med+" + r.hi + "%"; }
      }
      return out;
   },

   // Graph lines of the active rows: both sides.
   ruleThresholds: function( table, stats, available )
   {
      let out = [];
      for ( let r of this.activeRules( table, available ) )
      {
         let L = this.ruleLimits( r, stats );
         if ( L.lo !== null && isFinite( L.lo ) )
            out.push( { metric: r.metric, dir: "below", value: L.lo,
                        label: r.metric + " < " + this.fmt( L.lo ) + ( L.loTag ? " (" + L.loTag + ")" : "" ) } );
         if ( L.hi !== null && isFinite( L.hi ) )
            out.push( { metric: r.metric, dir: "above", value: L.hi,
                        label: r.metric + " > " + this.fmt( L.hi ) + ( L.hiTag ? " (" + L.hiTag + ")" : "" ) } );
      }
      return out;
   },

   // rows: [{failed, failReason, m:{metric:value}}]; table: rule table; overrides: {rowIndex: bool}.
   // Returns [{approved, reasons[], manual}]. Stats are computed once (or passed in).
   // NaN values and limits that cannot be computed fail closed.
   evalRules: function( rows, table, stats, overrides, available )
   {
      stats = stats || this.computeStats( rows );
      let rl = this.activeRules( table, available );
      let lim = rl.map( r => this.ruleLimits( r, stats ) );
      let res = [];
      for ( let i = 0; i < rows.length; ++i )
      {
         let row = rows[ i ];
         if ( row.failed )
         {
            res.push( { approved: false, reasons: [ "failed: " + ( row.failReason || "not measured" ) ], manual: false } );
            continue;
         }
         let reasons = [];
         for ( let k = 0; k < rl.length; ++k )
         {
            let key = rl[ k ].metric, L = lim[ k ];
            let v = row.m ? row.m[ key ] : undefined;
            if ( !( typeof v == "number" && isFinite( v ) ) )
            {
               reasons.push( key + " n/a (no value)" );
               continue;
            }
            if ( L.lo !== null )
            {
               if ( !isFinite( L.lo ) ) reasons.push( key + " limit n/a" );
               else if ( v < L.lo ) reasons.push( key + " " + this.fmt( v ) + " < " + this.fmt( L.lo ) + ( L.loTag ? " (" + L.loTag + ")" : "" ) );
            }
            if ( L.hi !== null )
            {
               if ( !isFinite( L.hi ) ) { if ( L.lo === null || isFinite( L.lo ) ) reasons.push( key + " limit n/a" ); }
               else if ( v > L.hi ) reasons.push( key + " " + this.fmt( v ) + " > " + this.fmt( L.hi ) + ( L.hiTag ? " (" + L.hiTag + ")" : "" ) );
            }
         }
         let r = { approved: reasons.length == 0, reasons: reasons, manual: false };
         if ( overrides && Object.prototype.hasOwnProperty.call( overrides, i ) )
         {
            r.approved = !!overrides[ i ];
            r.manual = true;
            if ( r.approved ) r.reasons = [];
            else if ( r.reasons.length == 0 ) r.reasons = [ "manual" ];
         }
         res.push( r );
      }
      return res;
   },

   // --- Auto rule (spec 4.6) ---------------------------------------------
   // stats0 (optional): computeStats( rows ) already computed by the caller; it equals the
   // first-pass statistics (all non-failed rows) and is reused instead of being recomputed.
   autoRule: function( rows, available, stats0 )
   {
      let n0 = rows.length;
      let approved = new Array( n0 ).fill( false );
      let reasons = [];
      for ( let i = 0; i < n0; ++i ) reasons.push( [] );
      let warnings = [];
      let has = k => ( !available || available.indexOf( k ) >= 0 ) &&
                     rows.some( r => !r.failed && r.m && typeof r.m[ k ] == "number" && isFinite( r.m[ k ] ) );
      let valid = [];
      for ( let i = 0; i < n0; ++i )
         if ( rows[ i ].failed ) reasons[ i ].push( "failed: " + ( rows[ i ].failReason || "not measured" ) );
         else valid.push( i );
      let n = valid.length;
      if ( n == 0 )
         return { approved: approved, reasons: reasons.map( r => r.join( "; " ) ), warnings: [ "no valid frames" ], thresholds: [] };
      for ( let k of [ "FWHM", "Eccentricity", "PSFSignalWeight", "Stars", "Median" ] )
         if ( !has( k ) )
            warnings.push( "metric " + k + " not available: its auto rule is skipped" );
      let small = n < 5;
      if ( small )
         warnings.push( "few frames: only absolute caps" );
      let floorOf = ( k, s ) => k == "Eccentricity" ? 0.01 : k == "Stars" ? 0.02*Math.abs( s.median ) : 0.01*Math.abs( s.median );
      let sig = ( k, s ) => Math.max( s.sigma, floorOf( k, s ) );
      let rejected = new Array( n0 ).fill( false );

      let pass = ( survivors, st ) =>
      {
         st = st || this.computeStats( rows, survivors );
         let th = [];
         if ( has( "Eccentricity" ) )
         {
            let s = st.Eccentricity;
            let L = small ? 0.70 : Math.max( s.median + 3*sig( "Eccentricity", s ), 0.70 );
            th.push( { metric: "Eccentricity", dir: "above", value: L, label: "Eccentricity > " + this.fmt( L ) } );
         }
         if ( has( "Stars" ) && n >= 3 )
         {
            let L = 0.5*st.Stars.median;
            th.push( { metric: "Stars", dir: "below", value: L, label: "Stars < 50% of median (" + this.fmt( L ) + ")" } );
         }
         if ( !small )
         {
            if ( has( "FWHM" ) )
            {
               let L = st.FWHM.median + 2.5*sig( "FWHM", st.FWHM );
               th.push( { metric: "FWHM", dir: "above", value: L, label: "FWHM > median + 2.5 sigma (" + this.fmt( L ) + ")" } );
            }
            if ( has( "PSFSignalWeight" ) )
            {
               let L = st.PSFSignalWeight.median - 2.5*sig( "PSFSignalWeight", st.PSFSignalWeight );
               th.push( { metric: "PSFSignalWeight", dir: "below", value: L, label: "PSFSignalWeight < median - 2.5 sigma (" + this.fmt( L ) + ")" } );
            }
            if ( has( "Median" ) )
            {
               let L = st.Median.median + 3*sig( "Median", st.Median );
               th.push( { metric: "Median", dir: "above", value: L, label: "Median > median + 3 sigma (" + this.fmt( L ) + ")" } );
            }
         }
         for ( let i of survivors )
            for ( let t of th )
            {
               let v = rows[ i ].m[ t.metric ];
               if ( !( typeof v == "number" && isFinite( v ) ) )
                  continue;
               let bad = t.dir == "above" ? v > t.value : v < t.value;
               if ( bad && t.metric == "Eccentricity" && v < 0.55 )
                  bad = false;      // hard floor: good tracking is never rejected for eccentricity
               if ( bad )
               {
                  rejected[ i ] = true;
                  reasons[ i ].push( t.label );
               }
            }
         return th;
      };

      let thresholds = pass( valid, stats0 );
      if ( !small )
      {
         let surv = valid.filter( i => !rejected[ i ] );
         if ( surv.length < valid.length && surv.length >= 5 )
            thresholds = pass( surv );       // pass 2: survivors only, never un-rejects
      }
      let nRej = valid.filter( i => rejected[ i ] ).length;
      if ( nRej > 0.4*n )
      {
         let keep = Math.ceil( 0.6*n );
         let sw = i => { let v = rows[ i ].m.PSFSignalWeight; return typeof v == "number" && isFinite( v ) ? v : -Infinity; };
         let fw = i => { let v = rows[ i ].m.FWHM; return typeof v == "number" && isFinite( v ) ? v : Infinity; };
         let cmp = ( a, b ) => { let d = sw( b ) - sw( a ); if ( d != 0 && !isNaN( d ) ) return d;
                                 d = fw( a ) - fw( b ); if ( d != 0 && !isNaN( d ) ) return d; return a - b; };
         let order = valid.slice().sort( cmp );
         let best = new Set( order.slice( 0, keep ) );
         for ( let i of valid )
            if ( best.has( i ) ) { rejected[ i ] = false; reasons[ i ] = []; }
            else { rejected[ i ] = true; reasons[ i ].push( "outside best 60% by PSFSignalWeight" ); }
         warnings.push( "Auto rule rejected more than 40%, kept best 60%" );
      }
      for ( let i of valid )
         approved[ i ] = !rejected[ i ];
      return { approved: approved, reasons: reasons.map( r => r.join( "; " ) ), warnings: warnings, thresholds: thresholds };
   },

   // Unified selection used by run() and the review dialog.
   // mode: "auto" | "rules" | "review". Review: the Auto rule when no table row is active.
   select: function( rows, mode, table, overrides, available )
   {
      let stats = this.computeStats( rows );
      let useAuto = mode == "auto" || ( mode == "review" && this.activeRules( table, available ).length == 0 );
      let out = { approved: [], reasons: [], manual: [], warnings: [], thresholds: [], stats: stats, usedAuto: useAuto };
      if ( useAuto )
      {
         let a = this.autoRule( rows, available, stats );
         out.approved = a.approved.slice();
         out.reasons = a.reasons.slice();
         out.warnings = a.warnings;
         out.thresholds = a.thresholds;
         out.manual = rows.map( () => false );
         if ( overrides )
            for ( let i = 0; i < rows.length; ++i )
               if ( !rows[ i ].failed && Object.prototype.hasOwnProperty.call( overrides, i ) )
               {
                  out.approved[ i ] = !!overrides[ i ];
                  out.manual[ i ] = true;
                  out.reasons[ i ] = out.approved[ i ] ? "" : ( out.reasons[ i ] || "manual" );
               }
      }
      else
      {
         let r = this.evalRules( rows, table, stats, overrides, available );
         out.approved = r.map( x => x.approved );
         out.reasons = r.map( x => x.reasons.join( "; " ) );
         out.manual = r.map( x => x.manual );
         out.thresholds = this.ruleThresholds( table, stats, available );
      }
      for ( let i = 0; i < rows.length; ++i )
         if ( rows[ i ].failed ) { out.approved[ i ] = false; out.manual[ i ] = false; }
      return out;
   },

   // --- Small helpers ---------------------------------------------------------
   csvEscape: function( v )
   {
      let s = v === undefined || v === null ? "" : ( typeof v == "number" ? ( isFinite( v ) ? String( v ) : "" ) : String( v ) );
      if ( /[",;\r\n]/.test( s ) || /^\s|\s$/.test( s ) )
         s = '"' + s.replace( /"/g, '""' ) + '"';
      return s;
   },

   // existsFn is optional (tests); default File.exists. Never overwrites: name_1, name_2 ...
   uniqueOutPath: function( dir, name, existsFn )
   {
      let ex = existsFn || ( p => File.exists( p ) );
      let d = String( dir ).replace( /[\/\\]+$/, "" );
      let dot = name.lastIndexOf( "." );
      let base = dot > 0 ? name.substring( 0, dot ) : name, ext = dot > 0 ? name.substring( dot ) : "";
      let p = d + "/" + name;
      for ( let k = 1; ex( p ); ++k )
         p = d + "/" + base + "_" + k + ext;
      return p;
   },

   groupBySize: function( infos )
   {
      let groups = [], map = Object.create( null );
      for ( let f of infos )
      {
         let key = f.width + "x" + f.height + "x" + ( f.channels || 1 ) + ":" + ( f.channelMode || "Off" ) + ":" + ( f.cfaMethod || "" );
         if ( !( key in map ) )
         {
            map[ key ] = groups.length;
            groups.push( { key: key, width: f.width, height: f.height, channels: f.channels || 1,
                           channelMode: f.channelMode || "Off", cfaMethod: f.cfaMethod || "", items: [] } );
         }
         groups[ map[ key ] ].items.push( f );
      }
      return groups;
   },

   batchesOf: function( list, n )
   {
      n = Math.max( 1, Math.round( n ) || 1 );
      let out = [];
      for ( let i = 0; i < list.length; i += n )
         out.push( list.slice( i, i + n ) );
      return out;
   },

   fmt: function( v )
   {
      if ( typeof v != "number" || !isFinite( v ) )
         return "-";
      let a = Math.abs( v );
      if ( a != 0 && ( a < 1e-3 || a >= 1e6 ) )
         return v.toExponential( 3 );
      return String( Number( v.toPrecision( 5 ) ) );
   },

   sig6: function( v )
   {
      return String( Number( v.toPrecision( 6 ) ) );
   },

   cameraResolution: function( bits )
   {
      let S = SubframeSelector;
      switch ( bits )
      {
      case 8: return S.Bits8;
      case 10: return S.Bits10;
      case 12: return S.Bits12;
      case 14: return S.Bits14;
      default: return S.Bits16;
      }
   },

   // Column table from SubframeSelector.measurements_* constants (missing -> hidden).
   columns: function()
   {
      let C = { path: SubframeSelector.measurements_filePath, metrics: [] };
      for ( let m of PSW_METRICS )
      {
         let c = SubframeSelector[ m.sfs ];
         if ( typeof c == "number" )
            C.metrics.push( { key: m.key, col: c } );
      }
      C.hasStars = C.metrics.some( c => c.key == "Stars" );
      return C;
   },

   availableMetrics: function()
   {
      return this.columns().metrics.map( c => c.key );
   },

   isSupportedFile: function( path )
   {
      return PSW_FILE_EXTS.indexOf( File.extractExtension( path ).toLowerCase() ) >= 0;
   },

   // Supported files of one folder (not recursive): lower- and upper-case extensions,
   // duplicates removed (case-insensitive file systems return a file for both patterns), sorted.
   searchFolder: function( dir )
   {
      dir = String( dir ).replace( /[\/\\]+$/, "" );
      let seen = Object.create( null ), list = [];
      for ( let e of PSW_FILE_EXTS )
         for ( let pat of [ e, e.toUpperCase() ] )
            for ( let p of File.searchDirectory( dir + "/*" + pat, false ) )
               if ( this.isSupportedFile( p ) && !( p in seen ) )
               {
                  seen[ p ] = true;
                  list.push( p );
               }
      list.sort();
      return list;
   },

   dirOf: function( path )
   {
      return File.extractDrive( path ) + File.extractDirectory( path );
   },

   // Case-insensitive on macOS and Windows (default file systems), exact on Linux.
   normPath: function( p )
   {
      let s = String( p ).replace( /\\/g, "/" ).replace( /\/+$/, "" );
      return PSW_CASE_INSENSITIVE_FS ? s.toLowerCase() : s;
   },

   samePath: function( a, b )
   {
      return this.normPath( a ) == this.normPath( b );
   },

   // ======================================================================
   // File I/O helpers (headers, CFA extraction, export)
   // ======================================================================

   // Header-only probe: dimensions + keywords, never loads pixels.
   probeFile: function( path )
   {
      if ( !File.exists( path ) )
         throw new Error( "file not found" );
      let ext = File.extractExtension( path ).toLowerCase();
      if ( PSW_FILE_EXTS.indexOf( ext ) < 0 )
         throw new Error( "unsupported file format '" + ext + "'" );
      let F = new FileFormat( ext, true, false );
      if ( F.isNull )
         throw new Error( "no installed format can read '" + ext + "'" );
      let f = new FileFormatInstance( F );
      if ( f.isNull )
         throw new Error( "unable to instantiate the file format" );
      let d = f.open( path, "verbosity 0 " + PSW_HINTS_IN );
      if ( !d || d.length < 1 )
         throw new Error( "unable to open the file" );
      let kws = [], props = {};
      try
      {
         if ( F.canStoreKeywords )
            kws = f.keywords.map( k => ( { name: k.name, value: k.strippedValue } ) );
         try
         {
            let cfa = f.colorFilterArray;
            if ( cfa && cfa[ 0 ] )
               props.ColorFilterArray = String( cfa[ 0 ] );
         }
         catch ( e ) {}
         if ( ext == ".xisf" )
            try
            {
               let v = f.readImageProperty( "PCL:CFASourcePattern" );
               if ( v ) props[ "PCL:CFASourcePattern" ] = String( v );
            }
            catch ( e ) {}
      }
      finally
      {
         f.close();
      }
      let h = this.parseHeader( kws, props );
      let d0 = d[ 0 ];
      h.width = d0.width;
      h.height = d0.height;
      h.channels = d0.numberOfChannels;
      if ( !h.bitpix )
         h.bitpix = d0.ieeefpSampleFormat ? 32 : d0.bitsPerSample;
      h.isFloat = !!d0.ieeefpSampleFormat;
      // The FITS reader flips BOTTOM-UP frames (use-roworder-keywords hint); XISF is never flipped.
      h.rowFlip = h.bottomUp && ext != ".xisf";
      h.path = path;
      return h;
   },

   // Reads the rows of an even-aligned ROI of a 1-channel frame in strips and calls
   // fn( a, n, stride, x0, yRel ) per strip: a = Float32Array holding n rows with row stride
   // 'stride', the ROI starting at column x0; yRel = first ROI row of the strip.
   // Only the ROI rows are read when the format reads incrementally (FITS, plain XISF);
   // otherwise the frame is read once and copied in blocks of <= 16 MB.
   // buf.a: reusable block buffer for the fallback path.
   readRoiStrips: function( info, roi, buf, fn )
   {
      let rw = roi.x1 - roi.x0;
      let W = info.width;
      let ext = File.extractExtension( info.path ).toLowerCase();
      let F = new FileFormat( ext, true, false );
      let f = new FileFormatInstance( F );
      let d = f.open( info.path, "verbosity 0 " + PSW_HINTS_IN );
      if ( !d || d.length < 1 )
         throw new Error( "unable to open the file" );
      let img = null;
      try
      {
         if ( f.canReadIncrementally )
         {
            // Row strips of the ROI only; strip height even, <= 16 MB as float32.
            let maxRows = Math.max( 2, Math.floor( 16*1024*1024/4/W ) );
            maxRows -= maxRows % 2;
            for ( let y = roi.y0; y < roi.y1; y += maxRows )
            {
               let n = Math.min( maxRows, roi.y1 - y );
               let M = f.read( y, n, 0 );
               if ( !M )
                  throw new Error( "unable to read rows " + y + "-" + ( y + n - 1 ) );
               fn( M.toFloat32Array(), n, W, roi.x0, y - roi.y0 );
               M = null;
            }
         }
         else
         {
            img = new Image( 1, 1, 1, ColorSpace.Gray, 32, PixelSampleType.Float );
            if ( !f.readImage( img ) )
               throw new Error( "unable to read the image" );
            let bh = Math.max( 2, Math.floor( 16*1024*1024/4/rw ) );
            bh -= bh % 2;
            if ( !buf.a || buf.a.length < rw*bh )
               buf.a = new Float32Array( rw*bh );
            for ( let y = roi.y0; y < roi.y1; y += bh )
            {
               let n = Math.min( bh, roi.y1 - y );
               let a = n*rw == buf.a.length ? buf.a : buf.a.subarray( 0, n*rw );
               img.getSamples( a, new Rect( roi.x0, y, roi.x1, y + n ), 0 );
               fn( a, n, rw, 0, y - roi.y0 );
            }
         }
      }
      finally
      {
         f.close();
         if ( img != null ) { img.free(); img = null; }
      }
   },

   // Writes a 1-channel 32-bit float XISF (no keywords) for SubframeSelector.
   writeTempXisf: function( tmpPath, image )
   {
      let G = new FileFormatInstance( new FileFormat( ".xisf", false, true ) );
      if ( !G.create( tmpPath, "no-warnings verbosity 0" ) )
         throw new Error( "unable to create temporary file " + tmpPath );
      try
      {
         let o = new ImageDescription;
         o.bitsPerSample = 32;
         o.ieeefpSampleFormat = true;
         G.setOptions( o );
         if ( !G.writeImage( image ) )
            throw new Error( "unable to write temporary file " + tmpPath );
      }
      finally
      {
         G.close();
      }
   },

   // Writes the superpixel image (half resolution, one pixel per 2x2 cell) of the centred
   // ROI of one CFA frame to tmpPath. buf.out: reusable output buffer (size change only).
   writeSuperpixel: function( info, pattern, channel, fraction, tmpPath, buf )
   {
      let roi = this.computeRoi( info.width, info.height, fraction, true );
      let rw = roi.x1 - roi.x0, rh = roi.y1 - roi.y0;
      if ( rw < 2 || rh < 2 )
         throw new Error( "frame too small for CFA extraction" );
      let effPat = this.effectivePattern( pattern, info.xBayOff, info.yBayOff, roi.x0, roi.y0,
                                          info.rowFlip ? info.height : 0 );
      let ow = rw >> 1, oh = rh >> 1;
      if ( !buf.out || buf.out.length != ow*oh )
         buf.out = new Float32Array( ow*oh );    // every element is rewritten below
      let out = buf.out;
      this.readRoiStrips( info, roi, buf, ( a, n, stride, x0, yRel ) =>
         this.extractSuperpixel( a, rw, n, effPat, channel, out, ( yRel >> 1 )*ow, stride, x0 ) );
      let sp = new Image( out, ow, oh );
      try
      {
         this.writeTempXisf( tmpPath, sp );
      }
      finally
      {
         sp.free();
         sp = null;
      }
      return { roi: roi, pattern: effPat };
   },

   // Full-resolution channel of the centred ROI of one CFA frame, debayered with the native
   // Debayer process (VNG or Bilinear), written to tmpPath. ctx holds the ONE hidden 1-channel
   // temp window, reused while the ROI size is unchanged (ctx.win, ctx.w, ctx.h), and the
   // reusable buffers (ctx.a, ctx.blk). Every window Debayer creates is closed in finally.
   writeDebayered: function( info, pattern, channel, method, fraction, tmpPath, ctx )
   {
      let roi = this.computeRoi( info.width, info.height, fraction, true );
      let rw = roi.x1 - roi.x0, rh = roi.y1 - roi.y0;
      if ( rw < 4 || rh < 4 )
         throw new Error( "frame too small for debayering" );
      let effPat = this.effectivePattern( pattern, info.xBayOff, info.yBayOff, roi.x0, roi.y0,
                                          info.rowFlip ? info.height : 0 );
      if ( typeof Debayer[ effPat ] != "number" || typeof Debayer[ method ] != "number" )
         throw new Error( "unsupported pattern/method " + effPat + "/" + method );
      if ( ctx.win && ( ctx.win.isNull || ctx.w != rw || ctx.h != rh ) )
         this.closeCfaWindow( ctx );
      if ( !ctx.win )
      {
         ctx.win = new ImageWindow( rw, rh, 1, 32, true, false, "SFS_cfa_tmp" );    // never shown
         ctx.w = rw;
         ctx.h = rh;
      }
      let view = ctx.win.mainView;
      view.beginProcess( UndoFlag.NoSwapFile );
      try
      {
         let img = view.image;
         this.readRoiStrips( info, roi, ctx, ( a, n, stride, x0, yRel ) =>
         {
            let blk;
            if ( stride == rw && x0 == 0 )
               blk = a.length == rw*n ? a : a.subarray( 0, rw*n );
            else
            {
               if ( !ctx.blk || ctx.blk.length < rw*n )
                  ctx.blk = new Float32Array( rw*n );
               blk = ctx.blk.length == rw*n ? ctx.blk : ctx.blk.subarray( 0, rw*n );
               for ( let j = 0, s = x0; j < n; ++j, s += stride )
                  blk.set( a.subarray( s, s + rw ), j*rw );
            }
            img.setSamples( blk, new Rect( 0, yRel, rw, yRel + n ), 0 );
         } );
      }
      finally
      {
         view.endProcess();
      }
      let before = Object.create( null );
      for ( let w of ImageWindow.windows )
         before[ w.mainView.id ] = true;
      try
      {
         let D = new Debayer;
         D.cfaPattern = Debayer[ effPat ];
         D.debayerMethod = Debayer[ method ];
         D.evaluateNoise = false;
         D.evaluateSignal = false;
         D.showImages = false;
         D.noGUIMessages = true;
         D.outputRGBImages = false;
         D.outputSeparateChannels = true;
         if ( !D.executeOn( view, false ) )
            throw new Error( "Debayer failed" );
         let id = channel == "R" ? D.outputChannelImageR : channel == "B" ? D.outputChannelImageB : D.outputChannelImageG;
         let w = ImageWindow.windowById( id );
         if ( !id || w.isNull )
            throw new Error( "Debayer produced no " + channel + " channel image" );
         this.writeTempXisf( tmpPath, w.mainView.image );
      }
      finally
      {
         for ( let w of ImageWindow.windows )
            if ( !( w.mainView.id in before ) )
               w.forceClose();
      }
      return { roi: roi, pattern: effPat };
   },

   closeCfaWindow: function( ctx )
   {
      if ( ctx && ctx.win )
      {
         try { if ( !ctx.win.isNull ) ctx.win.forceClose(); } catch ( e ) {}
         ctx.win = null;
         ctx.w = ctx.h = 0;
      }
   },

   makeSFS: function( params, opts )
   {
      let S = SubframeSelector;
      let P = new SubframeSelector;
      P.routine = S.MeasureSubframes;
      P.nonInteractive = true;
      P.fileCache = false;
      P.subframeScale = opts.scale;
      let gainKnown = params.cameraGain > 0;
      P.cameraGain = gainKnown ? params.cameraGain : 1.0;
      P.dataUnit = gainKnown ? S.Electron : S.DataNumber;
      P.cameraResolution = this.cameraResolution( params.bitDepth );
      P.siteLocalMidnight = 24;
      P.scaleUnit = S.ArcSeconds;
      P.trimmingFactor = 0.10;
      P.structureLayers = 5;
      P.noiseLayers = 0;
      P.sensitivity = 0.1;
      P.peakResponse = 0.8;
      P.maxDistortion = 0.5;
      P.upperLimit = 1.0;
      let pf = S[ params.psfFit ];
      P.psfFit = typeof pf == "number" ? pf : S.Moffat4;
      P.psfFitCircular = false;
      P.roiX0 = opts.roi.x0; P.roiY0 = opts.roi.y0;
      P.roiX1 = opts.roi.x1; P.roiY1 = opts.roi.y1;
      P.onError = S.Continue;
      P.approvalExpression = "";
      P.weightingExpression = "";
      P.outputDirectory = "";
      P.useFileThreads = true;
      return P;
   },

   // entries: [{ path, row }]. Measures them in one SFS call; retries a failed batch file by file.
   measureBatch: function( entries, params, opts, COL )
   {
      if ( entries.length == 0 )
         return;
      let P = this.makeSFS( params, opts );
      P.subframes = entries.map( e => [ true, e.path, "", "" ] );
      let ok = false;
      try
      {
         ok = P.executeGlobal();
      }
      catch ( e )
      {
         console.warningln( "** SubframeSelector: " + e );
      }
      let m = ok ? P.measurements : [];     // the table is read once
      P = null;
      let byPath = Object.create( null );
      for ( let r of m )
         byPath[ String( r[ COL.path ] ) ] = r;
      let missing = [];
      for ( let e of entries )
      {
         let r = byPath[ e.path ];
         if ( r === undefined )
            for ( let k in byPath )
               if ( this.samePath( k, e.path ) || k.toLowerCase() == e.path.toLowerCase() ) { r = byPath[ k ]; break; }
         if ( r === undefined )
         {
            missing.push( e );
            continue;
         }
         let mm = {};
         for ( let c of COL.metrics )
         {
            let v = r[ c.col ];
            mm[ c.key ] = typeof v == "number" ? v : parseFloat( v );
         }
         // FWHM px -> arcsec (finding 7); the pixel value is kept for the report.
         e.row.fwhmPx = mm.FWHM;
         if ( typeof mm.FWHM == "number" )
            mm.FWHM *= opts.scale;
         e.row.m = mm;
         e.row.measured = true;
         let noStars = COL.hasStars && !( mm.Stars > 0 );     // only when SFS reports a star count
         if ( !isFinite( mm.FWHM ) || noStars )
         {
            e.row.failed = true;
            e.row.failReason = noStars ? "no stars detected" : "invalid measurement (NaN)";
         }
      }
      if ( missing.length > 0 )
      {
         if ( entries.length > 1 )
            for ( let e of missing )
               this.measureBatch( [ e ], params, opts, COL );
         else
            for ( let e of missing )
            {
               e.row.failed = true;
               e.row.failReason = "SubframeSelector returned no measurement";
            }
      }
   },

   removeTree: function( dir )
   {
      if ( !dir || !File.directoryExists( dir ) )
         return;
      try
      {
         let names = [];
         let ff = new FileFind;
         if ( ff.begin( dir + "/*" ) )
         {
            do
            {
               if ( ff.name != "." && ff.name != ".." && !ff.isDirectory )
                  names.push( ff.name );
            }
            while ( ff.next() );
         }
         ff.end();
         for ( let n of names )
            try { File.remove( dir + "/" + n ); } catch ( e ) {}
         File.removeDirectory( dir );
      }
      catch ( e )
      {
         console.warningln( "** Unable to remove temporary folder " + dir + ": " + e );
      }
   },

   // Rewrites one original as XISF with measurement keywords and properties.
   exportWithMetadata: function( row, dst, meta )
   {
      let ext = File.extractExtension( row.path ).toLowerCase();
      let F = new FileFormat( ext, true, false );
      let f = new FileFormatInstance( F );
      let d = f.open( row.path, "verbosity 0 " + PSW_HINTS_IN );
      if ( !d || d.length < 1 )
         throw new Error( "unable to open the source" );
      let img = null, kws = [], props = [], cfa = null, icc = null, d0 = d[ 0 ];
      try
      {
         // Same sample format as the source: no conversion, half the RAM for 16-bit data.
         img = new Image( 1, 1, 1, ColorSpace.Gray, d0.bitsPerSample,
                          d0.ieeefpSampleFormat ? PixelSampleType.Float : PixelSampleType.Integer );
         if ( !f.readImage( img ) )
            throw new Error( "unable to read the source image" );
         if ( F.canStoreKeywords )
            kws = f.keywords;
         try
         {
            for ( let p of f.imageProperties )
               if ( String( p[ 0 ] ).indexOf( "SmartFrameSelection:" ) != 0 )
                  props.push( [ p[ 0 ], f.readImageProperty( p[ 0 ] ), p[ 1 ] ] );
         }
         catch ( e ) {}
         try { cfa = f.colorFilterArray; } catch ( e ) { cfa = null; }
         if ( F.canStoreICCProfiles )
            try { icc = f.iccProfile; } catch ( e ) { icc = null; }
      }
      catch ( e )
      {
         f.close();
         if ( img != null ) img.free();
         throw e;
      }
      f.close();
      let created = false;
      try
      {
         let skip = /^(SIMPLE|BITPIX|NAXIS\d*|EXTEND|BZERO|BSCALE|SFS_.*)$/;
         let out = [];
         for ( let k of kws )
            if ( !skip.test( String( k.name ).trim().toUpperCase() ) )
               out.push( k );
         for ( let m of PSW_METRICS )
         {
            let v = row.m ? row.m[ m.key ] : NaN;
            if ( typeof v == "number" && isFinite( v ) )
               out.push( new FITSKeyword( m.kw, this.sig6( v ), "SmartFrameSelection " + m.key ) );
         }
         out.push( new FITSKeyword( "SFS_ROI", "'" + meta.roi + "'", "SmartFrameSelection measured ROI" ) );
         out.push( new FITSKeyword( "SFS_MODE", "'" + meta.mode + "'", "SmartFrameSelection selection mode" ) );
         if ( meta.readNoise > 0 )
            out.push( new FITSKeyword( "SFS_RDNOISE", this.sig6( meta.readNoise ), "Read noise [e-] (metadata only)" ) );

         let G = new FileFormatInstance( new FileFormat( ".xisf", false, true ) );
         if ( !G.create( dst, "no-warnings verbosity 0" ) )
            throw new Error( "unable to create " + dst );
         created = true;
         try
         {
            G.setOptions( d0 );
            G.keywords = out;
            for ( let p of props )
               try { G.writeImageProperty( p[ 0 ], p[ 1 ], p[ 2 ] ); } catch ( e ) {}
            for ( let m of PSW_METRICS )
            {
               let v = row.m ? row.m[ m.key ] : NaN;
               if ( typeof v == "number" && isFinite( v ) )
                  G.writeImageProperty( "SmartFrameSelection:" + m.key, v,
                                        m.key == "Stars" ? PropertyType.Int32 : PropertyType.Float64 );
            }
            G.writeImageProperty( "SmartFrameSelection:ROI", meta.roi, PropertyType.String );
            G.writeImageProperty( "SmartFrameSelection:Mode", meta.mode, PropertyType.String );
            if ( meta.readNoise > 0 )
               G.writeImageProperty( "SmartFrameSelection:ReadNoise", meta.readNoise, PropertyType.Float64 );
            if ( cfa && cfa[ 0 ] )
               try { G.colorFilterArray = cfa; } catch ( e ) {}
            if ( icc && icc.length > 0 )
               G.iccProfile = icc;       // XISF stores ICC profiles
            if ( !G.writeImage( img ) )
               throw new Error( "unable to write " + dst );
         }
         finally
         {
            G.close();
         }
      }
      catch ( e )
      {
         if ( created && File.exists( dst ) )
            try { File.remove( dst ); } catch ( x ) {}
         throw e;
      }
      finally
      {
         img.free();
         img = null;
      }
   },

   // Returns "" when params are runnable, else an English error message.
   validate: function( params )
   {
      if ( !params.files || params.files.length == 0 )
         return "No input files.";
      if ( !params.outputDir || String( params.outputDir ).trim().length == 0 )
         return "No output folder.";
      if ( !( params.subframeScale > 0 ) )
         return "The image scale must be greater than zero.";
      if ( params.mode == "rules" || params.mode == "review" )
      {
         let e = this.validateRuleTable( params.ruleTable, params.mode == "rules" );
         if ( e )
            return e;
      }
      let out = String( params.outputDir ).replace( /[\/\\]+$/, "" );
      for ( let p of params.files )
         if ( this.samePath( this.dirOf( p ), out ) )
            return "The output folder must not be the folder of an input file.";
      let tmp = File.systemTempDirectory.replace( /[\/\\]+$/, "" );
      if ( this.samePath( out, tmp ) || this.normPath( out ).indexOf( this.normPath( tmp ) + "/" ) == 0 )
         return "The output folder must not be inside the temporary folder.";
      return "";
   },

   // ======================================================================
   // Pipeline
   // ======================================================================
   lastRows: null,
   lastSelection: null,
   lastTempDir: "",
   lastReportPath: "",
   lastTimings: null,

   run: function( view, params )
   {
      // view is ignored: the script is batch/file based.
      let t0 = Date.now();
      let res = { nInput: 0, nMeasured: 0, nFailed: 0, nApproved: 0, nRejected: 0, nExported: 0, seconds: 0 };
      this.lastRows = null;
      this.lastSelection = null;
      this.lastTempDir = "";
      this.lastReportPath = "";
      this.lastTimings = { prepMs: [], sfsMs: [] };
      if ( typeof params.clamp == "function" )
         params.clamp();

      let err = this.validate( params );
      if ( err )
         throw new Error( err );
      let outDir = String( params.outputDir ).replace( /[\/\\]+$/, "" );
      if ( !File.directoryExists( outDir ) )
         File.createDirectory( outDir, true );
      let probe = outDir + "/.sfs_write_test_" + Date.now();
      try
      {
         File.writeTextFile( probe, "x" );
         File.remove( probe );
      }
      catch ( e )
      {
         throw new Error( "The output folder is not writable: " + outDir );
      }

      let COL = this.columns();
      let available = COL.metrics.map( c => c.key );
      let modeTag = params.mode == "rules" ? "RULES" : params.mode == "review" ? "REVIEW" : "AUTO";
      let fraction = params.roiFraction/100;
      res.nInput = params.files.length;
      console.abortEnabled = true;

      if ( !( params.cameraGain > 0 ) )
         console.warningln( "** Camera gain unknown: SFS values are in data numbers." );
      if ( !( params.readNoise > 0 ) )
         console.warningln( "** Read noise unknown (metadata only; SubframeSelector has no read-noise parameter)." );

      // 1-2. Header probe (no pixels).
      let rows = params.files.map( ( p, i ) => ( { index: i + 1, path: p, name: File.extractNameAndExtension( p ),
                                                   width: 0, height: 0, failed: false, failReason: "",
                                                   measured: false, m: {}, channelMode: "Off", cfaMethod: "", pattern: "" } ) );
      let ok = [];
      for ( let r of rows )
      {
         try
         {
            let info = this.probeFile( r.path );
            r.width = info.width;
            r.height = info.height;
            let pat = params.bayerOverride != "Auto" ? params.bayerOverride : info.bayerPat;
            let handling = params.cfaHandling == "Auto" ? ( info.cfa ? "Debayer" : "Off" ) : params.cfaHandling;
            let wanted = handling == "Off" ? "Off" : ( PSW_CFA_CHANNELS.indexOf( params.cfaChannel ) >= 0 ? params.cfaChannel : "G" );
            if ( wanted != "Off" )
            {
               if ( !pat || PSW_CFA_PATTERNS.indexOf( pat ) < 0 )
               {
                  console.warningln( "** " + r.name + ": not a CFA frame, measured normally." );
                  wanted = "Off";
               }
               else if ( info.channels != 1 )
               {
                  console.warningln( "** " + r.name + ": " + info.channels + " channels; CFA mode needs a mono mosaic, measured normally." );
                  wanted = "Off";
               }
            }
            let method = wanted == "Off" ? "" : ( PSW_DEBAYER_METHODS.indexOf( params.debayerMethod ) >= 0 ? params.debayerMethod : "VNG" );
            r.channelMode = wanted;
            r.cfaMethod = method;
            r.pattern = pat;
            info.channelMode = wanted;
            info.cfaMethod = method;
            info.row = r;
            ok.push( info );
         }
         catch ( e )
         {
            r.failed = true;
            r.failReason = String( e.message || e );
            console.warningln( "** " + r.name + ": " + r.failReason );
         }
      }

      // 3-4. Measure, per size group, in batches.
      let groups = this.groupBySize( ok );
      let needTemp = ok.some( i => i.channelMode != "Off" );
      // Reusable CFA buffers and the ONE hidden Debayer source window (closed in finally).
      let buf = { a: null, out: null, blk: null, win: null, w: 0, h: 0 };
      let tmpDir = "";
      let aborted = false;
      let nBatches = 0, totalBatches = 0;
      for ( let g of groups )
         totalBatches += Math.ceil( g.items.length/params.batchSize );
      try
      {
         if ( needTemp )
         {
            tmpDir = File.systemTempDirectory.replace( /[\/\\]+$/, "" ) + "/SFS_" + Date.now();
            File.createDirectory( tmpDir, true );
            this.lastTempDir = tmpDir;
         }
         for ( let g of groups )
         {
            let cfa = g.channelMode != "Off";
            let superpixel = cfa && g.cfaMethod == "SuperPixel";
            let opts = {
               // Superpixel files have half the resolution: the scale doubles. Debayered
               // files keep the full resolution of the ROI.
               scale: superpixel ? 2*params.subframeScale : params.subframeScale,
               roi: cfa ? { x0: 0, y0: 0, x1: 0, y1: 0 } : this.computeRoi( g.width, g.height, fraction, false )
            };
            for ( let batch of this.batchesOf( g.items, params.batchSize ) )
            {
               if ( console.abortRequested ) { aborted = true; break; }
               let entries = [], temps = [];
               for ( let info of batch )
               {
                  let row = info.row;
                  if ( !cfa )
                  {
                     entries.push( { path: row.path, row: row } );
                     continue;
                  }
                  let tmp = tmpDir + "/cfa_" + row.index + ".xisf";
                  try
                  {
                     let tp = Date.now();
                     if ( superpixel )
                        this.writeSuperpixel( info, row.pattern, g.channelMode, fraction, tmp, buf );
                     else
                        this.writeDebayered( info, row.pattern, g.channelMode, g.cfaMethod, fraction, tmp, buf );
                     this.lastTimings.prepMs.push( Date.now() - tp );
                     temps.push( tmp );
                     entries.push( { path: tmp, row: row } );
                  }
                  catch ( e )
                  {
                     row.failed = true;
                     row.failReason = "CFA extraction failed: " + ( e.message || e );
                     console.warningln( "** " + row.name + ": " + row.failReason );
                     if ( File.exists( tmp ) )
                        try { File.remove( tmp ); } catch ( x ) {}
                  }
                  gc();
                  if ( console.abortRequested ) { aborted = true; break; }
               }
               if ( !aborted )
               {
                  let ts = Date.now();
                  this.measureBatch( entries, params, opts, COL );
                  this.lastTimings.sfsMs.push( Date.now() - ts );
               }
               for ( let t of temps )
                  try { if ( File.exists( t ) ) File.remove( t ); } catch ( e ) {}
               ++nBatches;
               console.noteln( "<end><cbr>Smart Frame Selection: batch " + nBatches + "/" + totalBatches + " (" +
                               batch.length + " frame" + ( batch.length == 1 ? "" : "s" ) +
                               ( cfa ? ", CFA " + g.channelMode + " " + ( superpixel ? "superpixel" : g.cfaMethod ) : "" ) + ")" );
               processEvents();
               gc();
               if ( aborted || console.abortRequested ) { aborted = true; break; }
            }
            if ( aborted )
               break;
         }
      }
      finally
      {
         this.closeCfaWindow( buf );
         buf.a = buf.out = buf.blk = null;
         if ( tmpDir )
            this.removeTree( tmpDir );
      }

      for ( let r of rows )
         if ( !r.failed && !r.measured )
         {
            r.failed = true;
            r.failReason = aborted ? "not measured" : "SubframeSelector returned no measurement";
         }
      res.nMeasured = rows.filter( r => r.measured && !r.failed ).length;
      res.nFailed = rows.filter( r => r.failed ).length;
      this.lastRows = rows;

      if ( aborted )
      {
         console.warningln( "** Aborted: nothing exported, no report written." );
         res.seconds = ( Date.now() - t0 )/1000;
         return res;
      }

      // 5. Selection.
      let overrides = null;
      if ( params.mode == "review" && typeof params.reviewCallback == "function" && res.nMeasured > 0 )
      {
         overrides = params.reviewCallback( rows, { available: available } );
         if ( overrides === null )
         {
            console.warningln( "** Review cancelled: nothing exported, no report written." );
            res.seconds = ( Date.now() - t0 )/1000;
            return res;
         }
      }
      // The review dialog may have edited params.ruleTable.
      let sel = this.select( rows, params.mode, params.ruleTable, overrides, available );
      this.lastSelection = sel;
      for ( let w of sel.warnings )
         console.warningln( "** " + w );
      res.nApproved = sel.approved.filter( a => a ).length;
      res.nRejected = rows.length - res.nApproved - res.nFailed;

      // 6. Export (originals are only read, never modified).
      let meta = { roi: params.roiFraction + "%", mode: modeTag, readNoise: params.readNoise };
      if ( res.nMeasured == 0 )
         console.criticalln( "*** No frame could be measured: nothing exported." );
      else
      {
         let rejDir = outDir + "/rejected";
         for ( let i = 0; i < rows.length; ++i )
         {
            let r = rows[ i ];
            if ( r.failed )
               continue;
            if ( !sel.approved[ i ] )
            {
               if ( params.copyRejected )
               {
                  if ( !File.directoryExists( rejDir ) )
                     File.createDirectory( rejDir, true );
                  File.copyFile( this.uniqueOutPath( rejDir, r.name ), r.path );
               }
               continue;
            }
            let byteCopy = params.copyUnchanged || r.channelMode != "Off";
            if ( !byteCopy )
            {
               let dst = this.uniqueOutPath( outDir, File.extractName( r.path ) + ".xisf" );
               try
               {
                  this.exportWithMetadata( r, dst, meta );
                  r.outPath = dst;
               }
               catch ( e )
               {
                  console.warningln( "** " + r.name + ": metadata export failed (" + ( e.message || e ) + "), copied unchanged." );
                  byteCopy = true;
               }
               gc();
            }
            if ( byteCopy )
            {
               let dst = this.uniqueOutPath( outDir, r.name );
               File.copyFile( dst, r.path );
               r.outPath = dst;
            }
            ++res.nExported;
            console.writeln( "Exported " + File.extractNameAndExtension( r.outPath ) );
         }
      }

      // CSV report (always, also when nothing is approved).
      this.lastReportPath = this.writeReport( outDir, rows, sel, modeTag, params, available );
      console.writeln( "Report: " + this.lastReportPath );
      res.seconds = ( Date.now() - t0 )/1000;
      return res;
   },

   writeReport: function( outDir, rows, sel, modeTag, params, available )
   {
      let keys = PSW_METRICS.map( m => m.key ).filter( k => available.indexOf( k ) >= 0 );
      let E = v => this.csvEscape( v );
      let lines = [ [ "index", "file", "width", "height", "status", "reason", "mode" ].concat( keys )
                    .concat( [ "FWHM_px", "channel", "roi", "scale", "gain", "readNoise" ] ).map( E ).join( "," ) ];
      for ( let i = 0; i < rows.length; ++i )
      {
         let r = rows[ i ];
         let status = r.failed ? "failed" : sel.approved[ i ] ? "approved" : "rejected";
         let reason = r.failed ? r.failReason :
                      ( sel.reasons[ i ] || "" ) + ( sel.manual[ i ] ? ( sel.reasons[ i ] ? "; " : "" ) + "manual" : "" );
         let f = [ r.index, r.path, r.width, r.height, status, reason, modeTag ];
         for ( let k of keys )
            f.push( r.m && typeof r.m[ k ] == "number" && isFinite( r.m[ k ] ) ? r.m[ k ] : "" );
         f.push( typeof r.fwhmPx == "number" && isFinite( r.fwhmPx ) ? r.fwhmPx : "" );
         f.push( r.channelMode + ( r.cfaMethod ? " " + r.cfaMethod : "" ), params.roiFraction + "%", params.subframeScale,
                 params.cameraGain > 0 ? params.cameraGain : "", params.readNoise > 0 ? params.readNoise : "" );
         lines.push( f.map( E ).join( "," ) );
      }
      let p = this.uniqueOutPath( outDir, "SFS_report.csv" );
      File.writeTextFile( p, lines.join( "\n" ) + "\n" );
      return p;
   }
};
