// FlatStrengthCalibration_v1GUI.js - dialogs only. They edit PSWParameters and call
// PSWEngine; they never process pixels themselves.
// V8 engine style: ES6 class extends Dialog, enums as Namespace.Value (FrameStyle.Box ...).
//
// PSWDialog         main dialog (sessions, output, advanced options, Calibrate)
// PSWPreviewDialog  "Flat Strength" preview. It is a MODAL child dialog launched from
//                   the main dialog: its Apply buttons write strengths straight into
//                   params, and the main dialog refreshes its lists when it closes.

var PSW_FILE_FILTERS = [ [ "XISF and FITS files", "*.xisf", "*.fit", "*.fits", "*.fts" ], [ "All files", "*" ] ];

function pswFormatStrength( s )
{
   return ( s >= 0 ? "+" : "" ) + s.toFixed( 2 );
}

function pswMessage( text, icon )
{
   ( new MessageBox( text, PSW_TITLE, icon === undefined ? StdIcon.Information : icon, StdButton.Ok ) ).execute();
}

// ----------------------------------------------------------------------------
// Preview dialog
// ----------------------------------------------------------------------------

var PSWPreviewDialog = class extends Dialog
{
   // ctx: prepared preview context (PSWEngine.preparePreview), owned by this dialog from now on.
   constructor( params, sessionIndex, ctx, selectedIndices, parent )
   {
      super( parent );
      let self = this;
      this.params = params;
      this.si = sessionIndex;
      this.session = params.sessions[ sessionIndex ];
      this.ctx = ctx;
      this.selected = selectedIndices || [];
      this.bitmap = null;
      this.beforeCache = {};     // "deb" / "mos" -> { bmp, st }
      this.busy = false;
      this.pending = false;
      this.lastRenderMs = 0;

      let li = ctx.lightIndex || 0;
      this.s = PSWEngine.effectiveStrength( this.session.lights[ li ], this.session );

      // Header
      this.headerLabel = new Label( this );
      this.headerLabel.useRichText = true;
      this.headerLabel.wordWrapping = true;

      this.lightCombo = new ComboBox( this );
      this.session.lights.forEach( l => this.lightCombo.addItem( File.extractNameAndExtension( l.path ) ) );
      this.lightCombo.currentItem = li;
      this.lightCombo.toolTip = "<p>Light frame shown in the preview.</p>";
      this.lightCombo.onItemSelected = function( index ) { self.switchLight( index ); };

      this.lightSizer = new HorizontalSizer;
      this.lightSizer.spacing = 6;
      let ll = new Label( this );
      ll.text = "Light:";
      ll.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.lightSizer.add( ll );
      this.lightSizer.add( this.lightCombo, 100 );

      // Preview area
      this.previewControl = new Control( this );
      this.previewControl.setScaledMinSize( 820, 560 );
      this.previewControl.toolTip = "<p>Auto-stretched preview (display only).</p>";
      this.previewControl.onPaint = function( x0, y0, x1, y1 )
      {
         let g = new Graphics( this );
         try
         {
            g.fillRect( 0, 0, this.width, this.height, new Brush( 0xff181818 ) );
            let bmp = self.bitmap;
            if ( bmp )
            {
               let sc = Math.min( this.width/bmp.width, this.height/bmp.height );
               let w = Math.max( 1, Math.round( bmp.width*sc ) ), h = Math.max( 1, Math.round( bmp.height*sc ) );
               let ox = Math.round( ( this.width - w )/2 ), oy = Math.round( ( this.height - h )/2 );
               g.drawScaledBitmap( new Rect( ox, oy, ox + w, oy + h ), bmp );
            }
            else
            {
               g.pen = new Pen( 0xffc0c0c0 );
               g.drawTextRect( 0, 0, this.width, this.height, "Rendering...", TextAlignment.Center );
            }
         }
         finally
         {
            g.end();
         }
      };

      this.statusLabel = new Label( this );
      this.statusLabel.text = "";

      // Strength
      this.strengthControl = new NumericControl( this );
      this.strengthControl.label.text = "Flat strength:";
      this.strengthControl.setRange( -1, 1 );
      this.strengthControl.slider.setRange( -100, 100 );
      this.strengthControl.slider.scaledMinWidth = 300;
      this.strengthControl.setPrecision( 2 );
      this.strengthControl.setValue( this.s );
      this.strengthControl.toolTip = "<p>Flat correction strength. 0 = standard calibration, -1 = no flat, " +
                                     "+1 = flat applied twice (exponent k = 1 + s).</p>";
      this.strengthControl.onValueUpdated = function( value )
      {
         self.s = PSWEngine.normStrength( value );
         self.updateK();
         self.scheduleRender();
      };

      this.kLabel = new Label( this );
      this.kLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

      this.resetButton = new PushButton( this );
      this.resetButton.text = "Reset to 0";
      this.resetButton.toolTip = "<p>Back to the standard calibration (strength 0).</p>";
      this.resetButton.onClick = function()
      {
         self.strengthControl.setValue( 0 );
         self.s = 0;
         self.updateK();
         self.scheduleRender();
      };

      this.strengthSizer = new HorizontalSizer;
      this.strengthSizer.spacing = 8;
      this.strengthSizer.add( this.strengthControl, 100 );
      this.strengthSizer.add( this.kLabel );
      this.strengthSizer.add( this.resetButton );

      // View options
      this.beforeRadio = new RadioButton( this );
      this.beforeRadio.text = "Before";
      this.beforeRadio.toolTip = "<p>Raw light frame (no dark, no flat).</p>";
      this.beforeRadio.onCheck = function( checked ) { if ( checked ) self.scheduleRender( true ); };
      this.afterRadio = new RadioButton( this );
      this.afterRadio.text = "After";
      this.afterRadio.checked = true;
      this.afterRadio.toolTip = "<p>Calibrated light frame at the current strength.</p>";
      this.afterRadio.onCheck = function( checked ) { if ( checked ) self.scheduleRender( true ); };

      this.debayerCheck = new CheckBox( this );
      this.debayerCheck.text = "Debayer preview (CFA, preview only)";
      this.debayerCheck.checked = ctx.isCFA;
      this.debayerCheck.enabled = ctx.isCFA;
      this.debayerCheck.toolTip = "<p>Show a SuperPixel-debayered colour preview. Off: the calibrated mosaic " +
                                  "is shown in gray. The calibrated files always stay CFA.</p>";
      this.debayerCheck.onCheck = function() { self.bitmap = null; self.scheduleRender( true ); };

      this.lockCheck = new CheckBox( this );
      this.lockCheck.text = "Lock stretch to Before";
      this.lockCheck.toolTip = "<p>Use the Before image's stretch for the After image, so the real brightness " +
                               "change is visible.</p>";
      this.lockCheck.onCheck = function() { self.scheduleRender( true ); };

      this.viewSizer = new HorizontalSizer;
      this.viewSizer.spacing = 12;
      this.viewSizer.add( this.beforeRadio );
      this.viewSizer.add( this.afterRadio );
      this.viewSizer.addSpacing( 16 );
      this.viewSizer.add( this.debayerCheck );
      this.viewSizer.add( this.lockCheck );
      this.viewSizer.addSpacing( 16 );
      let msLabel = new Label( this );
      msLabel.text = "Preview size:";
      msLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.maxSizeSpin = new SpinBox( this );
      this.maxSizeSpin.minValue = 400;
      this.maxSizeSpin.maxValue = 4000;
      this.maxSizeSpin.stepSize = 100;
      this.maxSizeSpin.value = params.previewMaxSize;
      this.maxSizeSpin.toolTip = "<p>Longest side of the preview, in pixels.</p>";
      this.maxSizeSpin.onValueUpdated = function( v )
      {
         self.params.previewMaxSize = v;
         self.beforeCache = {};
         self.scheduleRender();
      };
      this.viewSizer.add( msLabel );
      this.viewSizer.add( this.maxSizeSpin );
      this.viewSizer.addStretch();

      // Apply
      this.applyFrameButton = new PushButton( this );
      this.applyFrameButton.text = "Apply to this frame";
      this.applyFrameButton.toolTip = "<p>Store the strength as an override for the frame shown.</p>";
      this.applyFrameButton.onClick = function()
      {
         self.session.lights[ self.ctx.lightIndex ].strength = self.s;
         self.feedback( "Strength " + pswFormatStrength( self.s ) + " set for " + self.lightCombo.itemText( self.ctx.lightIndex ) + "." );
      };

      this.applySelectedButton = new PushButton( this );
      this.applySelectedButton.text = "Apply to selected frames";
      this.applySelectedButton.enabled = this.selected.length > 0;
      this.applySelectedButton.toolTip = "<p>Store the strength as an override for all lights selected in the main " +
                                         "dialog (" + this.selected.length + ").</p>";
      this.applySelectedButton.onClick = function()
      {
         self.selected.forEach( i => { self.session.lights[ i ].strength = self.s; } );
         self.feedback( "Strength " + pswFormatStrength( self.s ) + " set for " + self.selected.length + " selected frame(s)." );
      };

      this.applySessionButton = new PushButton( this );
      this.applySessionButton.text = "Apply to whole session";
      this.applySessionButton.toolTip = "<p>Set the session strength. Frame overrides stay unless " +
                                        "'Also clear frame overrides' is checked.</p>";
      this.applySessionButton.onClick = function()
      {
         self.session.strength = self.s;
         if ( self.clearOverridesCheck.checked )
            self.session.lights.forEach( l => { l.strength = null; } );
         self.feedback( "Session strength set to " + pswFormatStrength( self.s ) +
                        ( self.clearOverridesCheck.checked ? "; frame overrides cleared." : "." ) );
      };

      this.clearOverridesCheck = new CheckBox( this );
      this.clearOverridesCheck.text = "Also clear frame overrides";
      this.clearOverridesCheck.checked = false;

      this.clearFrameButton = new PushButton( this );
      this.clearFrameButton.text = "Clear frame override";
      this.clearFrameButton.toolTip = "<p>The frame shown goes back to the session strength.</p>";
      this.clearFrameButton.onClick = function()
      {
         self.session.lights[ self.ctx.lightIndex ].strength = null;
         self.feedback( "Override cleared for " + self.lightCombo.itemText( self.ctx.lightIndex ) + "." );
      };

      this.closeButton = new PushButton( this );
      this.closeButton.text = "Close";
      this.closeButton.icon = this.scaledResource( ":/icons/close.png" );
      this.closeButton.onClick = function() { self.ok(); };

      this.applySizer = new HorizontalSizer;
      this.applySizer.spacing = 6;
      this.applySizer.add( this.applyFrameButton );
      this.applySizer.add( this.applySelectedButton );
      this.applySizer.add( this.applySessionButton );
      this.applySizer.add( this.clearOverridesCheck );
      this.applySizer.add( this.clearFrameButton );
      this.applySizer.addStretch();
      this.applySizer.add( this.closeButton );

      this.feedbackLabel = new Label( this );
      this.feedbackLabel.text = " ";

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 6;
      this.sizer.add( this.headerLabel );
      this.sizer.add( this.lightSizer );
      this.sizer.add( this.previewControl, 100 );
      this.sizer.add( this.statusLabel );
      this.sizer.add( this.strengthSizer );
      this.sizer.add( this.viewSizer );
      this.sizer.add( this.applySizer );
      this.sizer.add( this.feedbackLabel );

      this.windowTitle = "Flat Strength";
      this.updateHeader();
      this.updateK();
      this.adjustToContents();

      this.timer = new Timer;
      this.timer.interval = 0.15;
      this.timer.periodic = false;
      this.timer.onTimeout = function() { self.renderNow(); };

      this.onShow = function() { self.scheduleRender( true ); };
      this.onHide = function() { self.timer.stop(); };
   }

   updateHeader()
   {
      let name = File.extractNameAndExtension( this.ctx.lightPath );
      this.headerLabel.text = "<b>Session:</b> " + this.session.name + " &nbsp; <b>File:</b> " + name +
                              ( this.ctx.isCFA ? " &nbsp; (CFA " + this.ctx.pattern + ")" : " &nbsp; (mono)" ) +
                              ( this.ctx.flatPath ? "" : " &nbsp; <b>No master flat: only strength -1 is shown.</b>" );
   }

   updateK()
   {
      this.kLabel.text = "k = " + ( 1 + this.s ).toFixed( 2 );
   }

   feedback( text )
   {
      this.feedbackLabel.text = text;
   }

   scheduleRender( now )
   {
      this.timer.stop();
      if ( now )
         this.timer.interval = 0.01;
      else
         this.timer.interval = 0.15;
      this.timer.start();
   }

   switchLight( index )
   {
      if ( this.busy || index == this.ctx.lightIndex )
      {
         this.lightCombo.currentItem = this.ctx.lightIndex;
         return;
      }
      this.busy = true;
      this.cursor = new Cursor( StdCursor.Hourglass );
      try
      {
         // Same session: keep master flat, Fmax, reduced dark/flat and F_k means.
         PSWEngine.switchPreviewLight( this.ctx, this.session.lights[ index ].path, index );
         this.beforeCache = {};
         this.bitmap = null;
         this.updateHeader();
      }
      catch ( e )
      {
         this.lightCombo.currentItem = this.ctx.lightIndex;
         pswMessage( "Cannot switch the preview:\n" + ( e.message || e ), StdIcon.Error );
      }
      finally
      {
         this.cursor = new Cursor( StdCursor.Arrow );
         this.busy = false;
      }
      this.scheduleRender( true );
   }

   // Before image (cached per debayer mode): { bmp, st }. The engine's cached
   // Before window is stretched directly (no copy) and is not closed here.
   getBefore( debayer, maxSize )
   {
      let key = debayer ? "deb" : "mos";
      if ( this.beforeCache[ key ] && this.beforeCache[ key ].maxSize == maxSize )
         return this.beforeCache[ key ];
      let w = PSWEngine.previewBeforeWindow( this.ctx, { debayer: debayer, maxSize: maxSize } );
      let st = PSWEngine.computeStretch( w );
      let bmp = PSWEngine.stretchedBitmap( this.ctx, w, st );
      this.beforeCache[ key ] = { bmp: bmp, st: st, w: w.mainView.image.width, h: w.mainView.image.height, maxSize: maxSize };
      return this.beforeCache[ key ];
   }

   renderNow()
   {
      if ( this.busy )
      {
         this.pending = true;
         return;
      }
      this.busy = true;
      this.pending = false;
      let t0 = Date.now();
      let debayer = this.debayerCheck.checked;
      let maxSize = this.params.previewMaxSize;
      try
      {
         let size = "";
         if ( this.beforeRadio.checked )
         {
            let b = this.getBefore( debayer, maxSize );
            this.bitmap = b.bmp;
            size = b.w + "x" + b.h;
         }
         else
         {
            let w = PSWEngine.renderPreview( this.ctx, this.s, { debayer: debayer, maxSize: maxSize } );
            try
            {
               let st = this.lockCheck.checked ? this.getBefore( debayer, maxSize ).st : PSWEngine.computeStretch( w );
               this.bitmap = PSWEngine.stretchedBitmap( this.ctx, w, st );
               size = w.mainView.image.width + "x" + w.mainView.image.height;
            }
            finally
            {
               w.forceClose();
            }
         }
         this.lastRenderMs = Date.now() - t0;
         this.statusLabel.text = "Preview " + size + ", reduction 1:" + PSWEngine.previewFactor( this.ctx, debayer ) +
                                 ( this.ctx.isCFA ? ( debayer ? ", SuperPixel debayer" : ", gray mosaic" ) : "" ) +
                                 ", " + ( this.beforeRadio.checked ? "Before" : "After, strength " + pswFormatStrength( this.s ) ) +
                                 ", " + this.lastRenderMs + " ms";
      }
      catch ( e )
      {
         this.statusLabel.text = "Preview error: " + ( e.message || e );
         console.criticalln( "*** Preview error: " + ( e.message || e ) );
      }
      finally
      {
         this.busy = false;
      }
      this.previewControl.update();
      if ( this.pending )
         this.scheduleRender();
   }
};

// ----------------------------------------------------------------------------
// Main dialog
// ----------------------------------------------------------------------------

var PSWDialog = class extends Dialog
{
   constructor( params, parent )
   {
      super( parent );
      PSWParameters.defaults( params );
      this.params = params;
      let self = this;
      this.updating = false;

      let labelWidth = this.font.width( "Master dark flat:" ) + this.font.width( 'M' );

      this.helpLabel = new Label( this );
      this.helpLabel.frameStyle = FrameStyle.Box;
      this.helpLabel.margin = 6;
      this.helpLabel.wordWrapping = true;
      this.helpLabel.useRichText = true;
      this.helpLabel.text = "<p><b>" + PSW_TITLE + "</b> &mdash; Calibrate lights with per-session master dark and flats. " +
                            "Flat strength 0 = standard calibration.</p>";

      // ---------------------------------------------------------- sessions list
      this.sessionTree = new TreeBox( this );
      this.sessionTree.numberOfColumns = 1;
      this.sessionTree.headerVisible = false;
      this.sessionTree.rootDecoration = false;
      this.sessionTree.alternateRowColor = true;
      this.sessionTree.setScaledMinSize( 170, 200 );
      this.sessionTree.toolTip = "<p>Calibration sessions: each has lights, flats, master dark and master dark flat.</p>";
      this.sessionTree.onCurrentNodeUpdated = function() { if ( !self.updating ) self.updateSessionPanel(); };

      this.addSessionButton = new PushButton( this );
      this.addSessionButton.text = "Add session";
      this.addSessionButton.onClick = function()
      {
         let n = self.params.sessions.length;
         let s = PSWParameters.newSession( n );
         let names = self.params.sessions.map( x => PSWEngine.safeName( x.name ).toLowerCase() );
         let i = n + 1;
         while ( names.indexOf( PSWEngine.safeName( s.name ).toLowerCase() ) >= 0 )
            s.name = "Session " + ( ++i );
         self.params.sessions.push( s );
         self.refreshSessions( n );
      };

      this.removeSessionButton = new PushButton( this );
      this.removeSessionButton.text = "Remove session";
      this.removeSessionButton.onClick = function()
      {
         let i = self.currentSessionIndex();
         if ( i < 0 )
            return;
         self.params.sessions.splice( i, 1 );
         self.refreshSessions( Math.min( i, self.params.sessions.length - 1 ) );
      };

      this.renameButton = new PushButton( this );
      this.renameButton.text = "Rename";
      this.renameButton.toolTip = "<p>Rename the selected session using the Name field.</p>";
      this.renameButton.onClick = function() { self.applyName(); };

      this.sessionButtons = new VerticalSizer;
      this.sessionButtons.spacing = 4;
      this.sessionButtons.add( this.addSessionButton );
      this.sessionButtons.add( this.removeSessionButton );
      this.sessionButtons.add( this.renameButton );

      this.leftSizer = new VerticalSizer;
      this.leftSizer.spacing = 6;
      this.leftSizer.add( this.sessionTree, 100 );
      this.leftSizer.add( this.sessionButtons );

      // ---------------------------------------------------------- session panel
      this.panel = new Control( this );

      this.nameEdit = new Edit( this.panel );
      this.nameEdit.toolTip = "<p>Session name; used in output folder and master flat file names.</p>";
      this.nameEdit.onEditCompleted = function() { self.applyName(); };
      this.nameSizer = this.labeledRow( this.panel, "Name:", labelWidth, this.nameEdit );

      // Lights
      this.lightsTree = new TreeBox( this.panel );
      this.lightsTree.numberOfColumns = 2;
      this.lightsTree.headerVisible = true;
      this.lightsTree.setHeaderText( 0, "File" );
      this.lightsTree.setHeaderText( 1, "Strength" );
      this.lightsTree.setHeaderAlignment( 1, TextAlignment.Center );
      this.lightsTree.rootDecoration = false;
      this.lightsTree.alternateRowColor = true;
      this.lightsTree.multipleSelection = true;
      this.lightsTree.setScaledMinSize( 460, 170 );
      this.lightsTree.toolTip = "<p>Light frames. Strength '-' means the session value; other values are frame overrides.</p>";

      this.addLightsButton = this.button( this.panel, "Add lights...", "<p>Add light frames (XISF/FITS).</p>", function()
      {
         let files = self.pickFiles( "Select light frames", true );
         let s = self.currentSession();
         if ( !s || files.length == 0 )
            return;
         let have = {};
         s.lights.forEach( l => { have[ l.path ] = true; } );
         files.forEach( f => { if ( !have[ f ] ) s.lights.push( { path: f, strength: null } ); } );
         self.updateSessionPanel();
      } );
      this.removeLightsButton = this.button( this.panel, "Remove selected", "<p>Remove the selected light frames.</p>", function()
      {
         let s = self.currentSession();
         if ( !s )
            return;
         let sel = self.selectedLightIndices();
         s.lights = s.lights.filter( ( l, i ) => sel.indexOf( i ) < 0 );
         self.updateSessionPanel();
      } );
      this.clearLightsButton = this.button( this.panel, "Clear", "<p>Remove all light frames of this session.</p>", function()
      {
         let s = self.currentSession();
         if ( s )
         {
            s.lights = [];
            self.updateSessionPanel();
         }
      } );
      this.lightsSizer = this.listBlock( "Lights", this.lightsTree, [ this.addLightsButton, this.removeLightsButton, this.clearLightsButton ] );

      // Flats
      this.flatsTree = new TreeBox( this.panel );
      this.flatsTree.numberOfColumns = 1;
      this.flatsTree.headerVisible = false;
      this.flatsTree.rootDecoration = false;
      this.flatsTree.alternateRowColor = true;
      this.flatsTree.multipleSelection = true;
      this.flatsTree.setScaledMinSize( 460, 110 );
      this.flatsTree.toolTip = "<p>Flat frames of this session.</p>";

      this.addFlatsButton = this.button( this.panel, "Add flats...", "<p>Add flat frames (XISF/FITS).</p>", function()
      {
         let files = self.pickFiles( "Select flat frames", true );
         let s = self.currentSession();
         if ( !s || files.length == 0 )
            return;
         files.forEach( f => { if ( s.flats.indexOf( f ) < 0 ) s.flats.push( f ); } );
         self.updateSessionPanel();
      } );
      this.removeFlatsButton = this.button( this.panel, "Remove selected", "<p>Remove the selected flat frames.</p>", function()
      {
         let s = self.currentSession();
         if ( !s )
            return;
         let sel = [];
         for ( let i = 0; i < self.flatsTree.numberOfChildren; ++i )
            if ( self.flatsTree.child( i ).selected )
               sel.push( i );
         s.flats = s.flats.filter( ( f, i ) => sel.indexOf( i ) < 0 );
         self.updateSessionPanel();
      } );
      this.clearFlatsButton = this.button( this.panel, "Clear", "<p>Remove all flat frames of this session.</p>", function()
      {
         let s = self.currentSession();
         if ( s )
         {
            s.flats = [];
            self.updateSessionPanel();
         }
      } );
      this.flatsSizer = this.listBlock( "Flats", this.flatsTree, [ this.addFlatsButton, this.removeFlatsButton, this.clearFlatsButton ] );

      // Master files
      this.darkEdit = new Edit( this.panel );
      this.darkEdit.toolTip = "<p>Master dark for the lights (bias-calibrated).</p>";
      this.darkEdit.onEditCompleted = function() { let s = self.currentSession(); if ( s ) { s.masterDark = this.text.trim(); self.updateState(); } };
      this.darkButton = new ToolButton( this.panel );
      this.darkButton.icon = this.scaledResource( ":/icons/select-file.png" );
      this.darkButton.setScaledFixedSize( 22, 22 );
      this.darkButton.toolTip = "<p>Select the master dark.</p>";
      this.darkButton.onClick = function()
      {
         let f = self.pickFiles( "Select master dark", false );
         let s = self.currentSession();
         if ( s && f.length > 0 )
         {
            s.masterDark = f[ 0 ];
            self.updateSessionPanel();
         }
      };
      this.darkSizer = this.labeledRow( this.panel, "Master dark:", labelWidth, this.darkEdit, this.darkButton );

      this.darkFlatEdit = new Edit( this.panel );
      this.darkFlatEdit.toolTip = "<p>Master dark for the flats.</p>";
      this.darkFlatEdit.onEditCompleted = function() { let s = self.currentSession(); if ( s ) { s.masterDarkFlat = this.text.trim(); self.updateState(); } };
      this.darkFlatButton = new ToolButton( this.panel );
      this.darkFlatButton.icon = this.scaledResource( ":/icons/select-file.png" );
      this.darkFlatButton.setScaledFixedSize( 22, 22 );
      this.darkFlatButton.toolTip = "<p>Select the master dark flat.</p>";
      this.darkFlatButton.onClick = function()
      {
         let f = self.pickFiles( "Select master dark flat", false );
         let s = self.currentSession();
         if ( s && f.length > 0 )
         {
            s.masterDarkFlat = f[ 0 ];
            self.updateSessionPanel();
         }
      };
      this.darkFlatSizer = this.labeledRow( this.panel, "Master dark flat:", labelWidth, this.darkFlatEdit, this.darkFlatButton );

      // CFA
      this.cfaModeCombo = new ComboBox( this.panel );
      [ "Auto", "Mono", "CFA" ].forEach( t => this.cfaModeCombo.addItem( t ) );
      this.cfaModeCombo.toolTip = "<p>Treat frames as mono or CFA mosaics. Auto reads the Bayer keyword.</p>";
      this.cfaModeCombo.onItemSelected = function( i )
      {
         let s = self.currentSession();
         if ( s )
            s.cfaMode = [ "auto", "mono", "cfa" ][ i ];
      };
      this.cfaPatternCombo = new ComboBox( this.panel );
      [ "Auto", "RGGB", "BGGR", "GBRG", "GRBG" ].forEach( t => this.cfaPatternCombo.addItem( t ) );
      this.cfaPatternCombo.toolTip = "<p>Bayer pattern; auto reads it from the file.</p>";
      this.cfaPatternCombo.onItemSelected = function( i )
      {
         let s = self.currentSession();
         if ( s )
            s.cfaPattern = i == 0 ? "auto" : self.cfaPatternCombo.itemText( i );
      };
      let patLabel = new Label( this.panel );
      patLabel.text = "Pattern:";
      patLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.cfaSizer = this.labeledRow( this.panel, "CFA:", labelWidth, this.cfaModeCombo, patLabel, this.cfaPatternCombo );
      this.cfaSizer.addStretch();

      // Strength
      this.strengthLabel = new Label( this.panel );
      this.strengthLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
      this.strengthLabel.useRichText = true;
      this.strengthButton = this.button( this.panel, "Flat Strength...",
         "<p>Open the preview for the selected session (and the selected light, if any) to choose the flat strength.</p>",
         function() { self.openPreview(); } );
      this.resetStrengthButton = this.button( this.panel, "Reset session to 0",
         "<p>Set the session strength to 0 and clear all frame overrides.</p>", function()
      {
         let s = self.currentSession();
         if ( s )
         {
            s.strength = 0;
            s.lights.forEach( l => { l.strength = null; } );
            self.updateSessionPanel();
         }
      } );
      this.strengthSizer = new HorizontalSizer;
      this.strengthSizer.spacing = 6;
      this.strengthSizer.add( this.strengthLabel );
      this.strengthSizer.addStretch();
      this.strengthSizer.add( this.strengthButton );
      this.strengthSizer.add( this.resetStrengthButton );

      this.panel.sizer = new VerticalSizer;
      this.panel.sizer.spacing = 6;
      this.panel.sizer.add( this.nameSizer );
      this.panel.sizer.add( this.lightsSizer, 100 );
      this.panel.sizer.add( this.flatsSizer, 60 );
      this.panel.sizer.add( this.darkSizer );
      this.panel.sizer.add( this.darkFlatSizer );
      this.panel.sizer.add( this.cfaSizer );
      this.panel.sizer.add( this.strengthSizer );

      this.sessionsGroup = new GroupBox( this );
      this.sessionsGroup.title = "Sessions";
      this.sessionsGroup.sizer = new HorizontalSizer;
      this.sessionsGroup.sizer.margin = 6;
      this.sessionsGroup.sizer.spacing = 8;
      this.sessionsGroup.sizer.add( this.leftSizer );
      this.sessionsGroup.sizer.add( this.panel, 100 );

      // ---------------------------------------------------------- output
      this.outEdit = new Edit( this );
      this.outEdit.text = params.outputDir;
      this.outEdit.toolTip = "<p>Folder for calibrated lights (calibrated/), master flats (masters/) and temporary files (temp/).</p>";
      this.outEdit.onEditCompleted = function() { self.params.outputDir = this.text.trim(); self.updateState(); };
      this.outButton = new ToolButton( this );
      this.outButton.icon = this.scaledResource( ":/icons/select-file.png" );
      this.outButton.setScaledFixedSize( 22, 22 );
      this.outButton.toolTip = "<p>Select the output folder.</p>";
      this.outButton.onClick = function()
      {
         let d = new GetDirectoryDialog;
         d.caption = "Select output folder";
         d.initialPath = self.params.outputDir || self.params.lastDir;
         if ( d.execute() )
         {
            self.params.outputDir = d.directoryPath;
            self.outEdit.text = d.directoryPath;
            self.updateState();
         }
      };
      this.outSizer = this.labeledRow( this, "Output folder:", labelWidth, this.outEdit, this.outButton );

      this.subLabel = new Label( this );
      this.subLabel.text = "Writes calibrated lights to calibrated/<session>/, master flats to masters/ and temporary files to temp/ (removed after the run).";

      this.keepCheck = new CheckBox( this );
      this.keepCheck.text = "Keep intermediates";
      this.keepCheck.checked = params.keepIntermediates;
      this.keepCheck.toolTip = "<p>Keep calibrated flats and derived flats in temp/ after the run.</p>";
      this.keepCheck.onCheck = function( c ) { self.params.keepIntermediates = c; };

      this.reuseCheck = new CheckBox( this );
      this.reuseCheck.text = "Reuse existing masters";
      this.reuseCheck.checked = params.reuseMasters;
      this.reuseCheck.toolTip = "<p>Reuse an existing master flat in masters/ if its inputs have not changed.</p>";
      this.reuseCheck.onCheck = function( c ) { self.params.reuseMasters = c; };

      this.checksSizer = new HorizontalSizer;
      this.checksSizer.spacing = 16;
      this.checksSizer.addSpacing( labelWidth + 6 );
      this.checksSizer.add( this.keepCheck );
      this.checksSizer.add( this.reuseCheck );
      this.checksSizer.addStretch();

      this.outputGroup = new GroupBox( this );
      this.outputGroup.title = "Output";
      this.outputGroup.sizer = new VerticalSizer;
      this.outputGroup.sizer.margin = 6;
      this.outputGroup.sizer.spacing = 4;
      this.outputGroup.sizer.add( this.outSizer );
      this.outputGroup.sizer.add( this.subLabel );
      this.outputGroup.sizer.add( this.checksSizer );

      // ---------------------------------------------------------- advanced
      this.advControl = new Control( this );
      this.optDarkCheck = new CheckBox( this.advControl );
      this.optDarkCheck.text = "Optimize master dark";
      this.optDarkCheck.checked = params.optimizeDark;
      this.optDarkCheck.toolTip = "<p>Let ImageCalibration scale the master dark for the lights. Leave off when dark and " +
                                  "lights share exposure and temperature.</p>";
      this.optDarkCheck.onCheck = function( c ) { self.params.optimizeDark = c; };

      this.pedCombo = new ComboBox( this.advControl );
      [ "Auto", "None", "Literal" ].forEach( t => this.pedCombo.addItem( t ) );
      this.pedCombo.currentItem = Math.max( 0, [ "auto", "none", "literal" ].indexOf( params.pedestalMode ) );
      this.pedCombo.toolTip = "<p>Output pedestal for calibrated lights: Auto adds a pedestal only if values would go negative.</p>";
      this.pedCombo.onItemSelected = function( i )
      {
         self.params.pedestalMode = [ "auto", "none", "literal" ][ i ];
         self.pedSpin.enabled = i == 2;
      };
      this.pedSpin = new SpinBox( this.advControl );
      this.pedSpin.minValue = 0;
      this.pedSpin.maxValue = 1000;
      this.pedSpin.value = params.pedestal;
      this.pedSpin.enabled = params.pedestalMode == "literal";
      this.pedSpin.toolTip = "<p>Literal output pedestal in DN (16-bit units).</p>";
      this.pedSpin.onValueUpdated = function( v ) { self.params.pedestal = v; };
      let dnLabel = new Label( this.advControl );
      dnLabel.text = "DN";
      dnLabel.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;
      this.pedSizer = this.labeledRow( this.advControl, "Output pedestal:", labelWidth, this.pedCombo, this.pedSpin, dnLabel );
      this.pedSizer.addStretch();

      this.rejCombo = new ComboBox( this.advControl );
      [ "Auto", "None", "Percentile", "Winsorized sigma", "ESD" ].forEach( t => this.rejCombo.addItem( t ) );
      this.rejCombo.currentItem = Math.max( 0, [ "auto", "none", "percentile", "winsorized", "esd" ].indexOf( params.flatRejection ) );
      this.rejCombo.toolTip = "<p>Pixel rejection used when integrating flats. Auto chooses by frame count " +
                              "(&lt;3 none, 3-7 percentile, 8-19 Winsorized sigma, 20+ ESD).</p>";
      this.rejCombo.onItemSelected = function( i ) { self.params.flatRejection = [ "auto", "none", "percentile", "winsorized", "esd" ][ i ]; };
      this.rejSizer = this.labeledRow( this.advControl, "Flat rejection:", labelWidth, this.rejCombo );
      this.rejSizer.addStretch();

      let optSizer = new HorizontalSizer;
      optSizer.addSpacing( labelWidth + 6 );
      optSizer.add( this.optDarkCheck );
      optSizer.addStretch();

      this.advControl.sizer = new VerticalSizer;
      this.advControl.sizer.spacing = 4;
      this.advControl.sizer.add( optSizer );
      this.advControl.sizer.add( this.pedSizer );
      this.advControl.sizer.add( this.rejSizer );

      this.advBar = new SectionBar( this, "Advanced" );
      this.advBar.setSection( this.advControl );
      this.advBar.onToggleSection = function( bar, toggleBegin )
      {
         if ( !toggleBegin )
            self.adjustToContents();
      };
      this.advControl.hide();

      // ---------------------------------------------------------- bottom
      this.statusLabel = new Label( this );
      this.statusLabel.text = "Ready.";

      this.helpButton = this.button( this, "Help", "<p>How to use this script.</p>", function() { self.showHelp(); } );
      this.saveListButton = this.button( this, "Save list...", "<p>Save the session list to a JSON file.</p>", function() { self.saveList(); } );
      this.loadListButton = this.button( this, "Load list...", "<p>Load a session list from a JSON file.</p>", function() { self.loadList(); } );
      this.calibrateButton = this.button( this, "Calibrate", "<p>Calibrate all sessions.</p>", function() { self.calibrate(); } );
      this.calibrateButton.icon = this.scaledResource( ":/icons/power.png" );
      this.closeButton = this.button( this, "Close", "<p>Close the dialog (settings are kept).</p>", function() { self.ok(); } );
      this.closeButton.icon = this.scaledResource( ":/icons/close.png" );

      this.buttonsSizer = new HorizontalSizer;
      this.buttonsSizer.spacing = 6;
      this.buttonsSizer.add( this.helpButton );
      this.buttonsSizer.add( this.saveListButton );
      this.buttonsSizer.add( this.loadListButton );
      this.buttonsSizer.addStretch();
      this.buttonsSizer.add( this.calibrateButton );
      this.buttonsSizer.add( this.closeButton );

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 8;
      this.sizer.add( this.helpLabel );
      this.sizer.add( this.sessionsGroup, 100 );
      this.sizer.add( this.outputGroup );
      this.sizer.add( this.advBar );
      this.sizer.add( this.advControl );
      this.sizer.add( this.statusLabel );
      this.sizer.add( this.buttonsSizer );

      this.windowTitle = PSW_TITLE;
      this.refreshSessions( 0 );
      this.adjustToContents();
      this.setScaledMinWidth( 760 );
   }

   // ---------------------------------------------------------- layout helpers

   button( parent, text, tip, onClick )
   {
      let b = new PushButton( parent );
      b.text = text;
      b.toolTip = tip;
      b.onClick = onClick;
      return b;
   }

   labeledRow( parent, text, width )
   {
      let l = new Label( parent );
      l.text = text;
      l.minWidth = width;
      l.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      let s = new HorizontalSizer;
      s.spacing = 6;
      s.add( l );
      for ( let i = 3; i < arguments.length; ++i )
         s.add( arguments[ i ], i == 3 ? 100 : 0 );
      return s;
   }

   listBlock( title, tree, buttons )
   {
      let l = new Label( this.panel );
      l.text = title;
      l.useRichText = false;
      let bs = new VerticalSizer;
      bs.spacing = 4;
      buttons.forEach( b => bs.add( b ) );
      bs.addStretch();
      let hs = new HorizontalSizer;
      hs.spacing = 6;
      hs.add( tree, 100 );
      hs.add( bs );
      let vs = new VerticalSizer;
      vs.spacing = 2;
      vs.add( l );
      vs.add( hs, 100 );
      return vs;
   }

   pickFiles( caption, multiple )
   {
      let d = new OpenFileDialog;
      d.caption = caption;
      d.multipleSelections = multiple;
      d.filters = PSW_FILE_FILTERS;
      if ( this.params.lastDir && File.directoryExists( this.params.lastDir ) )
         d.initialPath = this.params.lastDir;
      if ( !d.execute() )
         return [];
      let files = multiple ? d.fileNames : [ d.fileName ];
      if ( files.length > 0 )
         this.params.lastDir = File.extractDrive( files[ 0 ] ) + File.extractDirectory( files[ 0 ] );
      return files;
   }

   // ---------------------------------------------------------- state

   currentSessionIndex()
   {
      let n = this.sessionTree.currentNode;
      if ( !n )
         return -1;
      let i = this.sessionTree.childIndex( n );
      return ( i >= 0 && i < this.params.sessions.length ) ? i : -1;
   }

   currentSession()
   {
      let i = this.currentSessionIndex();
      return i >= 0 ? this.params.sessions[ i ] : null;
   }

   selectedLightIndices()
   {
      let sel = [];
      for ( let i = 0; i < this.lightsTree.numberOfChildren; ++i )
         if ( this.lightsTree.child( i ).selected )
            sel.push( i );
      return sel;
   }

   refreshSessions( select )
   {
      this.updating = true;
      try
      {
         this.sessionTree.clear();
         this.params.sessions.forEach( ( s, i ) =>
         {
            PSWParameters.sessionDefaults( s, i );
            let node = new TreeBoxNode( this.sessionTree );
            node.setText( 0, s.name );
         } );
         if ( this.params.sessions.length > 0 )
         {
            let i = Math.max( 0, Math.min( this.params.sessions.length - 1, select || 0 ) );
            this.sessionTree.currentNode = this.sessionTree.child( i );
            this.sessionTree.child( i ).selected = true;
         }
      }
      finally
      {
         this.updating = false;
      }
      this.updateSessionPanel();
   }

   applyName()
   {
      let i = this.currentSessionIndex();
      if ( i < 0 )
         return;
      let name = this.nameEdit.text.trim();
      if ( name.length == 0 )
      {
         this.nameEdit.text = this.params.sessions[ i ].name;
         return;
      }
      let safe = PSWEngine.safeName( name ).toLowerCase();
      for ( let j = 0; j < this.params.sessions.length; ++j )
         if ( j != i && PSWEngine.safeName( this.params.sessions[ j ].name ).toLowerCase() == safe )
         {
            pswMessage( "Another session already uses this name.", StdIcon.Warning );
            this.nameEdit.text = this.params.sessions[ i ].name;
            return;
         }
      this.params.sessions[ i ].name = name;
      this.sessionTree.child( i ).setText( 0, name );
   }

   updateSessionPanel()
   {
      let s = this.currentSession();
      this.panel.enabled = s != null;
      this.removeSessionButton.enabled = s != null;
      this.renameButton.enabled = s != null;
      if ( !s )
      {
         this.lightsTree.clear();
         this.flatsTree.clear();
         this.nameEdit.text = "";
         this.darkEdit.text = "";
         this.darkFlatEdit.text = "";
         this.strengthLabel.text = "Session strength: +0.00";
         this.updateState();
         return;
      }
      this.nameEdit.text = s.name;
      let overrides = 0;
      let setStrength = ( node, l ) =>
      {
         if ( l.strength === null || l.strength === undefined || l.strength === "" )
         {
            node.setText( 1, "-" );
            node.setTextColor( 1, node.textColor( 0 ) );
         }
         else
         {
            ++overrides;
            node.setText( 1, pswFormatStrength( PSWEngine.normStrength( l.strength ) ) );
            node.setTextColor( 1, 0xff2060e0 );
         }
      };
      let T = this.lightsTree;
      let same = T.numberOfChildren == s.lights.length;
      for ( let i = 0; same && i < s.lights.length; ++i )
         if ( T.child( i ).toolTip( 0 ) != s.lights[ i ].path )
            same = false;
      if ( same )
      {
         // Same list (e.g. after Apply): update the strength column in place, so
         // selection and scroll position stay and nothing flickers.
         for ( let i = 0; i < s.lights.length; ++i )
            setStrength( T.child( i ), s.lights[ i ] );
      }
      else
      {
         // Rebuild, keeping the selected paths and the current row in view.
         let selPaths = {};
         for ( let i = 0; i < T.numberOfChildren; ++i )
            if ( T.child( i ).selected )
               selPaths[ T.child( i ).toolTip( 0 ) ] = true;
         let cur = T.currentNode ? T.currentNode.toolTip( 0 ) : "";
         T.enabled = false;
         T.clear();
         let curNode = null;
         s.lights.forEach( l =>
         {
            let node = new TreeBoxNode( T );
            node.setText( 0, File.extractNameAndExtension( l.path ) );
            node.setToolTip( 0, l.path );
            node.setAlignment( 1, TextAlignment.Center );
            setStrength( node, l );
            if ( selPaths[ l.path ] )
               node.selected = true;
            if ( l.path == cur )
               curNode = node;
         } );
         if ( curNode )
         {
            T.currentNode = curNode;
            T.setNodeIntoView( curNode );
         }
         T.adjustColumnWidthToContents( 0 );
         T.enabled = true;
      }
      let F = this.flatsTree;
      let sameF = F.numberOfChildren == s.flats.length;
      for ( let i = 0; sameF && i < s.flats.length; ++i )
         if ( F.child( i ).toolTip( 0 ) != s.flats[ i ] )
            sameF = false;
      if ( !sameF )
      {
         F.clear();
         s.flats.forEach( f =>
         {
            let node = new TreeBoxNode( F );
            node.setText( 0, File.extractNameAndExtension( f ) );
            node.setToolTip( 0, f );
         } );
      }
      this.darkEdit.text = s.masterDark;
      this.darkFlatEdit.text = s.masterDarkFlat;
      this.cfaModeCombo.currentItem = Math.max( 0, [ "auto", "mono", "cfa" ].indexOf( String( s.cfaMode ).toLowerCase() ) );
      let pi = [ "AUTO", "RGGB", "BGGR", "GBRG", "GRBG" ].indexOf( String( s.cfaPattern ).toUpperCase() );
      this.cfaPatternCombo.currentItem = Math.max( 0, pi );
      this.strengthLabel.text = "Session strength: <b>" + pswFormatStrength( PSWEngine.normStrength( s.strength ) ) + "</b>" +
                                " &nbsp; (" + s.lights.length + " lights, " + overrides + " frame override(s), " +
                                s.flats.length + " flats)";
      this.updateState();
   }

   updateState()
   {
      let s = this.currentSession();
      let hasOut = this.params.outputDir && File.directoryExists( this.params.outputDir );
      let canPreview = s != null && hasOut && s.lights.length > 0 && s.masterDark != "";
      this.strengthButton.enabled = canPreview;
      if ( !hasOut )
         this.strengthButton.toolTip = "<p>Set the output folder first: the preview builds the master flat there.</p>";
      else if ( !canPreview )
         this.strengthButton.toolTip = "<p>Add lights and a master dark (and flats with a master dark flat) first.</p>";
      else
         this.strengthButton.toolTip = "<p>Open the preview for the selected session (and the selected light, if any) to choose the flat strength.</p>";
   }

   // ---------------------------------------------------------- actions

   openPreview()
   {
      let si = this.currentSessionIndex();
      if ( si < 0 )
         return;
      let s = this.params.sessions[ si ];
      if ( !this.params.outputDir || !File.directoryExists( this.params.outputDir ) )
      {
         pswMessage( "Please set an existing output folder first: the preview builds the master flat there.", StdIcon.Warning );
         return;
      }
      // Validate this session as the preview needs it (flats and dark flat required),
      // so size mismatches, missing files or an unknown CFA pattern give a clear message.
      let probe = {};
      for ( let key in this.params )
         probe[ key ] = this.params[ key ];
      let sc = {};
      for ( let key in s )
         sc[ key ] = s[ key ];
      sc.strength = 0;
      sc.lights = s.lights.map( l => ( { path: l.path, strength: null } ) );
      sc.flats = s.flats.slice();
      probe.sessions = [ sc ];
      this.cursor = new Cursor( StdCursor.Hourglass );
      let verr = PSWEngine.validate( probe );
      this.cursor = new Cursor( StdCursor.Arrow );
      if ( verr.length > 0 )
      {
         pswMessage( "The preview cannot be opened:\n\n" + verr.join( "\n" ), StdIcon.Error );
         return;
      }
      let sel = this.selectedLightIndices();
      let li = sel.length > 0 ? sel[ 0 ] : 0;
      let ctx = null;
      this.statusLabel.text = "Preparing the preview (building the master flat if needed)...";
      this.cursor = new Cursor( StdCursor.Hourglass );
      try
      {
         console.show();
         ctx = PSWEngine.preparePreview( s, li, this.params );
      }
      catch ( e )
      {
         this.cursor = new Cursor( StdCursor.Arrow );
         this.statusLabel.text = "Preview failed.";
         pswMessage( "Cannot open the preview:\n" + ( e.message || e ), StdIcon.Error );
         return;
      }
      this.cursor = new Cursor( StdCursor.Arrow );
      this.statusLabel.text = "Ready.";
      let dlg = new PSWPreviewDialog( this.params, si, ctx, sel, this );
      try
      {
         dlg.execute();
      }
      finally
      {
         dlg.timer.stop();
         PSWEngine.closePreview( dlg.ctx );
      }
      this.updateSessionPanel();
   }

   calibrate()
   {
      let errors = PSWEngine.validate( this.params );
      if ( errors.length > 0 )
      {
         pswMessage( "Please fix the following problems:\n\n" + errors.join( "\n" ), StdIcon.Error );
         return;
      }
      if ( errors.warnings.length > 0 )
      {
         let r = ( new MessageBox( "Warnings:\n\n" + errors.warnings.join( "\n" ) + "\n\nContinue?", PSW_TITLE,
                                   StdIcon.Warning, StdButton.Yes, StdButton.No ) ).execute();
         if ( r != StdButton.Yes )
            return;
      }
      this.params.save();
      console.show();
      this.enabled = false;
      this.statusLabel.text = "Calibrating... (use the Process Console Abort button to stop)";
      let R = null;
      try
      {
         R = PSWEngine.run( null, this.params, errors );   // already validated: no second header pass
      }
      catch ( e )
      {
         console.criticalln( "*** " + ( e.message || e ) );
         pswMessage( "Calibration failed:\n" + ( e.message || e ), StdIcon.Error );
      }
      finally
      {
         this.enabled = true;
      }
      if ( R )
      {
         let msg = ( R.aborted ? "Aborted.\n\n" : "Done.\n\n" ) +
                   R.lightsOk + " light(s) calibrated, " + R.lightsFailed + " failed.\n" +
                   R.icRuns + " ImageCalibration run(s), " + R.masterFlatsBuilt + " master flat(s) built, " +
                   R.derivedFlatsBuilt + " derived flat(s).\n" + format( "Time: %.1f s", R.seconds ) +
                   ( R.failed.length > 0 ? "\n\nFailed:\n" + R.failed.slice( 0, 10 ).join( "\n" ) : "" ) +
                   "\n\nOutput: " + this.params.outputDir + "/calibrated";
         this.statusLabel.text = format( "Last run: %d calibrated, %d failed, %.1f s", R.lightsOk, R.lightsFailed, R.seconds );
         pswMessage( msg, R.lightsFailed > 0 || R.aborted ? StdIcon.Warning : StdIcon.Information );
      }
      else
         this.statusLabel.text = "Last run failed.";
   }

   saveList()
   {
      let d = new SaveFileDialog;
      d.caption = "Save session list";
      d.filters = [ [ "JSON files", "*.json" ] ];
      if ( this.params.lastDir )
         d.initialPath = this.params.lastDir + "/sessions.json";
      if ( !d.execute() )
         return;
      try
      {
         File.writeTextFile( d.filePath, JSON.stringify( { version: PSW_VERSION, sessions: this.params.sessions }, null, 1 ) );
      }
      catch ( e )
      {
         pswMessage( "Cannot save the list:\n" + ( e.message || e ), StdIcon.Error );
      }
   }

   loadList()
   {
      let d = new OpenFileDialog;
      d.caption = "Load session list";
      d.filters = [ [ "JSON files", "*.json" ] ];
      if ( this.params.lastDir && File.directoryExists( this.params.lastDir ) )
         d.initialPath = this.params.lastDir;
      if ( !d.execute() )
         return;
      try
      {
         let j = JSON.parse( File.readTextFile( d.fileName ) );
         let sessions = Array.isArray( j ) ? j : j.sessions;
         if ( !Array.isArray( sessions ) )
            throw new Error( "No session list in this file." );
         sessions.forEach( ( s, i ) => PSWParameters.sessionDefaults( s, i ) );
         this.params.sessions = sessions;
         this.refreshSessions( 0 );
      }
      catch ( e )
      {
         pswMessage( "Cannot load the list:\n" + ( e.message || e ), StdIcon.Error );
      }
   }

   showHelp()
   {
      pswMessage(
         "Flat Strength Calibration calibrates light frames with a master dark and a master flat per session, " +
         "without WBPP, and lets you choose how strongly the flat is applied.\n\n" +
         "1. Add a session per night/optical setup. Add its lights, flats, the master dark for the lights and the " +
         "master dark for the flats (both already bias-calibrated).\n" +
         "2. Choose an output folder. The master flat is built in masters/, calibrated lights go to " +
         "calibrated/<session>/ as 32-bit XISF. CFA data stay CFA (not debayered).\n" +
         "3. Optional: 'Flat Strength...' opens a before/after preview. Strength 0 is the standard calibration, " +
         "-1 applies no flat, +1 applies the flat twice (exponent k = 1 + s). Apply the value to one frame, the " +
         "selected frames or the whole session.\n" +
         "4. Press Calibrate. Lights are grouped by strength: one ImageCalibration run per distinct strength.\n\n" +
         "The preview is auto-stretched for display only. Its mosaic mode (debayer off) keeps two full-size images " +
         "in memory, four while loading (about 210 to 420 MB for 26 MP); the debayered preview stays below about 150 MB.\n" +
         "Abort a running calibration with the Process Console Abort button." );
   }
};
