// RingArtifactRemover_v2GUI.js - dialog only. Reads/writes PSWParameters, never processes pixels.
// V8 engine style: ES6 class extends Dialog, enums as Namespace.Value (FrameStyle.Box ...).

var PSWDialog = class extends Dialog
{
   constructor( params, parent )
   {
      super( parent );

      this.params = params;
      let self = this;

      let win = ImageWindow.activeWindow;
      this.targetView = (win == null || win.isNull) ? null : win.currentView;
      let W = 0, H = 0, nch = 0;
      let hasTarget = this.targetView != null && !this.targetView.isNull;
      if ( hasTarget )
      {
         W = this.targetView.image.width;
         H = this.targetView.image.height;
         nch = this.targetView.image.numberOfChannels;
         params.adaptToImage( W, H, false );
      }
      this.imgW = W;
      this.imgH = H;
      let isColor = nch >= 3;

      let labelWidth = this.font.width( "Arc smoothing:" ) + this.font.width( 'MM' );
      let editWidth = this.font.width( "-000000.0" ) + this.font.width( 'MM' );

      // ---- help -------------------------------------------------------------
      this.helpLabel = new Label( this );
      this.helpLabel.frameStyle = FrameStyle.Box;
      this.helpLabel.margin = 6;
      this.helpLabel.wordWrapping = true;
      this.helpLabel.useRichText = true;
      this.helpLabel.text = "<p><b>" + PSW_TITLE + "</b> &mdash; removes large, sharp ring artifacts " +
         "(internal reflections). The rings are measured locally along every direction from the centre, " +
         "so arcs that are not perfect concentric circles are removed too.</p>" +
         "<p>Linear, gradient-corrected data. Ring scale = widest structure to remove; " +
         "larger removes broader zones at the edges.</p>";

      // ---- target info -----------------------------------------------------
      this.targetLabel = new Label( this );
      this.targetLabel.text = !hasTarget ?
         "Target: no image" :
         format( "Target: %s   %d x %d   %s%s", this.targetView.id, W, H, isColor ? "RGB" : "mono",
                 this.targetView.isPreview ? "   (preview: not supported)" : "" );

      let rightLabel = ( text, tip ) =>
      {
         let l = new Label( this );
         l.text = text;
         l.minWidth = labelWidth;
         l.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
         if ( tip ) l.toolTip = tip;
         return l;
      };

      // ---- ring geometry ------------------------------------------------------
      this.modeCombo = new ComboBox( this );
      this.modeCombo.addItem( "Image centre" );
      this.modeCombo.addItem( "Manual" );
      this.modeCombo.currentItem = params.centerMode;
      this.modeCombo.toolTip = "<p>Where the rings are measured from. The model adapts to rings whose " +
         "own centres drift by several hundred pixels, so the image centre usually works. " +
         "Use Manual if the rings clearly come from another point (it may lie outside the image).</p>";
      this.modeCombo.onItemSelected = function( i ) { self.params.centerMode = i; self.updateEnabled(); };
      let modeSizer = new HorizontalSizer;
      modeSizer.spacing = 4;
      modeSizer.add( rightLabel( "Centre:", this.modeCombo.toolTip ) );
      modeSizer.add( this.modeCombo );
      modeSizer.addStretch();

      let makeEdit = ( text, tip, value, lo, hi ) =>
      {
         let e = new NumericEdit( this );
         e.label.text = text;
         e.label.minWidth = labelWidth;
         e.setReal( true );
         e.setPrecision( 1 );
         e.setRange( lo, hi );
         e.edit.setFixedWidth( editWidth );
         e.setValue( value );
         e.toolTip = tip;
         return e;
      };
      let rw = W > 0 ? W : 10000, rh = H > 0 ? H : 10000;
      this.cxEdit = makeEdit( "Centre X:", "<p>X of the ring centre in full-resolution pixels (Manual mode). " +
         "May lie outside the image.</p>", isFinite( params.centerX ) ? params.centerX : rw/2, -2*rw, 3*rw );
      this.cxEdit.onValueUpdated = function( v ) { self.params.centerX = v; };
      this.cyEdit = makeEdit( "Centre Y:", "<p>Y of the ring centre in full-resolution pixels (Manual mode). " +
         "May lie outside the image.</p>", isFinite( params.centerY ) ? params.centerY : rh/2, -2*rh, 3*rh );
      this.cyEdit.onValueUpdated = function( v ) { self.params.centerY = v; };

      this.centreButton = new PushButton( this );
      this.centreButton.text = "Use image centre";
      this.centreButton.toolTip = "<p>Set Centre X/Y to the centre of the target image.</p>";
      this.centreButton.enabled = W > 0;
      this.centreButton.onClick = function()
      {
         self.params.centerX = self.imgW/2;
         self.params.centerY = self.imgH/2;
         self.cxEdit.setValue( self.params.centerX );
         self.cyEdit.setValue( self.params.centerY );
      };

      let xySizer = new HorizontalSizer;
      xySizer.spacing = 12;
      xySizer.add( this.cxEdit );
      xySizer.add( this.cyEdit );
      xySizer.addStretch();
      xySizer.add( this.centreButton );

      this.geomGroup = new GroupBox( this );
      this.geomGroup.title = "Ring geometry";
      this.geomGroup.sizer = new VerticalSizer;
      this.geomGroup.sizer.margin = 6;
      this.geomGroup.sizer.spacing = 4;
      this.geomGroup.sizer.add( modeSizer );
      this.geomGroup.sizer.add( xySizer );

      // ---- model ----------------------------------------------------------------
      let makeNum = ( text, tip, lo, hi, prec, value, steps, onv ) =>
      {
         let c = new NumericControl( this );
         c.label.text = text;
         c.label.minWidth = labelWidth;
         c.setRange( lo, hi );
         c.slider.setRange( 0, steps );
         c.slider.minWidth = 200;
         c.setPrecision( prec );
         c.setReal( prec > 0 );
         c.setValue( value );
         c.toolTip = tip;
         c.onValueUpdated = onv;
         return c;
      };
      this.scaleControl = makeNum( "Ring scale:", "<p>Widest ring structure to remove, in full-resolution pixels. " +
         "Smoother radial trends (vignetting-like falloff) are kept. Larger values also remove broader " +
         "bright or dark zones near the image edges.</p>", 100, 3000, 0, params.ringScale, 290,
         function( v ) { self.params.ringScale = v; } );
      this.arcControl = makeNum( "Arc smoothing:", "<p>How far, in degrees, ring brightness is averaged around " +
         "the centre. Smaller follows rings that bend or shift more strongly but is noisier; larger is smoother.</p>",
         2, 30, 1, params.arcSmooth, 280, function( v ) { self.params.arcSmooth = v; } );
      this.detailControl = makeNum( "Ring detail:", "<p>Radial smoothing of the ring model, in radius bins " +
         "(one bin = 2 x bin factor full-resolution pixels). Smaller keeps sharper ring edges but adds noise.</p>",
         0.5, 4, 2, params.ringDetail, 350, function( v ) { self.params.ringDetail = v; } );
      this.innerControl = makeNum( "Inner radius:", "<p>No correction inside this radius (full-resolution " +
         "pixels, 0 = off), with a short smooth transition. Use it when the target object sits on the centre.</p>",
         0, 10000, 0, params.innerRadius, 1000, function( v ) { self.params.innerRadius = v; } );

      this.sectorSpin = new SpinBox( this );
      this.sectorSpin.setRange( 36, 180 );
      this.sectorSpin.value = params.nSectors;
      this.sectorSpin.toolTip = "<p>Number of angular sectors of the polar model. More sectors resolve " +
         "finer changes of ring shape around the centre; fewer are less noisy.</p>";
      this.sectorSpin.onValueUpdated = function( v ) { self.params.nSectors = v; };
      let secSizer = new HorizontalSizer;
      secSizer.spacing = 4;
      secSizer.add( rightLabel( "Sectors:", this.sectorSpin.toolTip ) );
      secSizer.add( this.sectorSpin );
      secSizer.addStretch();

      this.binSpin = new SpinBox( this );
      this.binSpin.setRange( PSW_BIN_MIN, PSW_BIN_MAX );
      this.binSpin.value = params.binFactor;
      this.binSpin.toolTip = "<p>Working bin factor. The model is measured on a binned copy; larger is " +
         "faster and less noisy, smaller resolves narrower rings.</p>";
      this.binSpin.onValueUpdated = function( v ) { self.params.binFactor = v; };
      secSizer.addSpacing( 16 );
      secSizer.add( rightLabel( "Bin factor:", this.binSpin.toolTip ) );
      secSizer.add( this.binSpin );

      this.objControl = makeNum( "Object sigma:", "<p>Large bright objects (nebulae, galaxies) above this many " +
         "noise sigmas are excluded from the measurement; the model is interpolated across them. " +
         "Lower excludes more faint nebulosity.</p>", 1, 10, 2, params.objectSigma, 900,
         function( v ) { self.params.objectSigma = v; } );

      this.protectCheck = new CheckBox( this );
      this.protectCheck.text = "Protect extended objects";
      this.protectCheck.checked = params.protectObjects;
      this.protectCheck.toolTip = "<p>Also exclude pixels surrounded mostly by rejected area (gaps between " +
         "nebula filaments, bright star halos). Turn off only if the ring model looks starved.</p>";
      this.protectCheck.onCheck = function( on ) { self.params.protectObjects = on; };
      let protSizer = new HorizontalSizer;
      protSizer.addSpacing( labelWidth + 4 );
      protSizer.add( this.protectCheck );
      protSizer.addStretch();

      this.modelGroup = new GroupBox( this );
      this.modelGroup.title = "Model";
      this.modelGroup.sizer = new VerticalSizer;
      this.modelGroup.sizer.margin = 6;
      this.modelGroup.sizer.spacing = 4;
      this.modelGroup.sizer.add( this.scaleControl );
      this.modelGroup.sizer.add( this.arcControl );
      this.modelGroup.sizer.add( secSizer );
      this.modelGroup.sizer.add( this.detailControl );
      this.modelGroup.sizer.add( this.innerControl );
      this.modelGroup.sizer.add( this.objControl );
      this.modelGroup.sizer.add( protSizer );

      // ---- apply ----------------------------------------------------------------
      this.amountControl = makeNum( "Amount:", "<p>Fraction of the ring model that is subtracted.</p>",
         0, 1.5, 2, params.amount, 150, function( v ) { self.params.amount = v; } );

      let makeCh = ( text, key ) =>
      {
         let cb = new CheckBox( this );
         cb.text = text;
         cb.checked = params[key];
         cb.enabled = isColor;
         cb.toolTip = "<p>Correct this colour channel.</p>";
         cb.onCheck = function( on ) { self.params[key] = on; };
         return cb;
      };
      this.chRCheck = makeCh( "R", "chR" );
      this.chGCheck = makeCh( "G", "chG" );
      this.chBCheck = makeCh( "B", "chB" );
      let chSizer = new HorizontalSizer;
      chSizer.spacing = 8;
      chSizer.add( rightLabel( "Channels:" ) );
      chSizer.add( this.chRCheck );
      chSizer.add( this.chGCheck );
      chSizer.add( this.chBCheck );
      chSizer.addStretch();

      this.modelCheck = new CheckBox( this );
      this.modelCheck.text = "Show ring model";
      this.modelCheck.checked = params.showModel;
      this.modelCheck.toolTip = "<p>Open a window (RingModel) with the removed ring model plus a 0.5 " +
         "pedestal. Apply an STF auto-stretch to see it.</p>";
      this.modelCheck.onCheck = function( on ) { self.params.showModel = on; };
      let modelSizer = new HorizontalSizer;
      modelSizer.addSpacing( labelWidth + 4 );
      modelSizer.add( this.modelCheck );
      modelSizer.addStretch();

      this.applyGroup = new GroupBox( this );
      this.applyGroup.title = "Apply";
      this.applyGroup.sizer = new VerticalSizer;
      this.applyGroup.sizer.margin = 6;
      this.applyGroup.sizer.spacing = 4;
      this.applyGroup.sizer.add( this.amountControl );
      this.applyGroup.sizer.add( chSizer );
      this.applyGroup.sizer.add( modelSizer );

      // ---- buttons --------------------------------------------------------------
      this.resetButton = new PushButton( this );
      this.resetButton.text = "Reset";
      this.resetButton.icon = this.scaledResource( ":/icons/reload.png" );
      this.resetButton.toolTip = "<p>Restore all parameters to their defaults.</p>";
      this.resetButton.onClick = function() { self.params.reset(); self.refresh(); };

      this.okButton = new PushButton( this );
      this.okButton.text = "Apply";
      this.okButton.icon = this.scaledResource( ":/icons/ok.png" );
      this.okButton.toolTip = "<p>Remove the rings from the target image (one undoable step).</p>";
      this.okButton.enabled = hasTarget && !this.targetView.isPreview;
      this.okButton.onClick = function()
      {
         if ( isColor && !self.params.chR && !self.params.chG && !self.params.chB )
         {
            (new MessageBox( "Select at least one channel.", PSW_TITLE, StdIcon.Error, StdButton.Ok )).execute();
            return;
         }
         self.ok();
      };

      this.cancelButton = new PushButton( this );
      this.cancelButton.text = "Cancel";
      this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
      this.cancelButton.toolTip = "<p>Close without changes.</p>";
      this.cancelButton.onClick = function() { self.cancel(); };

      this.buttonsSizer = new HorizontalSizer;
      this.buttonsSizer.spacing = 6;
      this.buttonsSizer.add( this.resetButton );
      this.buttonsSizer.addStretch();
      this.buttonsSizer.add( this.okButton );
      this.buttonsSizer.add( this.cancelButton );

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 8;
      this.sizer.add( this.helpLabel );
      this.sizer.add( this.targetLabel );
      this.sizer.add( this.geomGroup );
      this.sizer.add( this.modelGroup );
      this.sizer.add( this.applyGroup );
      this.sizer.add( this.buttonsSizer );

      this.windowTitle = PSW_TITLE;
      this.updateEnabled();
      this.setScaledMinWidth( 560 );
      this.adjustToContents();
      this.userResizable = false;
   }

   updateEnabled()
   {
      let manual = this.params.centerMode == 1;
      this.cxEdit.enabled = manual;
      this.cyEdit.enabled = manual;
      this.centreButton.enabled = manual && this.imgW > 0;
   }

   refresh()
   {
      let p = this.params;
      this.modeCombo.currentItem = p.centerMode;
      if ( isFinite( p.centerX ) ) this.cxEdit.setValue( p.centerX );
      if ( isFinite( p.centerY ) ) this.cyEdit.setValue( p.centerY );
      this.scaleControl.setValue( p.ringScale );
      this.arcControl.setValue( p.arcSmooth );
      this.sectorSpin.value = p.nSectors;
      this.binSpin.value = p.binFactor;
      this.detailControl.setValue( p.ringDetail );
      this.innerControl.setValue( p.innerRadius );
      this.objControl.setValue( p.objectSigma );
      this.amountControl.setValue( p.amount );
      this.chRCheck.checked = p.chR;
      this.chGCheck.checked = p.chG;
      this.chBCheck.checked = p.chB;
      this.modelCheck.checked = p.showModel;
      this.protectCheck.checked = p.protectObjects;
      this.updateEnabled();
   }
};
