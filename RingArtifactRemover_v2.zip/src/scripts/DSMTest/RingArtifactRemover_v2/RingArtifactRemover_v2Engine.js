// RingArtifactRemover_v2Engine.js - processing logic, no GUI objects allowed here.
//
// Contract used by the GUI and by the headless test harness:
//   new PSWParameters()            -> object with defaults, .load(), .save()
//   PSWEngine.run( view, params )  -> processes view in place (one undo step),
//                                     returns an object with numbers worth logging
//
// Algorithm (spec v2, locally adaptive polar model):
//   1. bin the image with IntegerResample (native, multithreaded);
//   2. star / large-object rejection mask, computed once on the channel mean;
//   3. per channel, accumulate sums and counts of masked pixels in a polar grid
//      (radius bins of 2 binned px x nSectors angular sectors) around the centre;
//   4. circular Gaussian smoothing of sums and counts along the angle, so every
//      arc keeps its own local radial position (no global circle is assumed);
//   5. along the radius: fine = narrow normalised Gaussian, coarse = wide
//      normalised Gaussian with one twicing step; ring = fine - coarse;
//   6. render the ring model at full resolution (bilinear in r, theta) and subtract.

var PSW_BIN_MIN = 2;
var PSW_BIN_MAX = 8;
var PSW_DR = 2;            // radial bin width of the polar grid (binned px)
var PSW_CF_MIN = 3;        // minimum smoothed pixel count of a cell for a ring value
var PSW_TAPER = 40;        // inner-radius taper length (binned px)
var PSW_REF_BIN = 4;       // mask sizes below are defined for bin 4 and scaled for other bins
var PSW_METRIC_HP = 250;   // high-pass sigma of the ring-power metric (binned px at bin 4)
// Object protection: an accepted pixel whose 25x25 (bin 4) neighbourhood is more than
// 60% rejected is excluded too (nebula light between filaments, bright-star halos).
var PSW_PROTECT_BOX = 25;
var PSW_PROTECT_FRAC = 0.6;

var PSWParameters = class
{
   constructor()
   {
      this.centerMode = 0;     // 0 = image centre, 1 = manual
      this.centerX = NaN;      // manual centre, full-resolution pixels
      this.centerY = NaN;
      this.lastW = 0;
      this.lastH = 0;
      this.binFactor = 4;
      this.nSectors = 96;
      this.arcSmooth = 7.5;    // degrees
      this.ringScale = 640;    // full-resolution px
      this.ringDetail = 1.0;   // radial bins (sigma)
      this.innerRadius = 0;    // full-resolution px
      this.amount = 1.0;
      this.objectSigma = 3.0;
      this.chR = true;
      this.chG = true;
      this.chB = true;
      this.showModel = false;
      this.protectObjects = true;
      this.diagnostics = true;   // not persisted: ring-power / object-ratio report (harness on, GUI off)
   }

   reset()
   {
      let w = this.lastW, h = this.lastH, diag = this.diagnostics;
      let d = new PSWParameters;
      for ( let k in d )
         this[k] = d[k];
      this.diagnostics = diag;
      this.adaptToImage( w, h, true );
   }

   // The manual centre is kept only if it was stored for an image of exactly this size.
   adaptToImage( w, h, force )
   {
      if ( !(w > 0 && h > 0) )
         return;
      if ( force || w != this.lastW || h != this.lastH || !isFinite( this.centerX ) || !isFinite( this.centerY ) )
      {
         this.centerX = w/2;
         this.centerY = h/2;
      }
      this.lastW = w;
      this.lastH = h;
   }

   validate()
   {
      let clamp = ( v, a, b, d ) => (typeof v == "number" && isFinite( v )) ? Math.max( a, Math.min( b, v ) ) : d;
      this.centerMode = (this.centerMode == 1) ? 1 : 0;
      this.binFactor = Math.round( clamp( this.binFactor, PSW_BIN_MIN, PSW_BIN_MAX, 4 ) );
      this.nSectors = Math.round( clamp( this.nSectors, 36, 180, 96 ) );
      this.arcSmooth = clamp( this.arcSmooth, 2, 30, 7.5 );
      this.ringScale = clamp( this.ringScale, 100, 3000, 640 );
      this.ringDetail = clamp( this.ringDetail, 0.5, 4, 1.0 );
      this.innerRadius = clamp( this.innerRadius, 0, 100000, 0 );
      this.amount = clamp( this.amount, 0, 1.5, 1 );
      this.objectSigma = clamp( this.objectSigma, 1, 10, 3 );
      this.chR = !!this.chR; this.chG = !!this.chG; this.chB = !!this.chB;
      this.showModel = !!this.showModel;
      this.protectObjects = !!this.protectObjects;
      this.diagnostics = !!this.diagnostics;
   }

   load()
   {
      let key = ( n ) => PSW_SETTINGS + "/" + n;
      let rd = ( n, t ) => { let v = Settings.read( key( n ), t ); if ( Settings.lastReadOK ) this[n] = v; };
      rd( "centerMode", DataType.Int32 );
      rd( "centerX", DataType.Double );
      rd( "centerY", DataType.Double );
      rd( "lastW", DataType.Int32 );
      rd( "lastH", DataType.Int32 );
      rd( "binFactor", DataType.Int32 );
      rd( "nSectors", DataType.Int32 );
      rd( "arcSmooth", DataType.Double );
      rd( "ringScale", DataType.Double );
      rd( "ringDetail", DataType.Double );
      rd( "innerRadius", DataType.Double );
      rd( "amount", DataType.Double );
      rd( "objectSigma", DataType.Double );
      rd( "chR", DataType.Boolean );
      rd( "chG", DataType.Boolean );
      rd( "chB", DataType.Boolean );
      rd( "showModel", DataType.Boolean );
      rd( "protectObjects", DataType.Boolean );
      this.validate();
   }

   save()
   {
      let key = ( n ) => PSW_SETTINGS + "/" + n;
      let okC = isFinite( this.centerX ) && isFinite( this.centerY );
      Settings.write( key( "centerMode" ), DataType.Int32, this.centerMode );
      Settings.write( key( "centerX" ), DataType.Double, okC ? this.centerX : 0 );
      Settings.write( key( "centerY" ), DataType.Double, okC ? this.centerY : 0 );
      Settings.write( key( "lastW" ), DataType.Int32, okC ? this.lastW : 0 );
      Settings.write( key( "lastH" ), DataType.Int32, okC ? this.lastH : 0 );
      Settings.write( key( "binFactor" ), DataType.Int32, this.binFactor );
      Settings.write( key( "nSectors" ), DataType.Int32, this.nSectors );
      Settings.write( key( "arcSmooth" ), DataType.Double, this.arcSmooth );
      Settings.write( key( "ringScale" ), DataType.Double, this.ringScale );
      Settings.write( key( "ringDetail" ), DataType.Double, this.ringDetail );
      Settings.write( key( "innerRadius" ), DataType.Double, this.innerRadius );
      Settings.write( key( "amount" ), DataType.Double, this.amount );
      Settings.write( key( "objectSigma" ), DataType.Double, this.objectSigma );
      Settings.write( key( "chR" ), DataType.Boolean, this.chR );
      Settings.write( key( "chG" ), DataType.Boolean, this.chG );
      Settings.write( key( "chB" ), DataType.Boolean, this.chB );
      Settings.write( key( "showModel" ), DataType.Boolean, this.showModel );
      Settings.write( key( "protectObjects" ), DataType.Boolean, this.protectObjects );
   }
};

// ----------------------------------------------------------------------------
// Numeric helpers (typed arrays only, no per-pixel Image access)
// ----------------------------------------------------------------------------
var PSWMath = {
   // k-th smallest element (0-based) of a typed array (the array is reordered).
   select: function( a, n, k )
   {
      let lo = 0, hi = n - 1;
      while ( hi > lo )
      {
         let mid = (lo + hi) >> 1;
         let x = a[lo], y = a[mid], z = a[hi];
         let p = (x < y) ? ((y < z) ? y : ((x < z) ? z : x)) : ((x < z) ? x : ((y < z) ? z : y));
         let i = lo, j = hi;
         while ( i <= j )
         {
            while ( a[i] < p ) ++i;
            while ( a[j] > p ) --j;
            if ( i <= j )
            {
               let t = a[i]; a[i] = a[j]; a[j] = t;
               ++i; --j;
            }
         }
         if ( k <= j )
            hi = j;
         else if ( k >= i )
            lo = i;
         else
            return a[k];
      }
      return a[k];
   },

   median: function( a, n )
   {
      if ( n <= 0 )
         return 0;
      let h = n >> 1;
      let m = this.select( a, n, h );
      if ( (n & 1) == 0 )
      {
         let mx = -Infinity;
         for ( let i = 0; i < h; ++i )
            if ( a[i] > mx ) mx = a[i];
         m = 0.5*(m + mx);
      }
      return m;
   },

   // Median and normalised MAD (1.4826*MAD) of src over sel != 0 (sel may be null).
   madn: function( src, sel, n, buf )
   {
      let m = 0;
      if ( sel == null )
      {
         for ( let i = 0; i < n; ++i ) buf[i] = src[i];
         m = n;
      }
      else
      {
         for ( let i = 0; i < n; ++i )
            if ( sel[i] ) buf[m++] = src[i];
      }
      if ( m < 3 )
         return { median: 0, madn: 0, n: m };
      let med = this.median( buf, m );
      for ( let i = 0; i < m; ++i )
         buf[i] = Math.abs( buf[i] - med );
      return { median: med, madn: 1.4826*this.median( buf, m ), n: m };
   },

   // Box radii of a 3-pass box approximation of a Gaussian of the given sigma.
   boxRadii: function( sigma )
   {
      let n = 3;
      let wIdeal = Math.sqrt( 12*sigma*sigma/n + 1 );
      let wl = Math.floor( wIdeal );
      if ( (wl & 1) == 0 ) --wl;
      let wu = wl + 2;
      let mIdeal = (12*sigma*sigma - n*wl*wl - 4*n*wl - 3*n)/(-4*wl - 4);
      let m = Math.round( mIdeal );
      let r = [];
      for ( let i = 0; i < n; ++i )
         r.push( ((i < m ? wl : wu) - 1) >> 1 );
      return r;
   },

   // Horizontal running box sum (truncated at the borders), src -> dst (distinct).
   boxH: function( src, dst, w, h, r )
   {
      if ( r <= 0 ) { dst.set( src ); return; }
      let e0 = Math.min( r, w );
      for ( let y = 0, o = 0; y < h; ++y, o += w )
      {
         let acc = 0;
         for ( let x = 0; x < e0; ++x ) acc += src[o + x];
         for ( let x = 0; x < w; ++x )
         {
            let xa = x + r;
            if ( xa < w ) acc += src[o + xa];
            dst[o + x] = acc;
            let xs = x - r;
            if ( xs >= 0 ) acc -= src[o + xs];
         }
      }
   },

   // Vertical running box sum (truncated), src -> dst (distinct), acc Float64Array(>= w).
   boxV: function( src, dst, w, h, r, acc )
   {
      if ( r <= 0 ) { dst.set( src ); return; }
      acc.fill( 0 );
      let e0 = Math.min( r, h );
      for ( let y = 0; y < e0; ++y )
         for ( let x = 0, o = y*w; x < w; ++x ) acc[x] += src[o + x];
      for ( let y = 0; y < h; ++y )
      {
         let ya = y + r;
         if ( ya < h )
            for ( let x = 0, o = ya*w; x < w; ++x ) acc[x] += src[o + x];
         for ( let x = 0, o = y*w; x < w; ++x ) dst[o + x] = acc[x];
         let ys = y - r;
         if ( ys >= 0 )
            for ( let x = 0, o = ys*w; x < w; ++x ) acc[x] -= src[o + x];
      }
   },

   // In-place 3-pass box approximation of a Gaussian (unnormalised sums).
   gaussSum: function( a, tmp, w, h, sigma, acc )
   {
      let rr = this.boxRadii( sigma );
      for ( let i = 0; i < 3; ++i )
      {
         this.boxH( a, tmp, w, h, rr[i] );
         this.boxV( tmp, a, w, h, rr[i], acc );
      }
   },

   // Gaussian blur normalised at the image borders: out = G(v)/G(1).
   // ws = { den, tmp : Float32Array(n), acc : Float64Array(>= max(w,h)) };
   // G(1) is cached in ws.den for the last sigma.
   blurBorder: function( v, w, h, sigma, out, ws )
   {
      if ( !ws.denReady || ws.denSigma != sigma )
      {
         ws.den.fill( 1 );
         this.gaussSum( ws.den, ws.tmp, w, h, sigma, ws.acc );
         ws.denReady = true;
         ws.denSigma = sigma;
      }
      out.set( v );
      this.gaussSum( out, ws.tmp, w, h, sigma, ws.acc );
      let d = ws.den;
      for ( let i = 0, n = w*h; i < n; ++i )
         out[i] /= d[i];
   },

   // City-block (L1) distance to the nearest seed pixel; with outsideSeed the
   // area outside the image counts as seed. Exact two-pass chamfer, out Int32Array.
   distL1: function( seed, w, h, outsideSeed, out )
   {
      const BIG = 1 << 29;
      for ( let y = 0, o = 0; y < h; ++y, o += w )
         for ( let x = 0; x < w; ++x )
         {
            let d = seed[o + x] ? 0 : BIG;
            if ( outsideSeed )
            {
               let e = Math.min( x + 1, w - x, y + 1, h - y );
               if ( e < d ) d = e;
            }
            out[o + x] = d;
         }
      for ( let y = 0, o = 0; y < h; ++y, o += w )
         for ( let x = 0; x < w; ++x )
         {
            let d = out[o + x];
            if ( x > 0 && out[o + x - 1] + 1 < d ) d = out[o + x - 1] + 1;
            if ( y > 0 && out[o + x - w] + 1 < d ) d = out[o + x - w] + 1;
            out[o + x] = d;
         }
      for ( let y = h - 1, o = (h - 1)*w; y >= 0; --y, o -= w )
         for ( let x = w - 1; x >= 0; --x )
         {
            let d = out[o + x];
            if ( x < w - 1 && out[o + x + 1] + 1 < d ) d = out[o + x + 1] + 1;
            if ( y < h - 1 && out[o + x + w] + 1 < d ) d = out[o + x + w] + 1;
            out[o + x] = d;
         }
   },

   // Marks (in big) the 4-connected components of obj with more than minArea pixels.
   // stack: Int32Array(n), seen: Uint8Array(n) scratch.
   bigComponents: function( obj, w, h, minArea, big, stack, seen )
   {
      seen.fill( 0 );
      big.fill( 0 );
      let n = w*h;
      for ( let s = 0; s < n; ++s )
      {
         if ( !obj[s] || seen[s] )
            continue;
         let top = 0, start = 0;
         stack[top++] = s;
         seen[s] = 1;
         // breadth-first; stack[0, top) is the component's pixel list
         while ( start < top )
         {
            let p = stack[start++];
            let x = p % w;
            if ( x > 0 && obj[p - 1] && !seen[p - 1] ) { seen[p - 1] = 1; stack[top++] = p - 1; }
            if ( x < w - 1 && obj[p + 1] && !seen[p + 1] ) { seen[p + 1] = 1; stack[top++] = p + 1; }
            if ( p >= w && obj[p - w] && !seen[p - w] ) { seen[p - w] = 1; stack[top++] = p - w; }
            if ( p < n - w && obj[p + w] && !seen[p + w] ) { seen[p + w] = 1; stack[top++] = p + w; }
         }
         if ( top > minArea )
            for ( let i = 0; i < top; ++i ) big[stack[i]] = 1;
      }
   },

   // Normalised 1-D Gaussian kernel with radius floor(4 sigma + 0.5) (scipy convention).
   gaussKernel: function( sigma )
   {
      let r = Math.max( 0, Math.floor( 4*sigma + 0.5 ) );
      let k = new Float64Array( 2*r + 1 );
      let s = 0;
      for ( let i = -r; i <= r; ++i )
      {
         let v = Math.exp( -0.5*i*i/(sigma*sigma) );
         k[i + r] = v;
         s += v;
      }
      for ( let i = 0; i < k.length; ++i ) k[i] /= s;
      return k;
   },

   // Circular convolution along the sector axis of an nr x ns grid (row-major), src -> dst.
   convAngular: function( src, dst, nr, ns, k )
   {
      let r = (k.length - 1) >> 1;
      let row = new Float64Array( ns + 2*r );
      for ( let i = 0, o = 0; i < nr; ++i, o += ns )
      {
         for ( let q = 0; q < ns + 2*r; ++q )
            row[q] = src[o + ((((q - r) % ns) + ns) % ns)];
         for ( let j = 0; j < ns; ++j )
         {
            let s = 0;
            for ( let q = 0, L = k.length; q < L; ++q )
               s += k[q]*row[j + q];
            dst[o + j] = s;
         }
      }
   },

   // Correlation along the radius axis, src -> dst: out[i] = sum_q k[q] src[i + q - r].
   // Outside the grid: edge replication ("nearest"), or zeros when zero is true.
   convRadial: function( src, dst, nr, ns, k, zero )
   {
      let r = (k.length - 1) >> 1;
      let col = new Float64Array( nr + 2*r );
      for ( let j = 0; j < ns; ++j )
      {
         let first = zero ? 0 : src[j], last = zero ? 0 : src[(nr - 1)*ns + j];
         for ( let i = 0; i < r; ++i ) col[i] = first;
         for ( let i = 0; i < nr; ++i ) col[r + i] = src[i*ns + j];
         for ( let i = 0; i < r; ++i ) col[r + nr + i] = last;
         for ( let i = 0; i < nr; ++i )
         {
            let s = 0;
            for ( let q = 0, L = k.length; q < L; ++q )
               s += k[q]*col[i + q];
            dst[i*ns + j] = s;
         }
      }
   }
};

// ----------------------------------------------------------------------------
var PSWEngine = {

   verbose: true,

   log: function( s ) { if ( this.verbose ) console.writeln( s ); },

   events: function()
   {
      CoreApplication.processEvents();
   },

   checkAbort: function()
   {
      if ( console.abortRequested )
         throw new Error( "Aborted by the user" );
   },

   selectedChannels: function( view, params )
   {
      let nch = view.image.numberOfChannels;
      if ( nch < 3 )
         return [ 0 ];
      let c = [];
      if ( params.chR ) c.push( 0 );
      if ( params.chG ) c.push( 1 );
      if ( params.chB ) c.push( 2 );
      return c;
   },

   validateView: function( view, params )
   {
      if ( view == null || view.isNull )
         return "Open an image first.";
      if ( view.isPreview )
         return "Select a main view, previews are not supported.";
      let img = view.image;
      if ( img.width < 256 || img.height < 256 )
         return "The image is too small (minimum 256 pixels on each side).";
      let f = params.binFactor;
      if ( Math.floor( img.width/f ) < 64 || Math.floor( img.height/f ) < 64 )
         return "The image is too small for this bin factor.";
      if ( this.selectedChannels( view, params ).length == 0 )
         return "No channel selected.";
      return null;
   },

   centre: function( view, params )
   {
      let W = view.image.width, H = view.image.height;
      if ( params.centerMode == 1 && isFinite( params.centerX ) && isFinite( params.centerY ) )
         return { x: params.centerX, y: params.centerY, source: "manual" };
      return { x: W/2, y: H/2, source: "image centre" };
   },

   // ------------------------------------------------------------------
   // Binned working copy (IntegerResample, average) and invalid pixels
   // ------------------------------------------------------------------
   prepare: function( view, params )
   {
      let img = view.image;
      let W = img.width, H = img.height, nch = img.numberOfChannels;
      let f = params.binFactor;
      let B = [];
      let Wb, Hb;
      let T = null;
      try
      {
         T = new ImageWindow( W, H, nch, 32, true, nch > 1, "psw_ring_tmp" );
         let tv = T.mainView;
         tv.beginProcess( UndoFlag.NoSwapFile );
         img.resetSelections();                   // assign() copies the selected channels only
         tv.image.assign( img );
         tv.endProcess();
         let R = new IntegerResample;
         R.zoomFactor = -f;                       // negative = downsample by f
         R.downsamplingMode = IntegerResample.Average;
         R.noGUIMessages = true;
         R.executeOn( tv, false );
         let bi = tv.image;
         Wb = bi.width; Hb = bi.height;           // floor( W/f ) x floor( H/f )
         for ( let c = 0; c < nch; ++c )
         {
            let a = new Float32Array( Wb*Hb );
            bi.getSamples( a, new Rect( 0, 0, Wb, Hb ), c );
            B.push( a );
         }
      }
      finally
      {
         if ( T != null )
            T.forceClose();
      }
      let n = Wb*Hb;

      // invalid pixels (registration borders): <= 0 or non-finite in any channel,
      // plus their 4-neighbours (partially covered border bins)
      let inv = new Uint8Array( n );
      for ( let c = 0; c < nch; ++c )
      {
         let a = B[c];
         for ( let i = 0; i < n; ++i )
         {
            let v = a[i];
            if ( !(v > 0 && v < 1e30) ) inv[i] = 1;
         }
      }
      let dist = new Int32Array( n );
      PSWMath.distL1( inv, Wb, Hb, false, dist );
      let valid = inv;
      let nValid = 0;
      for ( let i = 0; i < n; ++i )
      {
         let v = (dist[i] > 1) ? 1 : 0;
         valid[i] = v;
         nValid += v;
      }
      for ( let c = 0; c < nch; ++c )
      {
         let a = B[c];
         for ( let i = 0; i < n; ++i )
            if ( !valid[i] ) a[i] = 0;
      }
      return {
         W: W, H: H, nch: nch, f: f, Wb: Wb, Hb: Hb, n: n,
         B: B, valid: valid, nValid: nValid, dist: dist,
         ws: { den: new Float32Array( n ), tmp: new Float32Array( n ),
               acc: new Float64Array( Math.max( Wb, Hb ) ), denReady: false, denSigma: 0 },
         buf: new Float32Array( n ), mask: null, big: null, maskedFraction: 0
      };
   },

   // Native median filter (MorphologicalTransformation, square structure, max 25)
   // of one or more Float32Arrays of size w x h, in place. Groups of three arrays
   // share one RGB scratch window.
   medianFilter: function( arrs, w, h, size )
   {
      size = Math.max( 3, size | 1 );
      if ( size > 25 )
      {
         console.warningln( format( "** Median filter %d px capped at 25 px (process limit); star rejection is slightly weaker at this bin factor.", size ) );
         size = 25;
      }
      let way = [];
      for ( let i = 0; i < size*size; ++i ) way.push( 1 );
      let rect = new Rect( 0, 0, w, h );
      for ( let g = 0; g < arrs.length; )
      {
         let k = (arrs.length - g >= 3) ? 3 : 1;
         let T = null;
         try
         {
            T = new ImageWindow( w, h, k, 32, true, k == 3, "psw_ring_med" );
            let v = T.mainView;
            v.beginProcess( UndoFlag.NoSwapFile );
            for ( let c = 0; c < k; ++c )
               v.image.setSamples( arrs[g + c], rect, c );
            v.endProcess();
            let M = new MorphologicalTransformation;
            M.operator = MorphologicalTransformation.Median;
            M.interlacingDistance = 1;
            M.lowThreshold = 0;
            M.highThreshold = 0;
            M.numberOfIterations = 1;
            M.amount = 1;
            M.selectionPoint = 0.5;
            M.structureName = "";
            M.structureSize = size;
            M.structureWayTable = [ [ way ] ];
            M.executeOn( v, false );
            for ( let c = 0; c < k; ++c )
               v.image.getSamples( arrs[g + c], rect, c );
         }
         finally
         {
            if ( T != null )
               T.forceClose();
         }
         g += k;
      }
   },

   // ------------------------------------------------------------------
   // Star and large-object rejection mask on the channel mean
   // (port of the lead's reference se.py objmask / proto.py mask_of).
   // Sizes are defined at bin 4 and scaled by 4/binFactor.
   // ------------------------------------------------------------------
   buildMask: function( P, params )
   {
      let w = P.Wb, h = P.Hb, n = P.n;
      let s = PSW_REF_BIN/P.f;
      let odd = ( v ) => { let k = Math.max( 3, Math.round( v ) ); return (k & 1) ? k : k + 1; };
      let valid = P.valid;
      let x = new Float32Array( n );
      let inv = 1/P.nch;
      for ( let c = 0; c < P.nch; ++c )
      {
         let a = P.B[c];
         for ( let i = 0; i < n; ++i ) x[i] += a[i];
      }
      for ( let i = 0; i < n; ++i ) x[i] *= inv;

      // stars: keep x - median15(x) < 2.5 sigma, eroded by 2 (L1, image border counts as rejected)
      let st = PSWMath.madn( x, valid, n, P.buf );
      let bg = new Float32Array( n );
      for ( let i = 0; i < n; ++i ) bg[i] = valid[i] ? x[i] : st.median;
      this.medianFilter( [ bg ], w, h, odd( 15*s ) );
      let notM = new Uint8Array( n );
      let thr = 2.5*st.madn;
      for ( let i = 0; i < n; ++i )
         notM[i] = (valid[i] && x[i] - bg[i] < thr) ? 0 : 1;
      let dist = P.dist;
      let er = Math.max( 1, Math.round( 2*s ) );
      PSWMath.distL1( notM, w, h, true, dist );
      let m = notM;
      for ( let i = 0; i < n; ++i ) m[i] = (dist[i] > er) ? 1 : 0;
      this.checkAbort();

      // large objects: high-pass (sigma 60) of the star-cleaned, median-9 image above k sigma,
      // connected area > 200 px, dilated by 10 (L1)
      let med2 = PSWMath.madn( x, m, n, P.buf ).median;
      let sm = bg;
      for ( let i = 0; i < n; ++i ) sm[i] = m[i] ? x[i] : med2;
      this.medianFilter( [ sm ], w, h, odd( 9*s ) );
      let lo = x;   // x is no longer needed
      PSWMath.blurBorder( sm, w, h, 60*s, lo, P.ws );
      let y = sm;
      for ( let i = 0; i < n; ++i ) y[i] = sm[i] - lo[i];
      let sd = PSWMath.madn( y, m, n, P.buf ).madn;
      let obj = new Uint8Array( n );
      let ot = params.objectSigma*sd;
      for ( let i = 0; i < n; ++i ) obj[i] = (y[i] > ot) ? 1 : 0;
      let big = new Uint8Array( n );
      PSWMath.bigComponents( obj, w, h, 200*s*s, big, new Int32Array( n ), new Uint8Array( n ) );
      PSWMath.distL1( big, w, h, false, dist );
      let dil = Math.max( 1, Math.round( 10*s ) );
      for ( let i = 0; i < n; ++i )
      {
         let b = (dist[i] <= dil) ? 1 : 0;
         big[i] = b;
         if ( b ) m[i] = 0;
      }
      if ( params.diagnostics )
         P.maskRef = new Uint8Array( m );   // reference mask (lead's objmask), read by the test harness

      // Object protection (robustness addition to the reference): accepted pixels in
      // areas that are mostly rejected (gaps between nebula filaments, bright-star
      // halos) carry object light; they are excluded so it never enters the ring model.
      if ( params.protectObjects )
      {
         let rej = lo, tmp = y;
         for ( let i = 0; i < n; ++i ) rej[i] = m[i] ? 0 : 1;
         let rb = Math.max( 1, Math.round( PSW_PROTECT_BOX*s ) ) >> 1;
         PSWMath.boxH( rej, tmp, w, h, rb );
         PSWMath.boxV( tmp, rej, w, h, rb, P.ws.acc );
         let one = P.ws.den;
         one.fill( 1 );
         PSWMath.boxH( one, tmp, w, h, rb );
         PSWMath.boxV( tmp, one, w, h, rb, P.ws.acc );
         P.ws.denReady = false;
         for ( let i = 0; i < n; ++i )
            if ( m[i] && rej[i] > PSW_PROTECT_FRAC*one[i] ) m[i] = 0;
      }
      let nm = 0;
      for ( let i = 0; i < n; ++i ) nm += m[i];
      P.mask = m;
      P.big = big;
      P.maskedFraction = 1 - nm/n;
   },

   // ------------------------------------------------------------------
   // Polar geometry of the binned grid and cell counts (shared by all channels)
   // ------------------------------------------------------------------
   geometry: function( P, params, cx, cy )
   {
      let f = P.f, w = P.Wb, h = P.Hb;
      let ns = params.nSectors, dr = PSW_DR;
      let cxb = (cx + 0.5)/f - 0.5, cyb = (cy + 0.5)/f - 0.5;
      let rmax = 0;
      for ( let [ px, py ] of [ [ 0, 0 ], [ w - 1, 0 ], [ 0, h - 1 ], [ w - 1, h - 1 ] ] )
         rmax = Math.max( rmax, Math.sqrt( (px - cxb)*(px - cxb) + (py - cyb)*(py - cyb) ) );
      let nr = Math.floor( rmax/dr ) + 2;
      let rmin = params.innerRadius/f;
      let cell = new Int32Array( P.n );
      let C = new Float64Array( nr*ns );
      let k2 = ns/(2*Math.PI);
      let m = P.mask;
      for ( let y = 0, o = 0; y < h; ++y, o += w )
      {
         let dy = y - cyb;
         for ( let x = 0; x < w; ++x )
         {
            let i = o + x;
            if ( !m[i] ) { cell[i] = -1; continue; }
            let dx = x - cxb;
            let r = Math.sqrt( dx*dx + dy*dy );
            if ( r < rmin ) { cell[i] = -1; continue; }
            let rb = Math.floor( r/dr );
            if ( rb > nr - 1 ) rb = nr - 1;
            let sb = Math.floor( (Math.atan2( dy, dx ) + Math.PI)*k2 ) % ns;
            let c = rb*ns + sb;
            cell[i] = c;
            C[c] += 1;
         }
      }
      return { cxb: cxb, cyb: cyb, nr: nr, ns: ns, dr: dr, rmin: rmin, cell: cell, C: C };
   },

   // Kernels and smoothed count grids, shared by all channels.
   countGrids: function( G, params, f )
   {
      let nr = G.nr, ns = G.ns, N = nr*ns;
      let ka = PSWMath.gaussKernel( params.arcSmooth/360*ns );
      let kf = PSWMath.gaussKernel( params.ringDetail );
      let kc = PSWMath.gaussKernel( params.ringScale/(f*G.dr) );
      let Ca = new Float64Array( N ), Cf = new Float64Array( N ), Cc = new Float64Array( N );
      PSWMath.convAngular( G.C, Ca, nr, ns, ka );
      PSWMath.convRadial( Ca, Cf, nr, ns, kf, false );
      PSWMath.convRadial( Ca, Cc, nr, ns, kc, false );
      return { ka: ka, kf: kf, kc: kc, Ca: Ca, Cf: Cf, Cc: Cc };
   },

   // Ring grid of one channel: nr x (ns + 1) Float64Array, last column = first (wrap).
   ringGrid: function( P, G, K, a )
   {
      let nr = G.nr, ns = G.ns, N = nr*ns;
      let S = new Float64Array( N );
      let cell = G.cell;
      for ( let i = 0, n = P.n; i < n; ++i )
      {
         let c = cell[i];
         if ( c >= 0 ) S[c] += a[i];
      }
      let Sa = new Float64Array( N ), Sf = new Float64Array( N ), Sc = new Float64Array( N );
      PSWMath.convAngular( S, Sa, nr, ns, K.ka );
      PSWMath.convRadial( Sa, Sf, nr, ns, K.kf, false );
      PSWMath.convRadial( Sa, Sc, nr, ns, K.kc, false );
      let Ca = K.Ca, Cf = K.Cf, Cc = K.Cc;
      // coarse = Sc/Cc (edge-replicated normalised Gaussian, as the reference: its
      // end behaviour also removes broad zones at the frame edges, which is intended);
      // one twicing step: coarse += G( (Sa/Ca - coarse)*Ca )/Cc
      let coarse = Sc, R = S;
      for ( let i = 0; i < N; ++i )
      {
         coarse[i] = Sc[i]/Math.max( Cc[i], 1e-9 );
         R[i] = Sa[i] - coarse[i]*Ca[i];
      }
      let T = Sa;
      PSWMath.convRadial( R, T, nr, ns, K.kc, false );
      for ( let i = 0; i < N; ++i )
         coarse[i] += T[i]/Math.max( Cc[i], 1e-9 );
      let ring = new Float64Array( nr*(ns + 1) );
      let sumsq = 0, cnt = 0;
      for ( let i = 0; i < nr; ++i )
      {
         let o = i*ns, q = i*(ns + 1);
         for ( let j = 0; j < ns; ++j )
         {
            let k = o + j;
            let v = 0;
            if ( Cf[k] > PSW_CF_MIN )
            {
               v = Sf[k]/Cf[k] - coarse[k];
               sumsq += v*v*G.C[k];
               cnt += G.C[k];
            }
            ring[q + j] = v;
         }
         ring[q + ns] = ring[q];
      }
      return { ring: ring, rms: cnt > 0 ? Math.sqrt( sumsq/cnt ) : 0 };
   },

   // Ring model of one row, one output array per channel (up to 3).
   // Pixel x of row y maps to dx = (x - ox)*invf, dy = (y - oy)*invf binned px
   // (full resolution: centre in full-res px, invf = 1/f; binned grid: binned centre, invf = 1).
   modelRow: function( G, rings, y, len, ox, oy, invf, outs )
   {
      let ns = G.ns, ns1 = ns + 1, nr = G.nr;
      let invdr = 1/G.dr, k2 = ns/(2*Math.PI), PI = Math.PI;
      let rmax = nr - 1.001;
      let rmin = G.rmin, hasTaper = rmin > 0, invTaper = 1/PSW_TAPER;
      let nb = rings.length;
      let r0 = rings[0], r1 = nb > 1 ? rings[1] : null, r2 = nb > 2 ? rings[2] : null;
      let o0 = outs[0], o1 = nb > 1 ? outs[1] : null, o2 = nb > 2 ? outs[2] : null;
      let dy = (y - oy)*invf;
      let dy2 = dy*dy;
      for ( let x = 0; x < len; ++x )
      {
         let dx = (x - ox)*invf;
         let rho = Math.sqrt( dx*dx + dy2 );
         // radius bin i covers [i dr, (i+1) dr): its value sits at the bin centre
         let rf = rho*invdr - 0.5;
         if ( rf < 0 ) rf = 0; else if ( rf > rmax ) rf = rmax;
         let i0 = rf | 0;
         let t = rf - i0;
         let af = (Math.atan2( dy, dx ) + PI)*k2 - 0.5;
         if ( af < 0 ) af += ns;
         let j0 = af | 0;
         if ( j0 >= ns ) j0 = ns - 1;
         let u = af - j0;
         let b = i0*ns1 + j0;
         let w00 = (1 - t)*(1 - u), w10 = t*(1 - u), w01 = (1 - t)*u, w11 = t*u;
         if ( hasTaper )
         {
            let g = (rho - rmin)*invTaper;
            g = g < 0 ? 0 : (g > 1 ? 1 : g);
            w00 *= g; w10 *= g; w01 *= g; w11 *= g;
         }
         o0[x] = w00*r0[b] + w10*r0[b + ns1] + w01*r0[b + 1] + w11*r0[b + ns1 + 1];
         if ( r1 != null )
            o1[x] = w00*r1[b] + w10*r1[b + ns1] + w01*r1[b + 1] + w11*r1[b + ns1 + 1];
         if ( r2 != null )
            o2[x] = w00*r2[b] + w10*r2[b + ns1] + w01*r2[b + 1] + w11*r2[b + ns1 + 1];
      }
   },

   // Ring power: fill rejected pixels with the masked median, median 7x7,
   // high-pass against a Gaussian (sigma 250 binned px at bin 4), RMS over
   // the model cells (unrejected, r >= inner radius). arrs are modified.
   ringPower: function( P, G, arrs )
   {
      let n = P.n, m = P.mask, w = P.Wb, h = P.Hb;
      let s = PSW_REF_BIN/P.f;
      for ( let a of arrs )
      {
         let med = PSWMath.madn( a, m, n, P.buf ).median;
         for ( let i = 0; i < n; ++i ) if ( !m[i] ) a[i] = med;
      }
      let sz = Math.max( 3, Math.round( 7*s ) );
      this.medianFilter( arrs, w, h, (sz & 1) ? sz : sz + 1 );
      let lo = P.buf;
      let out = [];
      for ( let a of arrs )
      {
         PSWMath.blurBorder( a, w, h, PSW_METRIC_HP*s, lo, P.ws );
         let ss = 0, cnt = 0;
         for ( let i = 0; i < n; ++i )
            if ( G.cell[i] >= 0 )
            {
               let d = a[i] - lo[i];
               ss += d*d;
               ++cnt;
            }
         out.push( cnt > 0 ? Math.sqrt( ss/cnt ) : 0 );
      }
      return out;
   },

   // Model RMS inside large-object areas relative to the background at the same
   // radii (near 1: the model is a smooth interpolation, not object structure).
   objectRatio: function( P, G, mB )
   {
      let nr = G.nr;
      let so = new Float64Array( nr ), co = new Float64Array( nr );
      let sb = new Float64Array( nr ), cb = new Float64Array( nr );
      let w = P.Wb, h = P.Hb, big = P.big, m = P.mask, valid = P.valid;
      for ( let y = 0, o = 0; y < h; ++y, o += w )
      {
         let dy = y - G.cyb;
         for ( let x = 0; x < w; ++x )
         {
            let i = o + x;
            if ( !valid[i] ) continue;
            let dx = x - G.cxb;
            let rb = Math.min( nr - 1, Math.floor( Math.sqrt( dx*dx + dy*dy )/G.dr ) );
            let v = mB[i]*mB[i];
            if ( big[i] ) { so[rb] += v; co[rb] += 1; }
            else if ( m[i] ) { sb[rb] += v; cb[rb] += 1; }
         }
      }
      let num = 0, den = 0;
      for ( let r = 0; r < nr; ++r )
         if ( co[r] > 0 && cb[r] > 0 )
         {
            num += so[r];
            den += co[r]*sb[r]/cb[r];
         }
      return den > 0 ? Math.sqrt( num/den ) : 0;
   },

   // ------------------------------------------------------------------
   // Orchestration
   // ------------------------------------------------------------------
   run: function( view, params )
   {
      let t0 = Date.now();
      let st = { bin: 0, mask: 0, model: 0, metric: 0, render: 0 };
      let result = { ok: false, applied: 0 };
      let err = this.validateView( view, params );
      if ( err != null )
      {
         result.error = err;
         console.criticalln( "<end><cbr>*** " + err );
         return result;
      }
      params.validate();
      if ( params.amount == 0 )
      {
         result.ok = true; result.reason = "amount_zero";
         this.log( "Amount is 0: nothing to do." );
         return result;
      }
      console.abortEnabled = true;
      let img = view.image;
      let W = img.width, H = img.height;
      let chans = this.selectedChannels( view, params );
      let f = params.binFactor;
      let ctr = this.centre( view, params );
      result.cx = ctr.x; result.cy = ctr.y; result.centerSource = ctr.source;
      this.log( format( "Ring centre: x = %.1f, y = %.1f (%s)", ctr.x, ctr.y, ctr.source ) );

      let ta = Date.now();
      let P = this.prepare( view, params );
      st.bin = Date.now() - ta;
      this.log( format( "Binned %dx%d -> %dx%d (bin %d); invalid (zero/NaN border) pixels %.1f%%",
                        W, H, P.Wb, P.Hb, f, 100*(1 - P.nValid/P.n) ) );
      if ( PSWMath.madn( P.B[0], P.valid, P.n, P.buf ).median > 0.2 )
         console.warningln( "** The image looks stretched; this script expects linear data." );
      this.events();

      ta = Date.now();
      this.buildMask( P, params );
      st.mask = Date.now() - ta;
      result.maskedFraction = P.maskedFraction;
      this.log( format( "Rejected (stars, objects, borders): %.1f%%", 100*P.maskedFraction ) );
      if ( P.maskedFraction > 0.9 )
      {
         result.error = format( "%.0f%% of the image is rejected as objects; aborted without changes.", 100*P.maskedFraction );
         console.criticalln( "*** " + result.error );
         return result;
      }
      if ( P.maskedFraction > 0.7 )
         console.warningln( format( "** %.0f%% of the image is rejected as objects; the ring model may be poor.", 100*P.maskedFraction ) );
      this.checkAbort();
      this.events();

      ta = Date.now();
      let G = this.geometry( P, params, ctr.x, ctr.y );
      let K = this.countGrids( G, params, f );
      let models = chans.map( ( c ) => this.ringGrid( P, G, K, P.B[c] ) );
      let rings = models.map( ( m ) => m.ring );
      st.model = Date.now() - ta;
      this.events();

      // ring power before / after on the binned image (model evaluated at binned pixel
      // centres) and the object/background model ratio; diagnostics only, no effect on output
      let pb = null, pa = null, ratios = null;
      if ( params.diagnostics )
      {
         ta = Date.now();
         let mB = chans.map( () => new Float32Array( P.n ) );
         let outs = mB.map( () => null );
         for ( let y = 0; y < P.Hb; ++y )
         {
            for ( let i = 0; i < mB.length; ++i ) outs[i] = mB[i].subarray( y*P.Wb, (y + 1)*P.Wb );
            this.modelRow( G, rings, y, P.Wb, G.cxb, G.cyb, 1, outs );
         }
         let am = params.amount;
         let before = chans.map( ( c ) => new Float32Array( P.B[c] ) );
         let after = chans.map( ( c, i ) =>
         {
            let a = new Float32Array( P.n ), b = P.B[c], m = mB[i];
            for ( let k = 0; k < P.n; ++k ) a[k] = b[k] - am*m[k];
            return a;
         } );
         pb = this.ringPower( P, G, before );
         pa = this.ringPower( P, G, after );
         ratios = mB.map( ( m ) => this.objectRatio( P, G, m ) );
         st.metric = Date.now() - ta;
      }

      result.binW = P.Wb; result.binH = P.Hb;
      result.nRadial = G.nr; result.nSectors = G.ns;
      result.channels = chans;
      result.modelRms = models.map( ( m ) => m.rms );
      if ( pb != null )
      {
         result.ringPowerBefore = pb;
         result.ringPowerAfter = pa;
         result.objectModelRatio = ratios;
      }
      P = null;   // release the binned data before the full-resolution pass

      ta = Date.now();
      let rr = this.render( view, params, G, rings, chans, ctr.x, ctr.y, f );
      st.render = Date.now() - ta;
      result.clamped = rr.clamped;
      result.modelWindowId = rr.modelId;
      result.applied = rr.applied;
      result.ok = rr.applied == 1;
      if ( rr.error ) result.error = rr.error;
      result.timeMs = Date.now() - t0;
      result.perStageMs = st;
      const names = [ "R", "G", "B" ];
      for ( let i = 0; i < chans.length; ++i )
      {
         let cn = img.numberOfChannels > 1 ? names[chans[i]] : "K";
         if ( pb != null )
            this.log( format( "Channel %s: ring power %.3e -> %.3e (model RMS %.3e, object/background %.2f)",
                              cn, pb[i], pa[i], result.modelRms[i], ratios[i] ) );
         else
            this.log( format( "Channel %s: ring model RMS %.3e", cn, result.modelRms[i] ) );
      }
      this.log( format( "Clamped %d px, %.2f s", result.clamped, result.timeMs/1000 ) );
      return result;
   },

   // ------------------------------------------------------------------
   // Full-resolution render and apply (single pass, one undo step)
   // ------------------------------------------------------------------
   render: function( view, params, G, rings, chans, cx, cy, f )
   {
      let img = view.image;
      let W = img.width, H = img.height, nch = img.numberOfChannels;
      let amount = params.amount;
      let BR = 32;
      let nb = chans.length;
      let modelWin = null, mimg = null;
      if ( params.showModel )
      {
         try
         {
            modelWin = new ImageWindow( W, H, nch, 32, true, nch > 1, "RingModel" );
            modelWin.mainView.beginProcess( UndoFlag.NoSwapFile );
            mimg = modelWin.mainView.image;
            mimg.fill( 0.5 );
         }
         catch ( e )
         {
            console.warningln( "** Could not create the model window: " + e );
            if ( modelWin != null ) { try { modelWin.forceClose(); } catch ( e2 ) {} }
            modelWin = null; mimg = null;
         }
      }
      let px = new Float32Array( W*BR );
      let mrows = [];
      for ( let i = 0; i < nb; ++i ) mrows.push( new Float32Array( W*BR ) );
      let outs = mrows.map( () => null );
      let invf = 1/f;
      let clamped = 0;
      let started = false, applied = 0, error = null;
      try
      {
         view.beginProcess();   // default flags: undoable history step
         started = true;
         for ( let y0 = 0; y0 < H; y0 += BR )
         {
            this.checkAbort();
            let nr = Math.min( BR, H - y0 );
            for ( let yy = 0; yy < nr; ++yy )
            {
               for ( let i = 0; i < nb; ++i ) outs[i] = mrows[i].subarray( yy*W, yy*W + W );
               this.modelRow( G, rings, y0 + yy, W, cx, cy, invf, outs );
            }
            let rect = new Rect( 0, y0, W, y0 + nr );
            let np = W*nr;
            let pv = (nr == BR) ? px : px.subarray( 0, np );
            for ( let i = 0; i < nb; ++i )
            {
               let c = chans[i];
               let mr = mrows[i];
               img.getSamples( pv, rect, c );
               for ( let k = 0; k < np; ++k )
               {
                  let x = pv[k];
                  if ( !(x > 0 && x < 1e30) ) continue;   // invalid pixels are never written
                  let o = x - amount*mr[k];
                  if ( o < 0 ) { o = 0; ++clamped; }
                  else if ( o > 1 ) { o = 1; ++clamped; }
                  pv[k] = o;
               }
               img.setSamples( pv, rect, c );
               if ( mimg != null )
               {
                  let mv = (nr == BR) ? mr : mr.subarray( 0, np );
                  for ( let k = 0; k < np; ++k )
                  {
                     let v = mv[k] + 0.5;
                     mv[k] = v < 0 ? 0 : (v > 1 ? 1 : v);
                  }
                  mimg.setSamples( mv, rect, c );
               }
            }
            if ( ((y0/BR) & 15) == 0 ) this.events();
         }
         view.endProcess();
         started = false;
         applied = 1;
      }
      catch ( e )
      {
         error = String( e );
         console.criticalln( "*** " + error );
         if ( started )
         {
            try { view.cancelProcess(); } catch ( e2 ) { try { view.endProcess(); } catch ( e3 ) {} }
         }
      }
      finally
      {
         if ( modelWin != null )
         {
            modelWin.mainView.endProcess();
            if ( applied )
               modelWin.show();
            else
               modelWin.forceClose();
         }
      }
      return { clamped: clamped, applied: applied, error: error,
               modelId: (applied && modelWin != null) ? modelWin.mainView.id : "" };
   }
};
